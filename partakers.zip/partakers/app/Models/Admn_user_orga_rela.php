<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class admn_user_orga_rela extends Model
{
    protected $table = 'admn_user_orga_rela';
    protected $primaryKey = 'User_Assc_UIN';
}
