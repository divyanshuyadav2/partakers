<?php

namespace App\Livewire\Contacts;

use Livewire\Attributes\Computed;
use Livewire\Attributes\On;
use Livewire\Component;
use App\Models\AdmnCntaNoteComnt;    

class ManageIssues extends Component
{
    public bool $showIssueModal = false;
    public bool $showCreateEditModal = false;

    public ?int $editingId = null;

    public string $parent = 'new'; // For category selection
    public string $newParent = ''; // For new category name
    public string $note = '';      // For comment text

    /**
     * Entry point: Opens the main "Manage Issues" modal
     */
    #[On('openIssueManager')]
    public function openModal()
    {
        $this->showIssueModal = true;
    }

    /**
     * Get all active issues - ONLY ORGANIZATION CREATED (NOT SYSTEM)
     */
    #[Computed]
    public function allIssues()
    {
        $org = session('selected_Orga_UIN');

        return AdmnCntaNoteComnt::where('Stau_UIN', 100201) // Active status only
            ->where('Orga_UIN', $org) // ONLY organization created (not NULL/system)
            ->orderBy('Category')
            ->orderBy('Comnt_Text')
            ->get();
    }

    /**
     * Get unique categories - ONLY FROM ORGANIZATION (NOT SYSTEM)
     */
    #[Computed]
    public function parents()
    {
        $org = session('selected_Orga_UIN');

        return AdmnCntaNoteComnt::where('Stau_UIN', 100201)
            ->where('Orga_UIN', $org) // ONLY organization categories
            ->pluck('Category')
            ->unique()
            ->filter() // Remove empty values
            ->values();
    }

    /**
     * Open Create Modal - default to 'new' parent
     */
    public function openCreate()
    {
        $this->resetForm();
        $this->parent = 'new'; // Default to new category
        $this->showCreateEditModal = true;
    }

    /**
     * Open Edit Modal
     */
    public function openEdit($id)
    {
        $issue = AdmnCntaNoteComnt::findOrFail($id);

        $this->editingId = $issue->Admn_Cnta_Note_Comnt_UIN;
        $this->parent = $issue->Category; // Set existing category
        $this->note = $issue->Comnt_Text;

        $this->showCreateEditModal = true;
    }

    /**
     * Check if category already exists for this organization
     */
    private function categoryExists($categoryName, $excludeId = null)
    {
        $org = session('selected_Orga_UIN');

        $query = AdmnCntaNoteComnt::where('Stau_UIN', 100201)
            ->where('Orga_UIN', $org)
            ->where('Category', trim($categoryName));

        if ($excludeId) {
            $query->where('Admn_Cnta_Note_Comnt_UIN', '!=', $excludeId);
        }

        return $query->exists();
    }

    /**
     * Save (Create or Update)
     */
    public function save()
    {
        $org = session('selected_Orga_UIN');
        $auth = session('authenticated_user_uin');

        // Determine final category
        $finalCategory = $this->parent === 'new'
            ? trim($this->newParent)
            : $this->parent;

        // Validation
        if (empty($finalCategory)) {
            session()->flash('error', 'Please select or enter a category.');
            return;
        }

        if (empty(trim($this->note))) {
            session()->flash('error', 'Comment is required.');
            return;
        }

        // Check if new category already exists
        if ($this->parent === 'new') {
            if ($this->categoryExists($finalCategory, $this->editingId)) {
                session()->flash('error', 'Category "' . $finalCategory . '" already exists. Please select from dropdown or enter a different name.');
                return;
            }
        }

        if ($this->editingId) {
            // UPDATE existing record
            $issue = AdmnCntaNoteComnt::findOrFail($this->editingId);
            
            // Check if user can edit this issue
            if (!$this->canEdit($issue)) {
                session()->flash('error', 'You cannot edit this issue.');
                return;
            }

            // If changing to a new category, check if it exists
            if ($this->parent === 'new' && $this->categoryExists($finalCategory, $this->editingId)) {
                session()->flash('error', 'Category "' . $finalCategory . '" already exists. Please select from dropdown or enter a different name.');
                return;
            }

            $issue->update([
                'Category' => $finalCategory,
                'Comnt_Text' => trim($this->note),
                'MoOn' => now(),
            ]);

            session()->flash('message', 'Note updated successfully.');
        } else {
            // CREATE new record
            AdmnCntaNoteComnt::create([
                'Category' => $finalCategory,
                'Comnt_Text' => trim($this->note),
                'Stau_UIN' => 100201, // Active status
                'Orga_UIN' => $org, // Set organization (makes it organization-created, not system)
                'CrBy' => $auth,
                'CrOn' => now(),
                'MoOn' => now(),
            ]);

            session()->flash('message', 'Note created successfully.');
        }

        // Clear computed cache
        unset($this->allIssues);
        unset($this->parents);

        $this->closeAllModals();
    }

    /**
     * Can edit if created by this organization
     */
    public function canEdit($issue)
    {
        $org = session('selected_Orga_UIN');
        
        // Can edit only if created by this organization
        return !is_null($issue->Orga_UIN) && $issue->Orga_UIN == $org;
    }

    /**
     * Can delete only if created by this organization
     * AND not used in any contacts
     */
    public function canDelete($issue)
    {
        $org = session('selected_Orga_UIN');
        
        // Must be created by this organization
        if (is_null($issue->Orga_UIN) || $issue->Orga_UIN != $org) {
            return false;
        }

        // Check if used in any contacts
        // TODO: Implement check based on your contact relationship
        // Example: if ($issue->isUsedInContacts()) return false;
        
        return true;
    }

    /**
     * Delete issue (soft delete by setting status to inactive)
     */
    public function delete($id)
    {
        $issue = AdmnCntaNoteComnt::findOrFail($id);
        
        // Double-check permissions
        if (!$this->canDelete($issue)) {
            session()->flash('error', 'You cannot delete this note. It may be in use.');
            return;
        }

        // Soft delete by setting status to inactive
        $issue->update(['Stau_UIN' => 100202]); // Assuming 100202 is inactive status
        
        // Clear computed cache
        unset($this->allIssues);
        unset($this->parents);
        
        session()->flash('message', 'Note deleted successfully.');
    }

    public function closeModal()
    {
        $this->showCreateEditModal = false;
    }

    public function closeAllModals()
    {
        $this->showIssueModal = false;
        $this->showCreateEditModal = false;
        $this->resetForm();
    }

    private function resetForm()
    {
        $this->editingId = null;
        $this->parent = 'new';
        $this->newParent = '';
        $this->note = '';
    }

    public function render()
    {
        return view('livewire.contacts.manage-issues');
    }
}