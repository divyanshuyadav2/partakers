import './bootstrap';
// Your existing JavaScript
import countries from 'country-flag-emoji'; // Import the library data
