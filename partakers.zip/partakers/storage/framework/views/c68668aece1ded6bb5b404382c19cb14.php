<div>
    <!-- MANAGE ISSUES MODAL -->
    <!--[if BLOCK]><![endif]--><?php if($showIssueModal): ?>
        <div class="fixed inset-0 z-30 flex items-center justify-center p-4 sm:p-6" 
             x-data="{ show: <?php if ((object) ('showIssueModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showIssueModal'->value()); ?>')<?php echo e('showIssueModal'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showIssueModal'); ?>')<?php endif; ?> }"
             @keydown.escape.window="show = false">

            <!-- Backdrop -->
            <div wire:click="closeAllModals" 
                 x-show="show" 
                 x-transition.opacity.duration.300ms
                 class="absolute inset-0 bg-gray-900/80 backdrop-blur-sm"></div>

            <!-- Modal Window -->
            <div x-show="show" 
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 scale-95" 
                 x-transition:enter-end="opacity-100 scale-100"
                 x-transition:leave="transition ease-in duration-200" 
                 x-transition:leave-start="opacity-100 scale-100"
                 x-transition:leave-end="opacity-0 scale-95"
                 class="relative z-10 flex flex-col w-full h-full sm:h-auto sm:max-h-[90vh] sm:max-w-5xl bg-slate-800 sm:rounded-xl rounded-none shadow-2xl border border-slate-700/60 overflow-hidden">

                <!-- Header -->
                <div class="shrink-0 bg-slate-900/70 backdrop-blur-sm px-6 py-5 border-b border-slate-700/60 flex justify-between items-center">
                    <div class="flex items-center gap-4">
                        <div class="p-2.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
                            <i class="bi bi-card-text text-blue-400 text-xl"></i>
                        </div>
                        <h2 class="text-xl font-bold text-white tracking-tight">Issues</h2>
                    </div>
                    <button wire:click="closeAllModals"
                        class="p-2 rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white transition-colors">
                        <i class="bi bi-x-lg text-lg"></i>
                    </button>
                </div>

                <!-- Flash Messages -->
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div class="mx-6 mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg flex items-center gap-3">
                        <i class="bi bi-check-circle text-green-400 text-xl"></i>
                        <span class="text-green-300 text-sm"><?php echo e(session('message')); ?></span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <?php if(session()->has('error')): ?>
                    <div class="mx-6 mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-3">
                        <i class="bi bi-exclamation-circle text-red-400 text-xl"></i>
                        <span class="text-red-300 text-sm"><?php echo e(session('error')); ?></span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Content -->
                <div class="flex-1 overflow-y-auto p-6 bg-slate-800/50">
                    <button wire:click="openCreate"
                        class="mb-6 inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 px-5 rounded-lg shadow-lg shadow-blue-900/30 transition-all transform hover:scale-105 active:scale-100">
                        <i class="bi bi-plus-circle"></i> Add Note
                    </button>

                    <!--[if BLOCK]><![endif]--><?php if($this->allIssues->count() > 0): ?>
                        <div class="overflow-x-auto rounded-lg border border-slate-700/60 bg-slate-900/40">
                            <table class="w-full text-sm">
                                <thead class="bg-slate-800/50 border-b border-slate-700/60 text-xs uppercase text-slate-400">
                                    <tr>
                                        <th class="px-6 py-3 text-left font-semibold">Category (Parent)</th>
                                        <th class="px-6 py-3 text-left font-semibold">Note (Comment)</th>
                                        <th class="px-6 py-3 text-right font-semibold">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-700/40">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->allIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr wire:key="issue-<?php echo e($issue->Admn_Cnta_Note_Comnt_UIN); ?>"
                                            class="hover:bg-slate-800/60 transition-colors duration-150">
                                            
                                            <!-- Category -->
                                            <td class="px-6 py-4 font-medium text-slate-100">
                                                <?php echo e($issue->Category); ?>

                                            </td>
                                            
                                            <!-- Comment -->
                                            <td class="px-6 py-4 text-slate-300">
                                                <?php echo e(Str::limit($issue->Comnt_Text, 80)); ?>

                                            </td>
                                            
                                            <!-- Actions -->
                                            <td class="px-6 py-4 text-right">
                                                <div class="inline-flex gap-2">
                                                    <button wire:click="openEdit(<?php echo e($issue->Admn_Cnta_Note_Comnt_UIN); ?>)"
                                                        title="Edit"
                                                        class="p-2 rounded text-slate-300 hover:bg-amber-600/30 hover:text-amber-300 transition-colors">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>
                                                    
                                                    <!--[if BLOCK]><![endif]--><?php if($this->canDelete($issue)): ?>
                                                        <button wire:click="delete(<?php echo e($issue->Admn_Cnta_Note_Comnt_UIN); ?>)"
                                                            wire:confirm="Delete this note? This action cannot be undone."
                                                            title="Delete"
                                                            class="p-2 rounded text-slate-300 hover:bg-red-600/30 hover:text-red-300 transition-colors">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <span class="text-slate-500 text-xs px-2 py-1 italic" title="Note is in use">
                                                            <i class="bi bi-lock"></i>
                                                        </span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="rounded-lg border-2 border-dashed border-slate-700 py-20 text-center bg-slate-800/30">
                            <i class="bi bi-inbox text-5xl text-slate-600 mb-4"></i>
                            <h3 class="text-lg font-semibold text-slate-200 mb-2">No Notes Yet</h3>
                            <p class="text-sm text-slate-500 mb-6">Create your first note to get started.</p>
                            <button wire:click="openCreate"
                                class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 px-6 rounded-lg shadow-lg transition-colors">
                                <i class="bi bi-plus-circle"></i> Create Note
                            </button>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- CREATE/EDIT MODAL -->
    <!--[if BLOCK]><![endif]--><?php if($showCreateEditModal): ?>
        <div class="fixed inset-0 z-40 flex items-center justify-center p-4 sm:p-6">
            <div wire:click="closeModal" class="absolute inset-0 bg-black/80 backdrop-blur-sm"></div>

            <form wire:submit.prevent="save" 
                  x-data="{ show: <?php if ((object) ('showCreateEditModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showCreateEditModal'->value()); ?>')<?php echo e('showCreateEditModal'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showCreateEditModal'); ?>')<?php endif; ?> }" 
                  x-show="show"
                  x-transition.scale.origin.center
                  class="relative z-10 bg-slate-800 rounded-xl shadow-2xl w-full max-w-md border border-slate-700/60 overflow-hidden">

                <div class="bg-slate-900/70 px-6 py-4 border-b border-slate-700/60 flex justify-between items-center">
                    <h3 class="text-lg font-bold text-white">
                        <?php echo e($editingId ? 'Edit Note' : 'Add Note'); ?>

                    </h3>
                    <button type="button" wire:click="closeModal"
                        class="p-2 rounded-lg text-slate-400 hover:bg-slate-700 hover:text-white transition-colors">
                        <i class="bi bi-x-lg text-lg"></i>
                    </button>
                </div>

                <!-- Flash Messages in Modal -->
                <?php if(session()->has('error')): ?>
                    <div class="mx-6 mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-start gap-3">
                        <i class="bi bi-exclamation-triangle text-red-400 text-lg mt-0.5"></i>
                        <span class="text-red-300 text-sm"><?php echo e(session('error')); ?></span>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="p-6 space-y-6">
                    <!-- Parent/Category Selection -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                            <?php echo e($editingId ? 'Edit Parent' : 'Select Parent'); ?>

                        </label>
                        <select wire:model.live="parent" 
                                class="w-full bg-slate-900/70 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 py-2.5 px-3 transition">
                            <option value="new">+ New Category</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p); ?>"><?php echo e($p); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php if($this->parents->count() === 0 && $parent !== 'new'): ?>
                            <p class="mt-2 text-xs text-slate-500">
                                <i class="bi bi-info-circle"></i> No existing categories. Please create a new one.
                            </p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- New Category Input (shown only if 'new' is selected) -->
                    <!--[if BLOCK]><![endif]--><?php if($parent === 'new'): ?>
                        <div x-data="{ focused: false }">
                            <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                                New Category Name <span class="text-red-400">*</span>
                            </label>
                            <input type="text" 
                                   wire:model.live="newParent" 
                                   @focus="focused = true"
                                   @blur="focused = false"
                                   placeholder="Enter new category name"
                                   maxlength="100"
                                   class="w-full bg-slate-900/70 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 py-2.5 px-3 transition"
                                   :class="{ 'border-blue-500': focused }">
                            <div class="flex justify-between items-center mt-1">
                                <p class="text-xs text-slate-500">
                                    <i class="bi bi-lightbulb"></i> Create a unique category name
                                </p>
                                <p class="text-xs text-slate-500"><?php echo e(strlen($newParent)); ?>/100</p>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Note/Comment Text -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                            <?php echo e($editingId ? 'Edit Note' : 'Enter Note'); ?> <span class="text-red-400">*</span>
                        </label>
                        <textarea wire:model.live="note" 
                                  rows="5"
                                  placeholder="Enter your note/comment here..."
                                  class="w-full bg-slate-900/70 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 py-2.5 px-3 transition resize-none"></textarea>
                        <p class="mt-1 text-xs text-slate-500"><?php echo e(strlen($note)); ?> characters</p>
                    </div>
                </div>

                <div class="bg-slate-900/50 px-6 py-4 border-t border-slate-700/60 flex gap-3 justify-end">
                    <button type="button" 
                            wire:click="closeModal"
                            class="bg-slate-700/50 hover:bg-slate-700 text-slate-300 font-semibold py-2 px-5 rounded-lg transition-colors">
                        Cancel
                    </button>
                    <button type="submit"
                        class="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-semibold py-2 px-5 rounded-lg transition-colors min-w-[100px]">
                        <span wire:loading.remove wire:target="save">
                            <i class="bi bi-check-circle"></i> <?php echo e($editingId ? 'Save' : 'Create'); ?>

                        </span>
                        <span wire:loading wire:target="save" class="flex items-center gap-2">
                            <i class="bi bi-arrow-repeat animate-spin"></i> Saving...
                        </span>
                    </button>
                </div>
            </form>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\Users\DIVYANSHU\laravel\partakers\resources\views/livewire/contacts/manage-issues.blade.php ENDPATH**/ ?>