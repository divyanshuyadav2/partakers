<div>
    <?php echo csrf_field(); ?>

    
    <!--[if BLOCK]><![endif]--><?php if($hasError): ?>
        <div class="max-w-2xl mx-auto py-10 sm:px-6 lg:px-8">
            <div
                class="rounded-md p-8 text-center border-2
                <?php if($errorType === 'used'): ?> bg-amber-900/30 border-amber-500/50
                <?php elseif($errorType === 'expired'): ?> bg-red-900/30 border-red-500/50
                <?php else: ?> bg-slate-900/50 border-slate-500/50 <?php endif; ?>">

                
                <div class="mb-6">
                    <!--[if BLOCK]><![endif]--><?php if($errorType === 'used'): ?>
                        <i class="bi bi-check-circle-fill text-amber-400 text-6xl"></i>
                    <?php elseif($errorType === 'expired'): ?>
                        <i class="bi bi-clock-fill text-red-400 text-6xl"></i>
                    <?php else: ?>
                        <i class="bi bi-exclamation-triangle-fill text-slate-400 text-6xl"></i>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <h2
                    class="text-2xl font-bold mb-4
                    <?php if($errorType === 'used'): ?> text-amber-300
                    <?php elseif($errorType === 'expired'): ?> text-red-300
                    <?php else: ?> text-slate-300 <?php endif; ?>">
                    <!--[if BLOCK]><![endif]--><?php if($errorType === 'used'): ?>
                        Link Already Used
                    <?php elseif($errorType === 'expired'): ?>
                        Link Has Expired
                    <?php else: ?>
                        Access Not Available
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </h2>

                
                <p
                    class="mb-6 text-base leading-relaxed
                    <?php if($errorType === 'used'): ?> text-amber-200
                    <?php elseif($errorType === 'expired'): ?> text-red-200
                    <?php else: ?> text-slate-300 <?php endif; ?>">
                    <?php echo e($errorMessage); ?>

                </p>

                
                <!--[if BLOCK]><![endif]--><?php if($errorType === 'used'): ?>
                    <div class="bg-amber-800/30 border border-amber-600/50 rounded-md p-4 mb-6">
                        <div class="flex items-start">
                            <i class="bi bi-info-circle-fill text-amber-400 text-lg mt-0.5 mr-3 flex-shrink-0"></i>
                            <div class="text-left">
                                <p class="text-amber-200 text-sm font-medium mb-1">What happened?</p>
                                <p class="text-amber-300 text-sm">
                                    Someone (possibly you) has already submitted information using this link.
                                    For security reasons, each invitation link can only be used once.
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <!--[if BLOCK]><![endif]--><?php if($errorType === 'expired'): ?>
                    <div class="bg-red-800/30 border border-red-600/50 rounded-md p-4 mb-6">
                        <div class="flex items-start">
                            <i class="bi bi-info-circle-fill text-red-400 text-lg mt-0.5 mr-3 flex-shrink-0"></i>
                            <div class="text-left">
                                <p class="text-red-200 text-sm font-medium mb-1">Why did this expire?</p>
                                <p class="text-red-300 text-sm">
                                    Invitation links are valid for 24 hours from the time they were created
                                    for security purposes.
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <div class="text-sm text-slate-400">
                    <!--[if BLOCK]><![endif]--><?php if($errorType === 'used' || $errorType === 'expired'): ?>
                        Need a new link? Please contact the person who originally sent you this invitation.
                    <?php else: ?>
                        If you believe this is an error, please contact support.
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        
    <?php elseif($isSuccess): ?>
        <div class="max-w-2xl mx-auto py-10 sm:px-6 lg:px-8">
            <div class="bg-green-900/50 border border-green-500/50 rounded-md p-8 text-center">
                <div class="mb-4">
                    <i class="bi bi-check-circle-fill text-green-400 text-6xl"></i>
                </div>
                <h2 class="text-2xl font-bold text-white mb-4">Thank You!</h2>
                <p class="text-green-300 mb-6">Your contact information has been successfully submitted.</p>
                <p class="text-slate-400 text-sm">
                    This invitation link has now been used and cannot be accessed again.
                </p>
            </div>
        </div>

        
    <?php else: ?>
        <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">

            
            <!--[if BLOCK]><![endif]--><?php if(isset($linkExpiresAt)): ?>
                <div class="mb-6 bg-blue-900/30 border border-blue-500/50 rounded-md p-4" x-data="linkExpiryTimer('<?php echo e($linkExpiresAt); ?>')"
                    x-init="init()">

                    <div class="flex items-center justify-between">
                        
                        <div class="flex items-center gap-3">
                            <i class="bi bi-clock text-blue-400 text-lg"></i>
                            <div>
                                <p class="text-blue-300 font-medium text-sm">Link Expires In</p>
                                <p class="text-blue-200 text-xs">
                                    This invitation link will expire automatically for security.
                                </p>
                            </div>
                        </div>

                        
                        <div class="text-right">
                            <div class="flex items-center gap-2 text-blue-300">
                                <div class="bg-blue-800/50 rounded px-2 py-1 text-sm font-mono"
                                    x-show="timeLeft.hours > 0">
                                    <span x-text="timeLeft.hours.toString().padStart(2, '0')"></span>h
                                </div>
                                <div class="bg-blue-800/50 rounded px-2 py-1 text-sm font-mono">
                                    <span x-text="timeLeft.minutes.toString().padStart(2, '0')"></span>m
                                </div>
                                <div class="bg-blue-800/50 rounded px-2 py-1 text-sm font-mono">
                                    <span x-text="timeLeft.seconds.toString().padStart(2, '0')"></span>s
                                </div>
                            </div>
                            <p class="text-blue-400 text-xs mt-1" x-text="expiryDate"></p>
                        </div>
                    </div>

                    
                    <div x-show="timeLeft.total < 3600000 && timeLeft.total > 0" x-transition
                        class="mt-3 bg-amber-900/30 border border-amber-600/50 rounded-md p-3">
                        <div class="flex items-center gap-2">
                            <i class="bi bi-exclamation-triangle-fill text-amber-400"></i>
                            <p class="text-amber-300 text-sm font-medium">Link expires in less than 1 hour!</p>
                        </div>
                        <p class="text-amber-200 text-xs mt-1">
                            Please complete and submit the form before it expires.
                        </p>
                    </div>

                    
                    <div x-show="timeLeft.total < 900000 && timeLeft.total > 0" x-transition
                        class="mt-3 bg-red-900/30 border border-red-600/50 rounded-md p-3">
                        <div class="flex items-center gap-2">
                            <i class="bi bi-exclamation-triangle-fill text-red-400 animate-pulse"></i>
                            <p class="text-red-300 text-sm font-medium">
                                Critical: Link expires in less than 15 minutes!
                            </p>
                        </div>
                        <p class="text-red-200 text-xs mt-1">
                            Submit the form immediately to avoid losing access.
                        </p>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <div class="flex items-center space-x-4 mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-white">
                        Welcome to <?php echo e($organization); ?>!
                    </h1>
                </div>
            </div>

            
            <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
                <div class="mt-4 bg-red-900/50 border border-red-500/50 rounded-md p-4">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="bi bi-exclamation-triangle-fill text-red-400 text-lg"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm text-red-300"><?php echo e(session('error')); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <form wire:submit="save" @submit="if(!validateForm()) { $event.preventDefault(); }"
                class="mt-8 grid grid-cols-1 gap-8">

                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-person-vcard"></i> Personal Details
                    </h2>
                    <div class="p-6 space-y-6">
                        
                        <div x-data="imageCropperComponent()" wire:key="alpine-image-cropper"
                            class="flex flex-col items-center space-y-4">
                            <input type="file" class="hidden" x-ref="fileInput" @change="handleFileSelect"
                                accept="image/png, image/jpeg, image/gif">
                            <div class="relative group w-36 h-36">
                                <div
                                    class="w-36 h-36 rounded-full mx-auto bg-slate-800 border-2 border-dashed border-slate-600 flex items-center justify-center overflow-hidden">
                                    <!--[if BLOCK]><![endif]--><?php if($Prfl_Pict): ?>
                                        <img src="<?php echo e($Prfl_Pict->temporaryUrl()); ?>" class="w-full h-full object-cover"
                                            alt="Profile Preview">
                                    <?php else: ?>
                                        <div @click="$refs.fileInput.click()"
                                            class="cursor-pointer w-full h-full flex flex-col items-center justify-center text-center p-2">
                                            <i class="bi bi-camera-fill text-3xl text-slate-500"></i>
                                            <span class="text-xs text-slate-500 mt-1">Upload Photo</span>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <!--[if BLOCK]><![endif]--><?php if($Prfl_Pict): ?>
                                    <div
                                        class="absolute inset-0 rounded-full bg-black/60 flex flex-col items-center justify-center space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                        <button type="button" @click.prevent="$refs.fileInput.click()"
                                            class="flex items-center gap-2 text-sm font-semibold text-green-200 hover:text-blue-300 transition-colors">
                                            <i class="bi bi-arrow-repeat"></i>
                                            <span>Change</span>
                                        </button>
                                        <button type="button" wire:click="removeProfilePicture"
                                            class="flex items-center gap-2 text-sm font-semibold text-green-200 hover:text-red-400 transition-colors">
                                            <i class="bi bi-trash"></i>
                                            <span>Clear</span>
                                        </button>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <span class="text-gray-400 text-xs -mt-2 block">upload file type : jpg/png </span>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Prfl_Pict'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <div x-show="showCropper" x-transition
                                class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
                                style="display: none;">
                                <div @click.away="closeCropper()"
                                    class="bg-slate-800 rounded-md shadow-xl w-full max-w-lg">
                                    <div class="p-6">
                                        <h3 class="text-lg font-medium text-green-200 mb-4">Crop Your Image</h3>
                                        <div class="w-full h-80 bg-slate-900">
                                            <img x-ref="imageToCropEl" :src="imageToCrop"
                                                class="max-w-full max-h-full block">
                                        </div>
                                    </div>
                                    <div
                                        class="px-6 py-4 bg-slate-900/50 flex justify-end items-center gap-4 rounded-b-lg">
                                        <button type="button" @click="closeCropper()"
                                            class="text-sm font-semibold text-white hover:text-green-200 transition-colors">
                                            Cancel
                                        </button>
                                        <button type="button" @click="cropImage()"
                                            class="figma-button-primary flex gap-2">
                                            <i class="bi bi-crop"></i> Apply
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label for="Prfx_UIN" class="text-sm font-medium text-white">Prefix</label>
                                <select id="Prfx_UIN" wire:model.live="Prfx_UIN"
                                    class="form-select-figma mt-1 <?php $__errorArgs = ['Prfx_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allPrefixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($prefix->Prfx_Name_UIN); ?>"
                                            title="<?php echo e($prefix->Prfx_Name_Desp ?? ''); ?>">
                                            <?php echo e($prefix->Prfx_Name ?? ''); ?>

                                            <?php echo e('[' . $prefix->Prfx_Name_Desp . ']' ?? ''); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Prfx_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label for="FaNm" class="text-sm font-medium text-white">
                                    First Name <span class="text-red-400">*</span>
                                </label>
                                <input type="text" id="FaNm" wire:model.blur="FaNm"
                                    x-on:input="$event.target.value = $event.target.value.replace(/[^a-zA-Z ]/g, '')"
                                    class="form-input-figma mt-1 <?php $__errorArgs = ['FaNm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['FaNm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label for="MiNm" class="text-sm font-medium text-white">Middle Name</label>
                                <input type="text" id="MiNm"
                                    x-on:input="$event.target.value = $event.target.value.replace(/[^a-zA-Z ]/g, '')"
                                    wire:model.blur="MiNm"
                                    class="form-input-figma mt-1 <?php $__errorArgs = ['MiNm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['MiNm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label for="LaNm" class="text-sm font-medium text-white">Last Name</label>
                                <input type="text" id="LaNm"
                                    x-on:input="$event.target.value = $event.target.value.replace(/[^a-zA-Z ]/g, '')"
                                    wire:model.blur="LaNm"
                                    class="form-input-figma mt-1 <?php $__errorArgs = ['LaNm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['LaNm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label for="Gend" class="text-sm font-medium text-white">
                                    Gender <span class="text-red-400">*</span>
                                </label>
                                <select id="Gend" wire:model.blur="Gend"
                                    class="form-select-figma mt-1 <?php $__errorArgs = ['Gend'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select...</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="transgender">Transgender</option>
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Gend'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label for="Blood_Grp" class="text-sm font-medium text-white">Blood Group</label>
                                <select id="Blood_Grp" wire:model.blur="Blood_Grp"
                                    class="form-select-figma mt-1 <?php $__errorArgs = ['Blood_Grp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select...</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Blood_Grp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label for="Brth_Dt" class="text-sm font-medium text-white">Date of Birth</label>
                                <input type="date" id="Brth_Dt" wire:model.blur="Brth_Dt"
                                    class="form-input-figma mt-1 <?php $__errorArgs = ['Brth_Dt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Brth_Dt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Contact Information Card -->
                <div class="figma-card rounded-2xl shadow-sm bg-slate-800/40 border border-slate-700">
                    <h2
                        class="figma-card-header text-lg font-semibold text-green-200 border-b border-slate-700 px-6 py-4">
                        <i class="bi bi-person-lines-fill mr-2"></i>Contact Information
                    </h2>
                    <div class="p-6 space-y-8">
                        <!-- Mobile Numbers -->
                        <div>
                            <h3
                                class="font-medium text-white mb-4 flex items-center gap-2 text-sm uppercase tracking-wide">
                                <i class="bi bi-telephone-fill text-blue-400"></i> Mobile Numbers
                            </h3>
                            <div class="space-y-4">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600"
                                        wire:key="phone-<?php echo e($index); ?>">
                                        <!-- Controls -->
                                        <div class="relative right-0 top-0 flex items-center justify-end gap-4 pb-2">
                                            <label for="primary_phone_<?php echo e($index); ?>"
                                                class="flex items-center cursor-pointer gap-2">
                                                <span class="text-sm font-medium text-white">Preferable</span>
                                                <input type="radio" id="primary_phone_<?php echo e($index); ?>"
                                                    name="primary_phone"
                                                    wire:click="setPrimaryPhone(<?php echo e($index); ?>)"
                                                    <?php if($phone['Is_Prmy'] ?? false): ?> checked <?php endif; ?>
                                                    class="form-radio-figma">
                                            </label>
                                            <!--[if BLOCK]><![endif]--><?php if(count($phones) > 1): ?>
                                                <button type="button" wire:click="removePhone(<?php echo e($index); ?>)"
                                                    wire:confirm="Are you sure you want to remove this mobile number?"
                                                    class="text-slate-500 hover:text-red-500 transition-colors">
                                                    <i class="bi bi-trash-fill text-lg"></i>
                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <!-- Phone Fields -->
                                        <div class="flex-grow grid grid-cols-1 sm:grid-cols-5 gap-3">
                                            <!-- Country Picker -->
                                            <div class="sm:col-span-2">
                                                <div wire:ignore>
                                                    <div x-data="countryPicker('<?php echo e($phone['Cutr_Code'] ?? ($allCountries[0]['Phon_Code'] ?? '91')); ?>', <?php echo e($index); ?>)" x-init="init()"
                                                        @primary-country-changed.window="updateFromPrimary($event.detail)"
                                                        class="relative">

                                                        <button type="button" @click="open = !open"
                                                            :aria-expanded="open"
                                                            class="form-select-figma text-sm w-full h-10 flex items-center justify-between px-3">
                                                            <span class="flex items-center gap-2 min-w-0">
                                                                <span x-show="selectedCountry"
                                                                    :class="`fi fi-${(selectedCountry?.Code || '').trim().toLowerCase()}`"></span>
                                                                <span x-show="selectedCountry"
                                                                    class="truncate max-w-[120px]"
                                                                    x-text="selectedCountry?.Name + ' +' +(selectedCountry?.Phon_Code || '').trim()"></span>
                                                            </span>
                                                            <i :class="{ 'rotate-180': open }"
                                                                class="bi bi-chevron-down text-gray-400 transition-transform"></i>
                                                        </button>
                                                        <div x-show="open" @click.outside="open = false"
                                                            x-transition:enter="transition ease-out duration-100"
                                                            x-transition:enter-start="opacity-0 scale-95"
                                                            x-transition:enter-end="opacity-100 scale-100"
                                                            x-transition:leave="transition ease-in duration-75"
                                                            x-transition:leave-start="opacity-100 scale-100"
                                                            x-transition:leave-end="opacity-0 scale-95"
                                                            class="absolute z-30 mt-1 w-full max-w-xs min-w-[220px] rounded-md bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 focus:outline-none">
                                                            <div
                                                                class="sticky top-0 z-10 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-2 pt-2 pb-1">
                                                                <input type="text" x-model="search" autofocus
                                                                    placeholder="Search country..."
                                                                    class="form-select-figma text-sm w-full px-2 py-1 mb-1 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100 border border-slate-300 dark:border-slate-600 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none">
                                                            </div>
                                                            <ul class="max-h-52 overflow-y-auto py-1">
                                                                <template x-for="(country, idx) in filteredCountries"
                                                                    :key="country.Code + '_' + idx">
                                                                    <li @click="choose(country); open = false;"
                                                                        :class="{
                                                                            'bg-blue-50 dark:bg-slate-700/60': selectedCountry &&
                                                                                selectedCountry.Code === country
                                                                                .Code,
                                                                            'hover:bg-slate-100 dark:hover:bg-slate-700': true
                                                                        }"
                                                                        class="flex items-center gap-x-3 px-3 py-2 text-sm cursor-pointer transition-colors select-none form-select-figma">
                                                                        <span
                                                                            :class="`fi fi-${(country?.Code || '').trim().toLowerCase()}`"></span>
                                                                        <span class="font-medium flex-1 truncate"
                                                                            x-text="country.Name"></span>
                                                                        <span class="text-gray-200"
                                                                            x-text="'+' + country.Phon_Code"></span>
                                                                        <span
                                                                            x-show="selectedCountry && selectedCountry.Code === country.Code"
                                                                            class="ml-2 text-blue-500"><i
                                                                                class="bi bi-check-circle-fill"></i></span>
                                                                    </li>
                                                                </template>
                                                                <li x-show="filteredCountries.length === 0"
                                                                    class="px-4 py-2 text-sm text-gray-500">No country
                                                                    found.</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Mobile Number -->
                                            <div class="sm:col-span-2">
                                                <input type="tel"
                                                    wire:model.live="phones.<?php echo e($index); ?>.Phon_Numb"
                                                    placeholder="Mobile Number"
                                                    class="form-input-figma text-sm w-full"
                                                    :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['phones.' . $index . '.Phon_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }"
                                                    x-on:input="$event.target.value = $event.target.value.replace(/[^0-9]/g, '')">
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phones.' . $index . '.Phon_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span
                                                        class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>

                                            <!-- Type -->
                                            <div class="sm:col-span-1 flex gap-3">
                                                <select wire:model.live="phones.<?php echo e($index); ?>.Phon_Type"
                                                    class="form-select-figma text-sm w-full"
                                                    :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['phones.' . $index . '.Phon_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                                    <option value="self">Self</option>
                                                    <option value="office">Office</option>
                                                    <option value="home">Home</option>
                                                </select>
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phones.' . $index . '.Phon_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span
                                                        class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                <!-- Messaging -->
                                                <div class="hidden md:flex md:flex-col gap-8 md:gap-2">
                                                    <label class="flex items-center gap-2 text-sm text-gray-200">
                                                        <input type="checkbox"
                                                            wire:model.live="phones.<?php echo e($index); ?>.Has_WtAp"
                                                            class="form-checkbox-figma">
                                                        <i class="bi bi-whatsapp text-green-400 text-xs"
                                                            title="WhatsApp"></i>
                                                    </label>
                                                    <label class="flex items-center gap-2 text-sm text-gray-200">
                                                        <input type="checkbox"
                                                            wire:model.live="phones.<?php echo e($index); ?>.Has_Telg"
                                                            class="form-checkbox-figma">
                                                        <i class="bi bi-telegram text-sky-400 text-xs"
                                                            title="Telegram"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="md:hidden flex gap-8 md:gap-2">
                                                <label class="flex items-center gap-2 text-sm text-gray-200">
                                                    <input type="checkbox"
                                                        wire:model.live="phones.<?php echo e($index); ?>.Has_WtAp"
                                                        class="form-checkbox-figma">
                                                    <i class="bi bi-whatsapp text-green-400 text-xs"
                                                        title="WhatsApp"></i>
                                                </label>
                                                <label class="flex items-center gap-2 text-sm text-gray-200">
                                                    <input type="checkbox"
                                                        wire:model.live="phones.<?php echo e($index); ?>.Has_Telg"
                                                        class="form-checkbox-figma">
                                                    <i class="bi bi-telegram text-sky-400 text-xs"
                                                        title="Telegram"></i>
                                                </label>
                                            </div>


                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-slate-500 text-sm pl-1">No mobile numbers added.</p>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if($this->canAdd('phones')): ?>
                                <button type="button" wire:click="addPhone" wire:loading.attr="disabled"
                                    class="mt-4 text-sm font-semibold capitalize text-blue-400 hover:text-blue-300 flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i> Add Mobile number
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Landline Numbers -->
                        <div>
                            <h3
                                class="font-medium text-white mb-4 flex items-center gap-2 text-sm uppercase tracking-wide">
                                <i class="bi bi-telephone text-purple-400"></i> <span>Landline Numbers</span>
                            </h3>
                            <div class="space-y-4">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $landlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $landline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div wire:key="landline-<?php echo e($index); ?>"
                                        class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600">

                                        <div class="relative right-0 top-0 flex items-center justify-end gap-4 pb-2">
                                            <label for="primary_landline_<?php echo e($index); ?>"
                                                class="flex items-center cursor-pointer gap-2">
                                                <span class="text-sm font-medium text-white">Preferable</span>
                                                <input type="radio" id="primary_landline_<?php echo e($index); ?>"
                                                    name="primary_landline"
                                                    wire:click="setPrimaryLandline(<?php echo e($index); ?>)"
                                                    <?php echo e($landline['Is_Prmy'] ?? false ? 'checked' : ''); ?>

                                                    class="form-radio-figma" />
                                            </label>
                                            <!--[if BLOCK]><![endif]--><?php if(count($landlines) > 1): ?>
                                                <button type="button"
                                                    wire:click="removeLandline(<?php echo e($index); ?>)"
                                                    class="text-slate-500 hover:text-red-500 transition-colors"
                                                    wire:confirm="Are you sure you want to remove this landline number?"
                                                    aria-label="Remove landline number">
                                                    <i class="bi bi-trash-fill text-lg"></i>
                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <div class="flex-grow grid grid-cols-1 sm:grid-cols-5 gap-3">

                                            <div class="sm:col-span-2">
                                                <div wire:ignore>
                                                    <div x-data="countryPicker('<?php echo e($landline['Cutr_Code'] ?? ($allCountries[0]['Phon_Code'] ?? '91')); ?>', <?php echo e($index); ?>, 'landlines')" x-init="init()"
                                                        @primary-country-changed.window="updateFromPrimary($event.detail)"
                                                        class="relative">

                                                        <button type="button" @click="open = !open"
                                                            :aria-expanded="open"
                                                            class="form-select-figma text-sm w-full h-10 flex items-center justify-between px-3">
                                                            <span class="flex items-center gap-2 min-w-0">
                                                                <span x-show="selectedCountry"
                                                                    :class="`fi fi-${(selectedCountry?.Code || '').trim().toLowerCase()}`"></span>
                                                                <span x-show="selectedCountry"
                                                                    class="truncate max-w-[120px]"
                                                                    x-text="selectedCountry?.Name + ' +' +(selectedCountry?.Phon_Code || '').trim()"></span>
                                                            </span>
                                                            <i :class="{ 'rotate-180': open }"
                                                                class="bi bi-chevron-down text-gray-400 transition-transform"></i>
                                                        </button>

                                                        <div x-show="open" @click.outside="open = false"
                                                            x-transition:enter="transition ease-out duration-100"
                                                            x-transition:enter-start="opacity-0 scale-95"
                                                            x-transition:enter-end="opacity-100 scale-100"
                                                            x-transition:leave="transition ease-in duration-75"
                                                            x-transition:leave-start="opacity-100 scale-100"
                                                            x-transition:leave-end="opacity-0 scale-95"
                                                            class="absolute z-30 mt-1 w-full max-w-xs min-w-[220px] rounded-md bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 focus:outline-none">
                                                            <div
                                                                class="sticky top-0 z-10 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-2 pt-2 pb-1">
                                                                <input type="text" x-model="search" autofocus
                                                                    placeholder="Search country..."
                                                                    class="form-select-figma text-sm w-full px-2 py-1 mb-1 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100 border border-slate-300 dark:border-slate-600 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none">
                                                            </div>
                                                            <ul class="max-h-52 overflow-y-auto py-1">
                                                                <template x-for="(country, idx) in filteredCountries"
                                                                    :key="country.Code + '_' + idx">
                                                                    <li @click="choose(country); open = false;"
                                                                        :class="{
                                                                            'bg-blue-50 dark:bg-slate-700/60': selectedCountry &&
                                                                                selectedCountry.Code === country
                                                                                .Code,
                                                                            'hover:bg-slate-100 dark:hover:bg-slate-700': true
                                                                        }"
                                                                        class="flex items-center gap-x-3 px-3 py-2 text-sm cursor-pointer transition-colors select-none form-select-figma">
                                                                        <span
                                                                            :class="`fi fi-${(country?.Code || '').trim().toLowerCase()}`"></span>
                                                                        <span class="font-medium flex-1 truncate"
                                                                            x-text="country.Name"></span>
                                                                        <span class="text-gray-200"
                                                                            x-text="'+' + country.Phon_Code"></span>
                                                                        <span
                                                                            x-show="selectedCountry && selectedCountry.Code === country.Code"
                                                                            class="ml-2 text-blue-500"><i
                                                                                class="bi bi-check-circle-fill"></i></span>
                                                                    </li>
                                                                </template>
                                                                <li x-show="filteredCountries.length === 0"
                                                                    class="px-4 py-2 text-sm text-gray-500">No country
                                                                    found.</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="sm:col-span-2">
                                                <input type="tel" id="landline_number_<?php echo e($index); ?>"
                                                    wire:model.live="landlines.<?php echo e($index); ?>.Land_Numb"
                                                    placeholder="Landline Number" maxlength="15"
                                                    class="form-input-figma text-sm w-full"
                                                    :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['landlines.' . $index . '.Land_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }"
                                                    x-on:input="$event.target.value = $event.target.value.replace(/[^0-9+]/g, '').replace(/(\+[0-9]{1,3}|[0-9]{1,15})/, '$1')"
                                                    autocomplete="tel" />
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['landlines.' . $index . '.Land_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span
                                                        class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>

                                            <div class="sm:col-span-1">
                                                <select id="landline_type_<?php echo e($index); ?>"
                                                    wire:model.live="landlines.<?php echo e($index); ?>.Land_Type"
                                                    class="form-select-figma text-sm w-full"
                                                    :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['landlines.' . $index . '.Land_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                                    <option value="home">Home</option>
                                                    <option value="office">Office</option>
                                                </select>
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['landlines.' . $index . '.Land_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span
                                                        class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-slate-500 text-sm pl-1 italic">No landline numbers added yet.</p>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!--[if BLOCK]><![endif]--><?php if($this->canAdd('landlines')): ?>
                                <button type="button" wire:click="addLandline" wire:loading.attr="disabled"
                                    class="mt-4 text-sm font-semibold capitalize text-blue-400 hover:text-blue-300 flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i> Add Landline number
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Emails -->
                        <div>
                            <h3
                                class="font-medium text-white mb-4 flex items-center gap-2 text-sm uppercase tracking-wide">
                                <i class="bi bi-envelope-fill text-green-400"></i> Email Addresses
                            </h3>
                            <div class="space-y-4">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600"
                                        wire:key="email-<?php echo e($index); ?>">
                                        <!-- Controls -->
                                        <div class="relative right-0 top-0 flex items-center justify-end gap-4 pb-2">
                                            <label for="primary_email_<?php echo e($index); ?>"
                                                class="flex items-center cursor-pointer gap-2">
                                                <span class="text-sm font-medium text-white">Preferable</span>
                                                <input type="radio" id="primary_email_<?php echo e($index); ?>"
                                                    name="primary_email"
                                                    wire:click="setPrimaryEmail(<?php echo e($index); ?>)"
                                                    <?php if($email['Is_Prmy'] ?? false): ?> checked <?php endif; ?>
                                                    class="form-radio-figma">
                                            </label>
                                            <!--[if BLOCK]><![endif]--><?php if(count($emails) > 1): ?>
                                                <button type="button" wire:click="removeEmail(<?php echo e($index); ?>)"
                                                    wire:confirm="Are you sure you want to remove this email?"
                                                    class="text-slate-500 hover:text-red-500 transition-colors">
                                                    <i class="bi bi-trash-fill text-lg"></i>
                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <!-- Email Fields -->
                                        <div class="flex-grow grid grid-cols-1 sm:grid-cols-3 gap-3">
                                            <div class="sm:col-span-2">
                                                <input type="email"
                                                    wire:model.live="emails.<?php echo e($index); ?>.Emai_Addr"
                                                    placeholder="example@domain.com"
                                                    class="form-input-figma text-sm w-full lowercase"
                                                    :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['emails.' . $index . '.Emai_Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['emails.' . $index . '.Emai_Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span
                                                        class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                            <select wire:model.blur="emails.<?php echo e($index); ?>.Emai_Type"
                                                class="form-select-figma text-sm w-full"
                                                :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['emails.' . $index . '.Emai_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                                <option value="Self Generated">Personal</option>
                                                <option value="Office">Office</option>
                                                <option value="Business">Business</option>
                                            </select>
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['emails.' . $index . '.Emai_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-slate-500 text-sm pl-1">No email addresses added.</p>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if($this->canAdd('emails')): ?>
                                <button type="button" wire:click="addEmail" wire:loading.attr="disabled"
                                    class="mt-4 text-sm font-semibold capitalize text-blue-400 hover:text-blue-300 flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i> Add Email
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-globe2 mr-2"></i>Web Presence</h2>
                    <div class="p-6 grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div class="relative">
                            <i
                                class="bi bi-globe text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="Web" placeholder="Website"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['Web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="bi bi-linkedin text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="LnDn" placeholder="LinkedIn"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['LnDn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['LnDn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="bi bi-twitter-x text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="Twtr" placeholder="Twitter / X"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['Twtr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Twtr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="bi bi-facebook text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="FcBk" placeholder="Facebook"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['FcBk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['FcBk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="bi bi-instagram text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="Intg" placeholder="Instagram"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['Intg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Intg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="bi bi-reddit text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="Redt" placeholder="Reddit"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['Redt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Redt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="bi bi-youtube text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="url" wire:model.live="Ytb" placeholder="YouTube"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['Ytb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Ytb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="relative">
                            <i
                                class="text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">Y!</i>
                            <input type="url" wire:model.live="Yaho" placeholder="Yahoo"
                                class="form-input-figma w-full pl-10 <?php $__errorArgs = ['Yaho'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Yaho'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-400 text-xs mt-1 ml-10 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-geo-alt-fill mr-2"></i>Address</h2>
                    <div class="p-6 space-y-6">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="relative p-5 rounded-md bg-slate-700/30 border border-slate-600"
                                wire:key="address-<?php echo e($index); ?>">
                                <div class="flex items-start justify-between gap-4 mb-4">
                                    <div class="flex-1">
                                        <label class="block text-sm mb-1 font-medium text-gray-100">Address
                                            Type</label>
                                        <select
                                            wire:model.blur="addresses.<?php echo e($index); ?>.Admn_Addr_Type_Mast_UIN"
                                            class="form-select-figma w-fit <?php $__errorArgs = ['addresses.' . $index . '.Admn_Addr_Type_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">Select</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $addressTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->Admn_Addr_Type_Mast_UIN); ?>">
                                                    <?php echo e($type->Name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Admn_Addr_Type_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="flex items-center gap-4 ">
                                        <label for="primary_address_<?php echo e($index); ?>"
                                            class="flex items-center cursor-pointer gap-2 whitespace-nowrap">
                                            <span class="text-sm font-medium text-white">Primary</span>
                                            <input type="radio" id="primary_address_<?php echo e($index); ?>"
                                                name="primary_address"
                                                wire:click="setPrimaryAddress(<?php echo e($index); ?>)"
                                                <?php if($address['Is_Prmy'] ?? false): ?> checked <?php endif; ?>
                                                class="form-radio-figma">
                                        </label>
                                        <!--[if BLOCK]><![endif]--><?php if(count($addresses) > 1): ?>
                                            <button type="button" wire:click="removeAddress(<?php echo e($index); ?>)"
                                                class="text-white hover:text-red-500 transition-colors"
                                                title="Remove Address">
                                                <i class="bi bi-trash-fill text-lg"></i>
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm mb-1 font-medium text-gray-100">Country</label>
                                        <select wire:model.live="addresses.<?php echo e($index); ?>.Admn_Cutr_Mast_UIN"
                                            class="form-select-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Admn_Cutr_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">Select Country...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->Admn_Cutr_Mast_UIN); ?>">
                                                    <?php echo e($country->Name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Admn_Cutr_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm mb-1 font-medium text-gray-100">State</label>
                                        <select wire:model.live="addresses.<?php echo e($index); ?>.Admn_Stat_Mast_UIN"
                                            class="form-select-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Admn_Stat_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            <?php if(empty($address['statesForDropdown'] ?? [])): ?> disabled <?php endif; ?>>
                                            <option value="">Select State...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $address['statesForDropdown'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($state['Admn_Stat_Mast_UIN']); ?>">
                                                    <?php echo e($state['Name']); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Admn_Stat_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm mb-1 font-medium text-gray-100">District</label>
                                        <select wire:model.live="addresses.<?php echo e($index); ?>.Admn_Dist_Mast_UIN"
                                            class="form-select-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Admn_Dist_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            <?php if(empty($address['districtsForDropdown'] ?? [])): ?> disabled <?php endif; ?>>
                                            <option value="">Select District...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $address['districtsForDropdown'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($district['Admn_Dist_Mast_UIN']); ?>">
                                                    <?php echo e($district['Name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Admn_Dist_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm mb-1 font-medium text-gray-100">Pincode</label>
                                        <select wire:model.live="addresses.<?php echo e($index); ?>.Admn_PinCode_Mast_UIN"
                                            class="form-select-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Admn_PinCode_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            <?php if(empty($address['pincodesForDropdown'] ?? [])): ?> disabled <?php endif; ?>>
                                            <option value="">Select Pincode...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $address['pincodesForDropdown'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pincode['Admn_PinCode_Mast_UIN']); ?>">
                                                    <?php echo e($pincode['Code']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Admn_PinCode_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm mb-1 font-medium text-gray-100">Landmark</label>
                                        <input type="text" wire:model.blur="addresses.<?php echo e($index); ?>.Lndm"
                                            class="form-input-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Lndm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Near By School, Petrol Pump, Hospital or Famous Place">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Lndm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label
                                            class="block text-sm mb-1 font-medium text-gray-100">Street/Locality</label>
                                        <input type="text" wire:model.blur="addresses.<?php echo e($index); ?>.Loca"
                                            class="form-input-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Loca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Area, Street, Sector, Village">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Loca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="sm:col-span-2">
                                        <label class="block text-sm mb-1 font-medium text-gray-100">Flat, House No,
                                            Building Name,
                                            Company</label>
                                        <textarea wire:model.blur="addresses.<?php echo e($index); ?>.Addr" rows="2"
                                            class="form-input-figma w-full <?php $__errorArgs = ['addresses.' . $index . '.Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Flat, House No, Building Name, Company..."></textarea>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['addresses.' . $index . '.Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->canAdd('addresses')): ?>
                            <button type="button" wire:click="addAddress"
                                class="text-sm font-semibold text-blue-500 hover:text-blue-300 transition-colors flex items-center gap-2">
                                <i class="bi bi-plus-circle"></i> Add Another Address
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-book-fill mr-2"></i>Education</h2>
                    <div class="p-6 space-y-6">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $this->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="relative p-5 border border-white/[.10] rounded-md"
                                wire:key="education-<?php echo e($index); ?>">
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                    <div>
                                        <label class="block text-sm font-medium text-white">Degree Name</label>
                                        <input type="text"
                                            wire:model.blur="educations.<?php echo e($index); ?>.Deg_Name"
                                            placeholder="Bachelor of Science"
                                            class="form-input-figma mt-1 <?php $__errorArgs = ['educations.' . $index . '.Deg_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['educations.' . $index . '.Deg_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-white">School / College /
                                            University /
                                            Institution
                                            Name</label>
                                        <input type="text"
                                            wire:model.blur="educations.<?php echo e($index); ?>.Inst_Name"
                                            placeholder="University Name"
                                            class="form-input-figma mt-1 <?php $__errorArgs = ['educations.' . $index . '.Inst_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['educations.' . $index . '.Inst_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-white">Completion Year</label>
                                        <input type="text" inputmode="numeric" pattern="[0-9]{4}" maxlength="4"
                                            wire:model.live="educations.<?php echo e($index); ?>.Cmpt_Year"
                                            placeholder="YYYY" class="form-input-figma mt-1">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-white">Country</label>
                                        <select wire:model="educations.<?php echo e($index); ?>.Admn_Cutr_Mast_UIN"
                                            class="form-input-figma mt-1">
                                            <option value="">Select Country</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->Admn_Cutr_Mast_UIN); ?>"><?php echo e($c->Name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                </div>
                                <div class="absolute top-4 right-4">
                                    <!--[if BLOCK]><![endif]--><?php if(count($this->educations) > 1 || true): ?>
                                        <button type="button" wire:click="removeEducation(<?php echo e($index); ?>)"
                                            class="text-slate-500 hover:text-red-500 transition-colors">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-slate-500 text-sm">No education added.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->canAdd('educations')): ?>
                            <button type="button" wire:click="addEducation"
                                class="text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-2">
                                <i class="bi bi-plus-circle"></i> Add Education
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['educations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-xs mt-2 block"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-star-fill mr-2"></i>Skills</h2>
                    <div class="p-6 space-y-6">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $this->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="relative p-5 border border-white/[.10] rounded-md"
                                wire:key="skill-<?php echo e($index); ?>">
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                    <div>
                                        <label class="block text-sm font-medium text-white">Worked On</label>
                                        <select wire:model.live="skills.<?php echo e($index); ?>.Skil_Type"
                                            class="form-select-figma w-full <?php $__errorArgs = ['skills.' . $index . '.Skil_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">..Select Worked On..</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skillTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <option value="Not in List">
                                                Not in List
                                            </option>
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['skills.' . $index . '.Skil_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <div class="flex items-center mb-1">
                                            <label class="block text-sm font-medium text-white">Proficiency
                                                Level</label>
                                            <span
                                                class="inline-block px-2 ml-2 py-0.5 bg-purple-500/20 text-purple-300 rounded text-xs font-semibold border border-purple-500/50">
                                                <?php echo e($skill['Profc_Lvl'] ?? 0); ?>/5
                                            </span>
                                        </div>
                                        <div class="flex items-center h-[42px]">
                                            <input type="range"
                                                wire:model.live="skills.<?php echo e($index); ?>.Profc_Lvl"
                                                min="1" max="5"
                                                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-500">
                                        </div>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-white">Skill Name</label>
                                        <select wire:model.live="skills.<?php echo e($index); ?>.Skil_Type_1"
                                            class="form-select-figma w-full">
                                            <option value="">Select Skill Name..</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skillSubtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subtype); ?>"><?php echo e($subtype); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <option value="Other">
                                                Other Skill
                                            </option>
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['skills.' . $index . '.Skil_Type_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-white">
                                            Enter Skill Name (if not found in the list)
                                            <!--[if BLOCK]><![endif]--><?php if($skill['Skil_Type_1'] === 'Other'): ?>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </label>
                                        <input type="text" wire:model.blur="skills.<?php echo e($index); ?>.Skil_Name"
                                            placeholder="Enter Skill Name.."
                                            <?php if($skill['Skil_Type_1'] !== 'Other'): ?> disabled <?php endif; ?>
                                            class="form-input-figma w-full disabled:bg-slate-700/50 disabled:text-slate-500 disabled:cursor-not-allowed <?php $__errorArgs = ['skills.' . $index . '.Skil_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['skills.' . $index . '.Skil_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                                <div class="absolute top-2 right-2">
                                    <button type="button" wire:click="removeSkill(<?php echo e($index); ?>)"
                                        class="p-2 text-slate-500 hover:text-red-500 transition-colors">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-slate-500 text-sm">No skills added.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->canAdd('skills')): ?>
                            <button type="button" wire:click="addSkill"
                                class="text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-2">
                                <i class="bi bi-plus-circle"></i> Add Skill
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['skills'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-xs mt-2 block"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Employment Card -->
                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-briefcase-fill mr-2"></i>Present
                        Employment</h2>
                    <div class="p-6 space-y-6">
                        <!-- Employment Type Toggle -->
                        <div class="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-xl">
                            <button type="button" wire:click="$set('Empl_Type', 'job')"
                                class="px-2 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200"
                                :class="{ 'bg-blue-600 text-green-200 shadow-md': <?php echo \Illuminate\Support\Js::from($Empl_Type)->toHtml() ?> === 'job', 'text-white hover:bg-slate-700': <?php echo \Illuminate\Support\Js::from($Empl_Type)->toHtml() ?> !== 'job' }">
                                Job
                            </button>
                            <button type="button" wire:click="$set('Empl_Type', 'self-employed')"
                                class="px-2 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200"
                                :class="{ 'bg-blue-600 text-green-200 shadow-md': <?php echo \Illuminate\Support\Js::from($Empl_Type)->toHtml() ?> === 'self-employed', 'text-white hover:bg-slate-700': <?php echo \Illuminate\Support\Js::from($Empl_Type)->toHtml() ?> !== 'self-employed' }">
                                Self Employed
                            </button>
                        </div>

                        <!-- Job Fields -->
                        <!--[if BLOCK]><![endif]--><?php if($Empl_Type === 'job'): ?>
                            <div class="space-y-5">
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                    <!-- Company Name -->
                                    <div>
                                        <label for="Comp_Name" class="text-sm font-medium text-white">Company
                                            Name</label>
                                        <input type="text" id="Comp_Name" wire:model.blur="Comp_Name"
                                            placeholder="e.g., ABC Corporation" class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- Designation -->
                                    <div>
                                        <label for="Comp_Dsig"
                                            class="text-sm font-medium text-white">Designation</label>
                                        <input type="text" id="Comp_Dsig" wire:model.blur="Comp_Dsig"
                                            placeholder="e.g., Senior Manager,Software Engineer"
                                            class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_Dsig'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_Dsig'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- Company Landline -->
                                    <div>
                                        <label for="Comp_LdLi" class="text-sm font-medium text-white">Company
                                            Landline</label>
                                        <input type="tel" id="Comp_LdLi" wire:model.live="Comp_LdLi"
                                            placeholder="e.g., 02012345678" class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_LdLi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }"
                                            x-on:input="$event.target.value = $event.target.value.replace(/[^0-9]/g, '')">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_LdLi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- Company Business Description -->
                                    <div>
                                        <label for="Comp_Desp" class="text-sm font-medium text-white">Company Business
                                            Description</label>
                                        <input type="text" id="Comp_Desp" wire:model.blur="Comp_Desp"
                                            placeholder="e.g., Software Development, Manufacturing"
                                            class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_Desp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_Desp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- Company Email -->
                                    <div>
                                        <label for="Comp_Emai" class="text-sm font-medium text-white">Company
                                            Email</label>
                                        <input type="email" id="Comp_Emai" wire:model.live="Comp_Emai"
                                            placeholder="e.g., info@company.com"
                                            class="form-input-figma mt-1 lowercase"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_Emai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_Emai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- Company Website -->
                                    <div>
                                        <label for="Comp_Web" class="text-sm font-medium text-white">Company
                                            Website</label>
                                        <input type="url" id="Comp_Web" wire:model.live="Comp_Web"
                                            placeholder="https://company.com" class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_Web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_Web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>

                                <!-- Company Address -->
                                <div>
                                    <label for="Comp_Addr" class="text-sm font-medium text-white">Company
                                        Address</label>
                                    <textarea id="Comp_Addr" wire:model.blur="Comp_Addr" rows="3"
                                        placeholder="Enter complete company address including street, city, state, and postal code"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Comp_Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }"></textarea>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Comp_Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- Self-Employed Fields -->
                        <!--[if BLOCK]><![endif]--><?php if($Empl_Type === 'self-employed'): ?>
                            <div class="space-y-5">
                                <!-- Profession/Service -->
                                <div>
                                    <label for="Prfl_Name" class="text-sm font-medium text-white">Profession /
                                        Service</label>
                                    <input type="text" id="Prfl_Name" wire:model.live="Prfl_Name"
                                        placeholder="e.g., Graphic Designer, Consultant, Freelance Developer"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Prfl_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Prfl_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <!-- Business Address -->
                                <div>
                                    <label for="Prfl_Addr" class="text-sm font-medium text-white">Business
                                        Address</label>
                                    <textarea id="Prfl_Addr" wire:model.live="Prfl_Addr" rows="3"
                                        placeholder="Enter your business address or work location" class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['Prfl_Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }"></textarea>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['Prfl_Addr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Work Experience Card -->
                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200"><i class="bi bi-briefcase-fill mr-2"></i>Past Working
                        Experience
                    </h2>
                    <div class="p-6 space-y-6">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $this->workExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="relative p-5 border border-white/[.10] rounded-md"
                                wire:key="work-<?php echo e($index); ?>">
                                <!-- Header -->
                                <div class="mb-4">
                                    <p class="text-white font-semibold">Previous Organization Details</p>
                                </div>

                                <!-- Organization & Designation -->
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-4">
                                    <!-- Organization -->
                                    <div>
                                        <label class="block text-sm font-medium text-white">Organization</label>
                                        <input type="text"
                                            wire:model.blur="workExperiences.<?php echo e($index); ?>.Orga_Name"
                                            placeholder="Company Name" class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': <?php $__errorArgs = ['workExperiences.' . $index . '.Orga_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> }">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['workExperiences.' . $index . '.Orga_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- Designation -->
                                    <div>
                                        <label class="block text-sm font-medium text-white">Designation</label>
                                        <input type="text"
                                            wire:model.blur="workExperiences.<?php echo e($index); ?>.Dsgn"
                                            placeholder="Job Title" class="form-input-figma mt-1">
                                    </div>
                                </div>

                                <!-- Dates & Type -->
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-4">
                                    <!-- From Date -->
                                    <div>
                                        <label class="block text-sm font-medium text-white">From</label>
                                        <input type="date"
                                            wire:model.blur="workExperiences.<?php echo e($index); ?>.Prd_From"
                                            class="form-input-figma mt-1">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['workExperiences.' . $index . '.Prd_From'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <!-- To Date -->
                                    <div>
                                        <label class="block text-sm font-medium text-white">To</label>
                                        <input type="date"
                                            wire:model.blur="workExperiences.<?php echo e($index); ?>.Prd_To"
                                            class="form-input-figma mt-1">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['workExperiences.' . $index . '.Prd_To'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>

                                <!-- Country & Description -->
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-4">
                                    <!-- Country -->
                                    <div>
                                        <label class="block text-sm font-medium text-white">Country</label>
                                        <select wire:model="workExperiences.<?php echo e($index); ?>.Admn_Cutr_Mast_UIN"
                                            class="form-input-figma mt-1">
                                            <option value="">Select Country</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->Admn_Cutr_Mast_UIN); ?>"><?php echo e($c->Name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <!-- Work Type -->
                                    <div>
                                        <label class="block text-sm font-medium text-white">Work Type</label>
                                        <select wire:model="workExperiences.<?php echo e($index); ?>.Work_Type"
                                            class="form-input-figma mt-1">
                                            <option value="">Select Work Type...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $workTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type); ?>">
                                                    <?php echo e($type); ?> (<?php echo e($title); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>

                                </div>

                                <!-- Job Description -->
                                <div>
                                    <label class="block text-sm font-medium text-white">Job Description</label>
                                    <input type="text"
                                        wire:model.blur="workExperiences.<?php echo e($index); ?>.Job_Desp"
                                        placeholder="Key responsibilities..."
                                        class="form-input-figma mt-1 resize-none"></textarea>
                                </div>
                                <!-- Delete Button -->
                                <div class="absolute top-4 right-4">
                                    <button type="button" wire:click="removeWorkExperience(<?php echo e($index); ?>)"
                                        class="text-slate-500 hover:text-red-500 transition-colors">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-slate-500 text-sm">No work experience added.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if($this->canAdd('workExperiences')): ?>
                            <button type="button" wire:click="addWorkExperience" wire:loading.attr="disabled"
                                class="mt-4 text-sm font-semibold capitalize text-blue-400 hover:text-blue-300 flex items-center gap-2">
                                <i class="bi bi-plus-circle"></i> Add Experience
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['workExperiences'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-400 text-xs mt-2 block"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Bank Accounts Card -->
                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200">
                        <i class="bi bi-bank mr-2"></i> Bank Accounts
                    </h2>
                    <div class="p-4 sm:p-6 space-y-6">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-4 sm:p-5 rounded-md bg-slate-700/30 border border-slate-600"
                                wire:key="bank-<?php echo e($index); ?>">
                                <div class="flex items-center justify-between mb-4 gap-4">
                                    <div class="flex-1"></div>
                                    <div class="flex items-center gap-4">
                                        <label for="primary_bank_<?php echo e($index); ?>"
                                            class="flex items-center cursor-pointer gap-2 whitespace-nowrap">
                                            <span class="text-sm font-medium text-white">Primary</span>
                                            <input type="radio" id="primary_bank_<?php echo e($index); ?>"
                                                name="primary_bank" wire:click="setPrimaryBank(<?php echo e($index); ?>)"
                                                <?php if($bank['Prmy'] ?? false): ?> checked <?php endif; ?>
                                                class="form-radio-figma">
                                        </label>
                                        <!--[if BLOCK]><![endif]--><?php if(count($bankAccounts) > 1): ?>
                                            <button type="button" wire:click="removeBank(<?php echo e($index); ?>)"
                                                wire:confirm="Are you sure you want to remove this bank account? This action cannot be undone."
                                                class="text-gray-200 hover:text-red-500 transition-colors p-2 rounded hover:bg-red-500/10"
                                                title="Remove Bank">
                                                <i class="bi bi-trash-fill text-lg"></i>
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Bank Name
                                        </label>
                                        <select wire:model.live="bankAccounts.<?php echo e($index); ?>.Bank_Name_UIN"
                                            class="form-select-figma w-full text-sm">
                                            <option value="">Select Bank...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bankOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($option->Bank_UIN); ?>"><?php echo e($option->Bank_Name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.Bank_Name_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Branch Name
                                        </label>
                                        <input type="text"
                                            wire:model.blur="bankAccounts.<?php echo e($index); ?>.Bank_Brnc_Name"
                                            class="form-input-figma w-full text-sm" placeholder="Enter branch name">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.Bank_Brnc_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Account Type
                                        </label>
                                        <select wire:model.live="bankAccounts.<?php echo e($index); ?>.Acnt_Type"
                                            class="form-select-figma w-full text-sm">
                                              <option value="" disabled selected>Select Type...</option>
                                            <option value="Savings Account">Savings Account</option>
                                            <option value="Current Account">Current Account</option>
                                            <option value="Fixed Deposit Account">Fixed Deposit Account</option>
                                            <option value="Recurring Deposit Account">Recurring Deposit Account
                                            </option>
                                            <option value="NRI Account">NRI Account</option>
                                            <option value="Salary Account">Salary Account</option>
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.Acnt_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block flex items-center gap-1">
                                                <i class="bi bi-exclamation-circle-fill"></i> <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Account Number
                                        </label>
                                        <input type="text"
                                            wire:model.live.debounce.500ms="bankAccounts.<?php echo e($index); ?>.Acnt_Numb"
                                            class="form-input-figma w-full text-sm <?php $__errorArgs = ['bankAccounts.' . $index . '.Acnt_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Enter account number">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.Acnt_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block flex items-center gap-1">
                                                <i class="bi bi-exclamation-circle-fill"></i> <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Indian Financial System Code (IFSC)
                                        </label>
                                        <input type="text"
                                            wire:model.blur="bankAccounts.<?php echo e($index); ?>.IFSC_Code"
                                            class="form-input-figma w-full text-sm"
                                            placeholder="e.g., SBIN0001234(11 Characters)">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.IFSC_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Society for Worldwide Interbank Financial Telecommunication (SWIFT) Code
                                        </label>
                                        <input type="text"
                                            wire:model.blur="bankAccounts.<?php echo e($index); ?>.Swift_Code"
                                            class="form-input-figma w-full text-sm"
                                            placeholder="e.g., SBININBB123(11 or 8 Characters)">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.Swift_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="col-span-1 sm:col-span-2">
                                        <div class="flex items-start gap-3">
                                            <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                                Attachments
                                                <span class="text-gray-400 text-xs block mt-1">
                                                    (PDF/JPG/PNG - Max 100KB per file)
                                                </span>
                                            </label>
                                            <label for="bank-attachment-<?php echo e($index); ?>"
                                                class="flex-shrink-0 pt-3 text-blue-400 hover:text-blue-300 cursor-pointer transition mt-0.5"
                                                title="Click to upload attachment">
                                                <i class="bi bi-paperclip text-lg"></i>
                                            </label>
                                        </div>
                                        <input type="file"
                                            wire:model.live="bankAccounts.<?php echo e($index); ?>.temp_upload"
                                            id="bank-attachment-<?php echo e($index); ?>" accept=".pdf,.jpg,.png,.webp"
                                            multiple class="hidden">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bankAccounts.' . $index . '.newAttachments.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div
                                                class="mt-2 text-red-400 text-xs bg-red-900/20 p-2.5 rounded border border-red-600/30 flex items-start gap-2">
                                                <i class="bi bi-exclamation-circle-fill flex-shrink-0 mt-0.5"></i>
                                                <span><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if(!empty($bank['newAttachments'])): ?>
                                            <div class="mt-3 space-y-1.5">
                                                <p class="text-xs text-slate-400 font-medium">Files staged for upload:
                                                </p>
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bank['newAttachments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachmentIndex => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="mt-2 p-2.5 text-xs sm:text-sm text-blue-300 bg-blue-900/20 border border-blue-600/30 rounded flex items-center justify-between gap-2"
                                                        wire:key="bank-<?php echo e($index); ?>-new-att-<?php echo e($attachmentIndex); ?>">
                                                        <div class="flex items-center gap-2 flex-1 min-w-0">
                                                            <i class="bi bi-check-circle-fill flex-shrink-0"></i>
                                                            <div class="flex-1 min-w-0">
                                                                <p class="font-medium truncate">
                                                                    <?php echo e($attachment->getClientOriginalName()); ?>

                                                                </p>
                                                                <p class="text-gray-400 text-xs">
                                                                    <?php echo e(round($attachment->getSize() / 1024, 1)); ?> KB
                                                                    (Ready to upload)
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <button type="button"
                                                            wire:click="removeNewAttachment(<?php echo e($index); ?>, <?php echo e($attachmentIndex); ?>)"
                                                            class="text-blue-400 hover:text-red-400 transition-colors text-lg px-2 flex-shrink-0"
                                                            title="Remove file">
                                                            &times;
                                                        </button>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-slate-500 text-sm text-center py-4">No bank accounts added.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->canAdd('banks')): ?>
                            <button type="button" wire:click="addBank"
                                class="w-full sm:w-auto text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center justify-center sm:justify-start gap-2 px-4 py-2.5 hover:bg-blue-600/10 rounded transition">
                                <i class="bi bi-plus-circle"></i> Add Bank Account
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="figma-card">
                    <h2 class="figma-card-header text-green-200">
                        <i class="bi bi-file-earmark-pdf mr-2"></i> Documents
                    </h2>
                    <div class="p-4 sm:p-6 space-y-6">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-4 sm:p-5 rounded-md bg-slate-700/30 border border-slate-600"
                                wire:key="document-<?php echo e($index); ?>">
                                <div class="flex items-center justify-between mb-4 gap-4">
                                    <div class="flex-1"></div>
                                    <div class="flex items-center gap-4">
                                        <label for="primary_doc_<?php echo e($index); ?>"
                                            class="flex items-center cursor-pointer gap-2 whitespace-nowrap">
                                            <span class="text-sm font-medium text-white">Primary</span>
                                            <input type="radio" id="primary_doc_<?php echo e($index); ?>"
                                                name="primary_doc"
                                                wire:click="setPrimaryDocument(<?php echo e($index); ?>)"
                                                <?php if($document['Prmy'] ?? false): ?> checked <?php endif; ?>
                                                class="form-radio-figma">
                                        </label>
                                        <!--[if BLOCK]><![endif]--><?php if(count($documents) > 1): ?>
                                            <button type="button" wire:click="removeDocument(<?php echo e($index); ?>)"
                                                wire:confirm="Are you sure you want to remove this document? This action cannot be undone."
                                                class="text-gray-200 hover:text-red-500 transition-colors p-2 rounded hover:bg-red-500/10"
                                                title="Remove Document">
                                                <i class="bi bi-trash-fill text-lg"></i>
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                                    <div class="col-span-1 sm:col-span-2">
                                        <label class="block text-sm mb-2 font-medium text-gray-100">
                                            Document Types
                                        </label>
                                        <!--[if BLOCK]><![endif]--><?php if(!empty($document['selected_types'])): ?>
                                            <div class="flex flex-wrap gap-2 mb-3">
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $document['selected_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $docType = collect($allDocumentTypes)->firstWhere(
                                                            'Admn_Docu_Type_Mast_UIN',
                                                            $typeId,
                                                        );
                                                    ?>
                                                    <!--[if BLOCK]><![endif]--><?php if($docType): ?>
                                                        <div wire:key="chip-<?php echo e($index); ?>-<?php echo e($typeId); ?>"
                                                            class="inline-flex items-center gap-2 px-3 py-1 bg-blue-600/20 text-blue-300 rounded-full text-xs sm:text-sm border border-blue-600/30">
                                                            <span class="truncate"><?php echo e($docType->Docu_Name); ?></span>
                                                            <button type="button"
                                                                wire:click="removeDocumentType(<?php echo e($index); ?>, <?php echo e($typeId); ?>)"
                                                                class="text-blue-400 hover:text-red-400 transition-colors flex-shrink-0"
                                                                title="Remove type">
                                                                <i class="bi bi-x-circle-fill text-xs"></i>
                                                            </button>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <div x-data="{ open: false }" @click.away="open = false" class="relative">
                                            <button type="button" @click="open = !open"
                                                class="form-select-figma w-full text-left flex items-center justify-between text-sm sm:text-base">
                                                <span class="text-gray-400 truncate">
                                                    <!--[if BLOCK]><![endif]--><?php if(empty($document['selected_types'])): ?>
                                                        Select types...
                                                    <?php else: ?>
                                                        <?php echo e(count($document['selected_types'])); ?> selected
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                                <i class="bi bi-chevron-down flex-shrink-0 ml-2"></i>
                                            </button>
                                            <div x-show="open" x-transition:enter="transition ease-out duration-200"
                                                x-transition:enter-start="transform opacity-0 scale-95"
                                                x-transition:enter-end="transform opacity-100 scale-100"
                                                x-transition:leave="transition ease-in duration-75"
                                                x-transition:leave-start="transform opacity-100 scale-100"
                                                x-transition:leave-end="transform opacity-0 scale-95"
                                                class="absolute z-50 mt-2 w-full rounded-md bg-slate-800 shadow-xl border border-slate-600 max-h-48 sm:max-h-60 overflow-auto left-0 right-0">
                                                <div class="py-1">
                                                    <!--[if BLOCK]><![endif]--><?php $__empty_2 = true; $__currentLoopData = $allDocumentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <!--[if BLOCK]><![endif]--><?php if(!in_array($docType->Admn_Docu_Type_Mast_UIN, $document['selected_types'] ?? [])): ?>
                                                            <button type="button"
                                                                wire:click="selectDocumentType(<?php echo e($index); ?>, <?php echo e($docType->Admn_Docu_Type_Mast_UIN); ?>)"
                                                                @click="open = false"
                                                                class="w-full text-left px-3 sm:px-4 py-2.5 sm:py-2 text-sm text-gray-300 hover:bg-slate-700 hover:text-white transition-colors flex items-center gap-2 active:bg-slate-600">
                                                                <i
                                                                    class="bi bi-plus-circle text-xs text-gray-500 flex-shrink-0"></i>
                                                                <span
                                                                    class="truncate"><?php echo e($docType->Docu_Name); ?></span>
                                                            </button>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                        <div class="px-3 sm:px-4 py-2 text-sm text-gray-500">
                                                            No document types available
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        </div>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.selected_types'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-2 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Document Name
                                        </label>
                                        <select wire:model.blur="documents.<?php echo e($index); ?>.Docu_Name"
                                            class="form-select-figma w-full text-sm">
                                            <option value="">Select...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $documentNameOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Docu_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Registration / Reference Number
                                        </label>
                                        <input type="text"
                                            wire:model.blur="documents.<?php echo e($index); ?>.Regn_Numb"
                                            class="form-input-figma w-full text-sm" placeholder="Enter number">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Regn_Numb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Country
                                        </label>
                                        <select wire:model="documents.<?php echo e($index); ?>.Admn_Cutr_Mast_UIN"
                                            class="form-select-figma w-full text-sm">
                                            <option value="">Select Country...</option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->Admn_Cutr_Mast_UIN); ?>">
                                                    <?php echo e($country->Name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Admn_Cutr_Mast_UIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Authority Issued
                                        </label>
                                        <input type="text"
                                            wire:model.blur="documents.<?php echo e($index); ?>.Auth_Issd"
                                            class="form-input-figma w-full text-sm"
                                            placeholder="e.g., Ministry of XYZ">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Auth_Issd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Valid From
                                        </label>
                                        <input type="date"
                                            wire:model.blur="documents.<?php echo e($index); ?>.Vald_From"
                                            class="form-input-figma w-full text-sm">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Vald_From'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div>
                                        <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                            Valid Upto
                                        </label>
                                        <input type="date"
                                            wire:model.blur="documents.<?php echo e($index); ?>.Vald_Upto"
                                            class="form-input-figma w-full text-sm">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Vald_Upto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-400 text-xs mt-1 block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="col-span-1 sm:col-span-2">
                                        <div class="flex items-start gap-3">
                                            <label class="block text-xs sm:text-sm mb-1.5 font-medium text-gray-100">
                                                Document Attachment
                                                <span class="text-gray-400 text-xs block mt-1">
                                                    (PDF/JPG/PNG/WEBP - Max 200KB)
                                                </span>
                                            </label>
                                            <label for="doc-upload-<?php echo e($index); ?>"
                                                class="flex-shrink-0 pt-3 text-blue-400 hover:text-blue-300 cursor-pointer transition mt-0.5"
                                                title="Click to upload document">
                                                <i class="bi bi-paperclip text-lg"></i>
                                            </label>
                                        </div>
                                        <input type="file"
                                            wire:model.live="documents.<?php echo e($index); ?>.Docu_Atch_Path"
                                            accept=".pdf,.jpg,.png,.webp" id="doc-upload-<?php echo e($index); ?>"
                                            class="hidden">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['documents.' . $index . '.Docu_Atch_Path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div
                                                class="mt-2 text-red-400 text-xs bg-red-900/20 p-2.5 rounded border border-red-600/30 flex items-start gap-2">
                                                <i class="bi bi-exclamation-circle-fill flex-shrink-0 mt-0.5"></i>
                                                <span><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if(!empty($document['Docu_Atch_Path']) && is_object($document['Docu_Atch_Path'])): ?>
                                            <div
                                                class="mt-2 p-2.5 text-xs sm:text-sm text-blue-300 bg-blue-900/20 border border-blue-600/30 rounded flex items-center justify-between gap-2">
                                                <div class="flex items-center gap-2 flex-1 min-w-0">
                                                    <i class="bi bi-check-circle-fill flex-shrink-0"></i>
                                                    <div class="flex-1 min-w-0">
                                                        <p class="font-medium truncate">
                                                            <?php echo e($document['Docu_Atch_Path']->getClientOriginalName()); ?>

                                                        </p>
                                                        <p class="text-gray-400 text-xs">
                                                            <?php echo e(round($document['Docu_Atch_Path']->getSize() / 1024, 1)); ?>

                                                            KB (Ready to upload)
                                                        </p>
                                                    </div>
                                                </div>
                                                <button type="button"
                                                    wire:click="clearDocumentFile(<?php echo e($index); ?>)"
                                                    class="text-blue-400 hover:text-red-400 transition-colors text-lg px-2 flex-shrink-0"
                                                    title="Remove file">
                                                    &times;
                                                </button>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-slate-500 text-sm text-center py-4">No documents added.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->canAdd('documents')): ?>
                            <button type="button" wire:click="addDocument"
                                class="w-full sm:w-auto text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center justify-center sm:justify-start gap-2 px-4 py-2.5 hover:bg-blue-600/10 rounded transition">
                                <i class="bi bi-plus-circle"></i> Add Document
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                
                <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
                    <div class="mt-6 bg-red-900/50 border border-red-500/50 rounded-md p-6" id="error-section">
                        <div class="flex items-start">
                            <div class="flex-shrink-0">
                                <i class="bi bi-exclamation-triangle-fill text-red-400 text-2xl"></i>
                            </div>
                            <div class="ml-4 flex-1">
                                <?php
                                    // Filter duplicate error messages
                                    $uniqueErrors = array_unique($errors->all());
                                ?>

                                <h3 class="text-lg font-semibold text-red-300 mb-4">
                                    Please review the errors highlighted in red below your entered data:
                                </h3>
                                <div class="space-y-3 max-h-96 overflow-y-auto pr-2">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $uniqueErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-start gap-2 bg-red-900/30 p-3 rounded-md">
                                            <i class="bi bi-x-circle text-red-400 mt-0.5"></i>
                                            <span class="text-sm text-red-200"><?php echo e($error); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="flex justify-end items-center gap-4 mt-6">
                    <button type="submit" class="figma-button-primary">
                        <div wire:loading.remove wire:target="save">
                            <i class="bi bi-person-fill-add"></i>
                            <span>Submit</span>
                        </div>
                        <div wire:loading wire:target="save">
                            <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline-block"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10"
                                    stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor"
                                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                                </path>
                            </svg>
                            <span>Saving...</span>
                        </div>
                    </button>
                </div>
            </form>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<?php $__env->startPush('scripts'); ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css">

    
    <script>
        function linkExpiryTimer(expiryTime) {
            return {
                timeLeft: {
                    total: 0,
                    hours: 0,
                    minutes: 0,
                    seconds: 0
                },
                expiryDate: '',
                interval: null,
                init() {
                    const expiry = new Date(expiryTime);
                    this.expiryDate = expiry.toLocaleDateString() + ' at ' + expiry.toLocaleTimeString();
                    this.updateTimer();
                    this.interval = setInterval(() => {
                        this.updateTimer();
                    }, 1000);
                },
                updateTimer() {
                    const now = new Date().getTime();
                    const expiry = new Date(this.expiryTime || expiryTime).getTime();
                    const distance = expiry - now;

                    if (distance < 0) {
                        this.timeLeft = {
                            total: 0,
                            hours: 0,
                            minutes: 0,
                            seconds: 0
                        };
                        if (this.interval) {
                            clearInterval(this.interval);
                        }
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                        return;
                    }

                    this.timeLeft = {
                        total: distance,
                        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
                        seconds: Math.floor((distance % (1000 * 60)) / 1000)
                    };
                },
                destroy() {
                    if (this.interval) {
                        clearInterval(this.interval);
                    }
                }
            }
        }
    </script>

    
    <script>
        function imageCropperComponent() {
            return {
                showCropper: false,
                imageToCrop: null,
                cropper: null,
                handleFileSelect(event) {
                    const file = event.target.files[0];
                    if (!file) return;

                    const reader = new FileReader();
                    reader.onload = (e) => {
                        this.imageToCrop = e.target.result;
                        this.showCropper = true;
                        this.$nextTick(() => this.initCropper());
                    };
                    reader.readAsDataURL(file);
                },
                initCropper() {
                    if (this.cropper) this.cropper.destroy();
                    this.cropper = new Cropper(this.$refs.imageToCropEl, {
                        aspectRatio: 1,
                        viewMode: 1,
                        autoCropArea: 1
                    });
                },
                cropImage() {
                    let canvas = this.cropper.getCroppedCanvas({
                        width: 400,
                        height: 400
                    });

                    // CHANGE: Use 'image/jpeg' and quality 0.8 (0 to 1)
                    // 0.8 usually results in a 512x512 image being ~40kb-70kb
                    canvas.toBlob((blob) => {
                        // Change extension to .jpg
                        const file = new File([blob], 'cropped-avatar.jpg', {
                            type: 'image/jpeg'
                        });

                        // Upload
                        this.$wire.upload('Prfl_Pict', file, () => this.closeCropper());
                    }, 'image/jpeg', 0.8); // <--- Quality Parameter
                },
                closeCropper() {
                    this.showCropper = false;
                    if (this.cropper) {
                        this.cropper.destroy();
                        this.cropper = null;
                    }
                    if (this.$refs.fileInput) {
                        this.$refs.fileInput.value = "";
                    }
                }
            }
        }
    </script>

    
    <script>
        const allCountries = <?php echo json_encode($allCountries ? $allCountries->toArray() : [], 15, 512) ?>;

        function countryPicker(initialCode, livewireIndex, type = 'phones') {
            return {
                open: false,
                search: '',
                selectedCountry: null,
                fieldType: type, // 'phones' or 'landlines'

                getPhoneInput() {
                    const selector = this.fieldType === 'landlines' ?
                        `input[wire\\:model\\.live="landlines.${livewireIndex}.Land_Numb"]` :
                        `input[wire\\:model\\.live="phones.${livewireIndex}.Phon_Numb"]`;
                    return this.$el.closest('.grid')?.querySelector(selector);
                },

                updateMaxLength(country) {
                    const phoneInput = this.getPhoneInput();
                    if (phoneInput && country) {
                        phoneInput.maxLength = country.MoNo_Digt || 15;
                    }
                },

                init() {
                    this.selectedCountry = allCountries.find(c => c.Phon_Code == initialCode) ||
                        allCountries.find(c => c.Phon_Code == '91') ||
                        allCountries[0];
                    if (this.selectedCountry) {
                        // Update the correct Livewire property based on type
                        const cutrCodePath = `${this.fieldType}.${livewireIndex}.Cutr_Code`;
                        this.$wire.set(cutrCodePath, this.selectedCountry.Phon_Code);
                        this.$nextTick(() => this.updateMaxLength(this.selectedCountry));
                    }
                },

                get filteredCountries() {
                    if (!this.search) return allCountries;
                    const q = this.search.toLowerCase();
                    return allCountries.filter(c =>
                        c.Name.toLowerCase().includes(q) ||
                        c.Phon_Code.includes(this.search) ||
                        c.Code.toLowerCase().includes(q)
                    );
                },

                choose(country) {
                    this.selectedCountry = country;
                    this.open = false;
                    this.search = '';
                    // Update the correct Livewire property based on type
                    const cutrCodePath = `${this.fieldType}.${livewireIndex}.Cutr_Code`;
                    this.$wire.set(cutrCodePath, country.Phon_Code);
                    this.updateMaxLength(country);
                },

                updateFromPrimary(detail) {
                    const newCode = detail.newPhoneCode;
                    const newCountry = allCountries.find(c => c.Phon_Code == newCode);
                    if (newCountry) {
                        this.selectedCountry = newCountry;
                        const cutrCodePath = `${this.fieldType}.${livewireIndex}.Cutr_Code`;
                        this.$wire.set(cutrCodePath, newCountry.Phon_Code);
                        this.updateMaxLength(newCountry);
                    }
                }
            }
        }
    </script>

    
    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('save-success', (data) => {
                console.log('Contact saved successfully:', data);
            });

            Livewire.on('save-failed', (errors) => {
                console.error('Contact save failed:', errors);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php if (! $__env->hasRenderedOnce('7fa5b64e-f9d1-4442-8fae-3e902362f896')): $__env->markAsRenderedOnce('7fa5b64e-f9d1-4442-8fae-3e902362f896'); ?>
    <script>
        function contactFormValidator() {
            return {
                touchedFields: {},

                markTouched(field) {
                    this.touchedFields[field] = true;
                },
            }
        }
    </script>
<?php endif; ?><?php /**PATH /home/u625055691/domains/admin.partakedigital.com/public_html/admin/resources/views/livewire/contacts/create-by-link.blade.php ENDPATH**/ ?>