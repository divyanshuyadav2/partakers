<div class="m-2">
    <div class="max-w-6xl mx-auto py-6 sm:px-4">
        
        <div class="flex items-center justify-between mb-4">
            <div class="flex space-x-3">
                <a href="<?php echo e(route('contacts.index')); ?>" class="text-green-200 hover:text-white">
                    <i class="bi bi-arrow-left text-lg ml-4"></i>
                </a>
            </div>
        </div>

        
        <?php
            $sectionHeaderClass = 'text-md font-semibold text-purple-300 mb-3 flex items-center gap-2';
            $labelClass = 'text-cyan-400 text-sm font-semibold';
            $subHeading = 'text-sm font-semibold';
            $dataClass = 'text-green-200 text-sm';
            // Unified wrapper for Label + Value pairs to ensure consistent gap
            $fieldWrapperClass = 'flex nowrap gap-1 items-baseline';
        ?>

        <div class="space-y-4">
            
            <?php
                $hasQuickFields =
                    $contact->Gend ||
                    ($contact->Prty === 'I' && $contact->Blood_Grp) ||
                    $contact->Brth_Dt ||
                    ($contact->Prty === 'I' && $contact->Anvy_Dt) ||
                    ($contact->Prty === 'I' && $contact->Deth_Dt);
            ?>
            <div class="figma-card bg-slate-600/40">
                <div class="flex items-center space-x-6 pl-2 m-4">

                    
                    <div x-data="{ showAvatarModal: false }">
                        <!--[if BLOCK]><![endif]--><?php if($contact->avatar_url): ?>
                            <img src="<?php echo e($contact->avatar_url); ?>" @click="showAvatarModal = true"
                                class="w-20 h-20 rounded-full border border-slate-600 cursor-pointer hover:opacity-90 transition"
                                alt="Profile Avatar">

                            <div x-show="showAvatarModal" style="display: none;" x-transition.opacity
                                class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-80">
                                <button @click="showAvatarModal = false"
                                    class="absolute top-5 right-5 text-white hover:text-gray-300 focus:outline-none">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="2" stroke="currentColor" class="w-8 h-8">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>

                                <img @click.outside="showAvatarModal = false" src="<?php echo e($contact->avatar_url); ?>"
                                    class="max-w-full max-h-screen rounded shadow-lg object-contain">
                            </div>
                        <?php else: ?>
                            <div class="w-20 h-20 rounded-full border border-slate-600 flex items-center justify-center"
                                style="background-color: <?php echo e($contact->avatar_color ?? '#334155'); ?>">
                                <span class="text-white text-lg font-bold"><?php echo e($contact->initials); ?></span>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    
                    <div class="flex-1">
                        <!--[if BLOCK]><![endif]--><?php if($hasQuickFields): ?>
                            <div class="mb-1">
                                <h1 class="text-xl font-normal text-green-200">
                                    <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                                        <?php echo e($contact->FaNm); ?>

                                    <?php else: ?>
                                        <?php echo e(collect([$prefixName, $contact->FaNm, $contact->MiNm, $contact->LaNm])->filter()->implode(' ')); ?>

                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </h1>
                            </div>

                            
                            <div class="flex flex-row gap-x-6 gap-y-1 flex-wrap">

                                
                                <!--[if BLOCK]><![endif]--><?php if($contact->Gend): ?>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">
                                            <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                                                Organization Type:
                                            <?php else: ?>
                                                Gender:
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e(ucfirst($contact->Gend) ?? '-'); ?></span>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <!--[if BLOCK]><![endif]--><?php if($contact->Brth_Dt): ?>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">
                                            <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                                                Date of Incorporation:
                                            <?php else: ?>
                                                DOB:
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                        <span
                                            class="<?php echo e($dataClass); ?>"><?php echo e($this->formatDate($contact->Brth_Dt, 'd-M-Y')); ?></span>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'I' && $contact->Blood_Grp): ?>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Blood Group:</span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Blood_Grp); ?></span>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'I' && $contact->Anvy_Dt): ?>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Anniversary:</span>
                                        <span
                                            class="<?php echo e($dataClass); ?>"><?php echo e($this->formatDate($contact->Anvy_Dt, 'd-M-Y')); ?></span>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'I' && $contact->Deth_Dt): ?>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Date of Death:</span>
                                        <span
                                            class="<?php echo e($dataClass); ?>"><?php echo e($this->formatDate($contact->Deth_Dt, 'd-M-Y')); ?></span>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            </div>
                        <?php else: ?>
                            <div class="text-slate-500 pl-2 m-4">No additional information available.</div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>

            
            <!--[if BLOCK]><![endif]--><?php if(!empty($phones) || !empty($emails) || !empty($landlines)): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header">
                        <i class="bi bi-person-lines-fill"></i> Contact Information
                    </h2>

                    
                    <div class="grid grid-cols-1 md:grid-cols-3 pl-2 m-4 gap-4">

                        
                        <?php if(!empty($phones)): ?>
                            <div class="border-l-2 border-slate-600 pl-3">
                                <h3 class="font-semibold text-slate-300 mb-2 flex items-center gap-1">
                                    Phones
                                </h3>
                                <ul class="space-y-1">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-white flex items-center gap-1">
                                            <div class="flex items-center gap-1">
                                                <!--[if BLOCK]><![endif]--><?php if($phone['Is_Prmy']): ?>
                                                    <span class="p-1 rounded-full bg-yellow-400" title="Primary"></span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <span
                                                    class="<?php echo e($labelClass); ?> capitalize"><?php echo e($phone['Phon_Type']); ?>:</span>
                                                <span class="<?php echo e($dataClass); ?>">+<?php echo e($phone['Cutr_Code']); ?>

                                                    <?php echo e($phone['Phon_Numb']); ?></span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <!--[if BLOCK]><![endif]--><?php if($phone['Has_WtAp']): ?>
                                                    <i class="bi bi-whatsapp text-green-400" title="WhatsApp"></i>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <!--[if BLOCK]><![endif]--><?php if($phone['Has_Telg']): ?>
                                                    <i class="bi bi-telegram text-sky-400" title="Telegram"></i>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        
                        <!--[if BLOCK]><![endif]--><?php if(!empty($emails)): ?>
                            <div class="border-l-2 border-slate-600 pl-3">
                                <h3 class="font-semibold text-slate-300 mb-2 flex items-center gap-1">
                                    Emails
                                </h3>
                                <ul class="space-y-1">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="flex items-center gap-1 text-white">
                                            <!--[if BLOCK]><![endif]--><?php if($email['Is_Prmy']): ?>
                                                <span class="p-1 rounded-full bg-yellow-400" title="Primary"></span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <span class="break-all flex gap-1">
                                                <span
                                                    class="<?php echo e($labelClass); ?> capitalize"><?php echo e($email['Emai_Type']); ?>:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($email['Emai_Addr']); ?></span>
                                            </span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        
                        <!--[if BLOCK]><![endif]--><?php if(!empty($landlines)): ?>
                            <div class="border-l-2 border-slate-600 pl-3">
                                <h3 class="font-semibold text-slate-300 mb-2 flex items-center gap-1">
                                    Landlines
                                </h3>
                                <ul class="space-y-1">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $landlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $landline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-white flex items-center gap-1">
                                            <div class="flex items-center gap-1">
                                                <!--[if BLOCK]><![endif]--><?php if($landline['Is_Prmy']): ?>
                                                    <span class="p-1 rounded-full bg-yellow-400" title="Primary"></span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <span
                                                    class="<?php echo e($labelClass); ?> capitalize"><?php echo e($landline['Land_Type']); ?>:</span>
                                                <span class="<?php echo e($dataClass); ?>">+<?php echo e($landline['Cutr_Code']); ?>

                                                    <?php echo e($landline['Land_Numb']); ?></span>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-person-lines-fill"></i> Contact Information
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No contact information available.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


            
            <!--[if BLOCK]><![endif]--><?php if($this->hasSocialLinks() && !empty($this->getSocialLinks())): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-share-fill"></i> Social Links
                    </h2>
                    <div class="flex flex-wrap pl-2 m-4 gap-4">
                        <?php
                            $socialIcons = [
                                'website' => 'bi-globe',
                                'linkedin' => 'bi-linkedin',
                                'twitter' => 'bi-twitter-x',
                                'facebook' => 'bi-facebook',
                                'instagram' => 'bi-instagram',
                                'reddit' => 'bi-reddit',
                                'youtube' => 'bi-youtube',
                                'yahoo' => 'bi-yahoo',
                            ];
                        ?>
                        <div class="flex flex-wrap items-center gap-x-4 gap-y-2">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->getSocialLinks(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($url); ?>" target="_blank" rel="noopener noreferrer"
                                    class="bg-green-100 px-2 rounded-md social-link-hover flex items-center gap-1"
                                    style="color: <?php echo e($socialHexColors[$platform] ?? '#000000'); ?>">
                                    <i class="<?php echo e($socialIcons[$platform] ?? 'bi-link'); ?>"></i>
                                    <span class="font-medium"><?php echo e(ucfirst($platform)); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-share-fill"></i> Social Links
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No social links added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if(!empty($addresses)): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-geo-alt-fill"></i> Addresses
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=" border-l-2 border-slate-600 pl-3">
                                <div class="flex items-center gap-1 mb-1">
                                    
                                    <!--[if BLOCK]><![endif]--><?php if($address->Is_Prmy): ?>
                                        <span class="p-1 rounded-full bg-yellow-400" title="Primary"></span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <span class="<?php echo e($labelClass); ?> block">
                                        <?php echo e($this->getAddressTypeName($address->Admn_Addr_Type_Mast_UIN)); ?>:
                                    </span>
                                </div>
                                <address class="<?php echo e($dataClass); ?> not-italic block">
                                    
                                    <?php echo e(collect([$address->Addr, $address->Loca, $address->Lndm])->filter()->implode(', ')); ?>

                                    
                                    <!--[if BLOCK]><![endif]--><?php if($address->district_name || $address->state_name || $address->pincode): ?>
                                        <br>
                                        <?php echo e(collect([$address->district_name, $address->state_name])->filter()->implode(', ')); ?>

                                        <!--[if BLOCK]><![endif]--><?php if($address->pincode || $address->country_name): ?>
                                            -
                                            <?php echo e(collect([$address->pincode, $address->country_name])->filter()->implode(', ')); ?>

                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </address>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-geo-alt-fill"></i> Addresses
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No addresses added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'I'): ?>
                <?php
                    $hasEmploymentDetails =
                        $contact->Comp_Name ||
                        $contact->Comp_Dsig ||
                        $contact->Comp_LdLi ||
                        $contact->Comp_Desp ||
                        $contact->Comp_Emai ||
                        $contact->Comp_Web ||
                        $contact->Comp_Addr;
                    $hasProfessionDetails = $contact->Prfl_Name || $contact->Prfl_Addr;
                ?>

                <!--[if BLOCK]><![endif]--><?php if($hasEmploymentDetails || $hasProfessionDetails): ?>
                    <div class="figma-card bg-slate-600/40">
                        <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header">
                            <i class="bi bi-briefcase-fill"></i> Present Employment
                        </h2>

                        <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 border-slate-600 gap-4">
                            <!--[if BLOCK]><![endif]--><?php if($hasEmploymentDetails): ?>
                                <div class=" border-slate-600  border-l-2 pl-3">
                                    <div class="pb-1">
                                        <span class="text-slate-300 font-semibold">Employment</span>
                                    </div>
                                    <div class="space-y">

                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_Name): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Company Name:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Comp_Name); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_Dsig): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Designation:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Comp_Dsig); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_Addr): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Address:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Comp_Addr); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_Web): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Website:&nbsp</span>
                                                <a href="<?php echo e($contact->Comp_Web); ?>" target="_blank"
                                                    class="text-xs text-blue-400 hover:text-blue-300 break-all font-thin">
                                                    <?php echo e($contact->Comp_Web); ?></a>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_Emai): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Email:</span>
                                                <span
                                                    class="<?php echo e($dataClass); ?> break-all"><?php echo e($contact->Comp_Emai); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_LdLi): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Landline:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Comp_LdLi); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                        <!--[if BLOCK]><![endif]--><?php if($contact->Comp_Desp): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Company Business
                                                    Description:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Comp_Desp); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <!--[if BLOCK]><![endif]--><?php if($hasProfessionDetails): ?>
                                <div class=" border-slate-600 border-l-2 pl-3">
                                    <div class=" text-slate-300 pb-1">
                                        <span class="text-slate-300 font-semibold ">Profession</span>
                                    </div>
                                    <div class="space-y">
                                        <!--[if BLOCK]><![endif]--><?php if($contact->Prfl_Name): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Profession:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Prfl_Name); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($contact->Prfl_Addr): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Profession Address:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($contact->Prfl_Addr); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-briefcase-fill"></i> Past Working Experience
                    </h2>

                    <!--[if BLOCK]><![endif]--><?php if($workExperiences && count($workExperiences) > 0): ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $workExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $safeFormat = function ($d) {
                                        if (empty($d)) {
                                            return null;
                                        }
                                        try {
                                            return \Carbon\Carbon::parse($d)->format('M Y');
                                        } catch (\Throwable $e) {
                                            return null;
                                        }
                                    };

                                    $from = $safeFormat($work['Prd_From'] ?? null);
                                    $to = $safeFormat($work['Prd_To'] ?? null);

                                    if ($from && $to) {
                                        $period = "$from - $to";
                                    } elseif ($from) {
                                        $period = "From $from";
                                    } elseif ($to) {
                                        $period = "To $to";
                                    } else {
                                        $period = '-';
                                    }
                                ?>
                                <div class="border-l-2 border-slate-600 pl-3">
                                    <div class="space-y text-white">
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Organization:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($work['Orga_Name'] ?? '-'); ?></span>
                                        </div>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Designation:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($work['Dsgn'] ?? '-'); ?></span>
                                        </div>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Period:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($period); ?></span>
                                        </div>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Country:</span>
                                            <span
                                                class="<?php echo e($dataClass); ?>"><?php echo e($this->getCountryName($work['Admn_Cutr_Mast_UIN'] ?? null) ?? '-'); ?></span>
                                        </div>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Type:</span>
                                            <span
                                                class="<?php echo e($dataClass); ?>"><?php echo e($work['Work_Type'] ?? '-'); ?></span>
                                        </div>
                                        <!--[if BLOCK]><![endif]--><?php if(!empty($work['Job_Desp'])): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Description:</span>
                                                <span class="<?php echo e($dataClass); ?>"><?php echo e($work['Job_Desp']); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <p class="text-slate-500 pl-2 m-4">No work experience added.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div class="figma-card bg-slate-600/40 mb-4">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-book"></i> Education
                    </h2>

                    <!--[if BLOCK]><![endif]--><?php if($educations && count($educations) > 0): ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class=" border-l-2 border-slate-600 pl-3">
                                    <div class="space-y text-white">
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Degree Name:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($edu['Deg_Name']); ?></span>
                                        </div>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Institute Name:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($edu['Inst_Name']); ?></span>
                                        </div>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Completion Year:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($edu['Cmpt_Year']); ?></span>
                                        </div>
                                        <!--[if BLOCK]><![endif]--><?php if($edu['Admn_Cutr_Mast_UIN']): ?>
                                            <div class="<?php echo e($fieldWrapperClass); ?>">
                                                <span class="<?php echo e($labelClass); ?>">Country:</span>
                                                <span
                                                    class="<?php echo e($dataClass); ?>"><?php echo e($this->getCountryName($edu['Admn_Cutr_Mast_UIN'])); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <p class="text-slate-500 pl-2 m-4">No education details added.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-star"></i> Skills
                    </h2>

                    <!--[if BLOCK]><![endif]--><?php if($skills && count($skills) > 0): ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class=" border-l-2 border-slate-600 pl-3">
                                    <div class="grid text-white space-y">
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Worked On:</span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($skill['Skil_Type']); ?></span>
                                        </div>

                                        <div>
                                            <!--[if BLOCK]><![endif]--><?php if($skill['Skil_Type_1'] === 'Other'): ?>
                                                
                                                <div class="<?php echo e($fieldWrapperClass); ?>">
                                                    <span class="<?php echo e($labelClass); ?>">Skill Name:</span>
                                                    <span
                                                        class="<?php echo e($dataClass); ?>"><?php echo e($skill['Skil_Name']); ?></span>
                                                </div>
                                            <?php else: ?>
                                                
                                                <div class="<?php echo e($fieldWrapperClass); ?>">
                                                    <span class="<?php echo e($labelClass); ?>">Skill Name:</span>
                                                    <span
                                                        class="<?php echo e($dataClass); ?>"><?php echo e($skill['Skil_Type_1']); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                        <div>
                                            <div class="flex gap-4 items-center">
                                                <span class="<?php echo e($labelClass); ?>">Proficiency Level:</span>
                                                <span
                                                    class="text-green-400 font-normal"><?php echo e($skill['Profc_Lvl']); ?>/5</span>
                                            </div>
                                            <div class="w-1/2 bg-slate-700 rounded-full h-1.5 mt-1">
                                                <div class="bg-green-400 h-1.5 rounded-full"
                                                    style="width: <?php echo e((int) ($skill['Profc_Lvl'] * 20)); ?>%"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <p class="text-slate-500 pl-2 m-4">No skills added.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if($contact->referencePersons && $contact->referencePersons->isNotEmpty()): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-people-fill "></i>
                        <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                            Authorized Person
                        <?php else: ?>
                            Reference Person
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                        
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contact->referencePersons->sortByDesc('Is_Prmy'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=" border-l-2 border-slate-600 pl-3">
                                <div class="space-y text-white">
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        
                                        <!--[if BLOCK]><![endif]--><?php if($reference->Is_Prmy): ?>
                                            <span class="p-1 rounded-full bg-yellow-400" title="Primary"></span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <span class="<?php echo e($labelClass); ?>">
                                            Name:
                                        </span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e($reference->Refa_Name); ?></span>
                                    </div>

                                    <!--[if BLOCK]><![endif]--><?php if($reference->Refa_Rsip): ?>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">
                                                <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                                                    Designation:
                                                <?php else: ?>
                                                    Relationship:
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                            <span class="<?php echo e($dataClass); ?>"><?php echo e($reference->Refa_Rsip); ?></span>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <div class="flex flex-wrap gap-4 mt-1">
                                        <!--[if BLOCK]><![endif]--><?php if($reference->Refa_Emai): ?>
                                            <span class="<?php echo e($dataClass); ?>">
                                                <i class="bi bi-envelope"></i> <?php echo e($reference->Refa_Emai); ?>

                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($reference->Refa_Phon): ?>
                                            <span class="<?php echo e($dataClass); ?>">
                                                <i class="bi bi-telephone"></i> <?php echo e($reference->Refa_Phon); ?>

                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-people-fill"></i>
                        <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                            Authorized Person
                        <?php else: ?>
                            Reference Person
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No reference persons added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if(!empty($bankAccounts) && is_array($bankAccounts) && count($bankAccounts) > 0): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-building"></i> Bank Details
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=" border-l-2 border-slate-600 pl-3">

                                <div class="space-y">
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        
                                        <!--[if BLOCK]><![endif]--><?php if($bank->Prmy): ?>
                                            <span class="p-1 rounded-full bg-yellow-400"
                                                title="Primary Bank"></span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <span class="<?php echo e($labelClass); ?>">

                                            Bank Name:
                                        </span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e($bank->Bank_Name ?? '-'); ?></span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Branch Name:</span>
                                        <span
                                            class="<?php echo e($dataClass); ?>"><?php echo e($bank->Bank_Brnc_Name ?? '-'); ?></span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>"> SWIFT Code:</span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e($bank->Swift_Code ?? '-'); ?></span>
                                    </div>

                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">IFSC Code:</span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e($bank->IFSC_Code ?? '-'); ?></span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Account Number:</span>
                                        <span
                                            class="<?php echo e($dataClass); ?> font-mono"><?php echo e($bank->Acnt_Numb ?? '-'); ?></span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Account Type:</span>
                                        <span class="<?php echo e($dataClass); ?>"><?php echo e($bank->Acnt_Type ?? '-'); ?></span>
                                    </div>
                                </div>
                                
                                <!--[if BLOCK]><![endif]--><?php if(isset($bank->attachments) && count($bank->attachments) > 0): ?>
                                    <div class=" border-slate-700">
                                        <p class="<?php echo e($labelClass); ?>">Attachments</p>
                                        <div class="flex gap-4 flex-wrap">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bank->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(Storage::url($attachment->Atch_Path)); ?>"
                                                    target="_blank"
                                                    class=" text-blue-400 text-xs hover:text-blue-300 break-all underline inline-flex items-center gap-1 font-normal">
                                                    <i
                                                        class="bi bi-download"></i><?php echo e(basename($attachment->Atch_Path)); ?>

                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-building"></i> Bank Details
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No bank accounts added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if(!empty($documents) && is_array($documents) && count($documents) > 0): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-file-earmark-pdf"></i>
                        <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'B'): ?>
                            Statutory
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        Documents
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 pl-2 m-4 gap-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=" border-l-2 border-slate-600 pl-3">
                                <div class="space-y">

                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        
                                        <!--[if BLOCK]><![endif]--><?php if($document['Prmy']): ?>
                                            <span class="p-1 rounded-full bg-yellow-400"
                                                title="Primary Document"></span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <span class="<?php echo e($labelClass); ?>">

                                            Document Name:
                                        </span>
                                        <span
                                            class="<?php echo e($dataClass); ?> text-sm !font-normal "><?php echo e($document['Docu_Name'] ?? '-'); ?></span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Registration Number:</span>
                                        <span
                                            class="<?php echo e($dataClass); ?>"><?php echo e($document['Regn_Numb'] ?? '-'); ?></span>
                                    </div>

                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Valid From:</span>
                                        <span class="<?php echo e($dataClass); ?> ">
                                            <!--[if BLOCK]><![endif]--><?php if($document['Vald_From'] ?? null): ?>
                                                <?php echo e($this->formatDate($document['Vald_From'], 'd-M-Y')); ?>

                                            <?php else: ?>
                                                -
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                    </div>

                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Country:</span>
                                        <span class="<?php echo e($dataClass); ?> ">
                                            <!--[if BLOCK]><![endif]--><?php if($document['Admn_Cutr_Mast_UIN'] ?? null): ?>
                                                <?php echo e($this->getCountryName($document['Admn_Cutr_Mast_UIN'])); ?>

                                            <?php else: ?>
                                                -
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Authority Issued:</span>
                                        <span
                                            class="<?php echo e($dataClass); ?> "><?php echo e($document['Auth_Issd'] ?? '-'); ?></span>
                                    </div>
                                    <div class="<?php echo e($fieldWrapperClass); ?>">
                                        <span class="<?php echo e($labelClass); ?>">Valid Upto:</span>
                                        <span class="<?php echo e($dataClass); ?> ">
                                            <!--[if BLOCK]><![endif]--><?php if($document['Vald_Upto'] ?? null): ?>
                                                <?php echo e($this->formatDate($document['Vald_Upto'], 'd-M-Y')); ?>

                                            <?php else: ?>
                                                -
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                    </div>

                                    <?php
                                        $docPath = $document['Docu_Atch_Path'] ?? null;
                                        $hasFile =
                                            isset($docPath) &&
                                            !empty($docPath) &&
                                            !is_object($docPath) &&
                                            $docPath !== '';
                                    ?>

                                    <!--[if BLOCK]><![endif]--><?php if($hasFile): ?>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Attachment:</span>
                                            <a href="<?php echo e(Storage::url($docPath)); ?>" target="_blank"
                                                class=" text-blue-400 text-xs hover:text-blue-300 break-all underline inline-flex items-center gap-1 font-normal">
                                                <i class="bi bi-download"></i><?php echo e(basename($docPath)); ?>

                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <div class="<?php echo e($fieldWrapperClass); ?>">
                                            <span class="<?php echo e($labelClass); ?>">Attachment:</span>
                                            <span class="text-slate-400 font-normal">-</span>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php if(!empty($document['selected_types'])): ?>
                                        <div>
                                            <div class="flex flex-wrap gap-2 mt-1">
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $document['selected_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $docType = $allDocumentTypes->firstWhere(
                                                            'Admn_Docu_Type_Mast_UIN',
                                                            $typeId,
                                                        );
                                                    ?>
                                                    <!--[if BLOCK]><![endif]--><?php if($docType): ?>
                                                        <span
                                                            class="inline-flex items-center border-blue-300/20  font-medium border
                                                            bg-blue-600/20 text-blue-300 text-xs px-1 py rounded-full">
                                                            <?php echo e($docType->Docu_Name); ?>

                                                        </span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-file-earmark-pdf"></i> Documents
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No documents added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


            <!--[if BLOCK]><![endif]--><?php if($contact->Note): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-journal-text "></i> Remarks for
                        <!--[if BLOCK]><![endif]--><?php if($contact->Prty === 'I'): ?>
                            Contact Person
                        <?php else: ?>
                            Organization
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </h2>
                    <p class="<?php echo e($dataClass); ?> whitespace-pre-line pl-2 m-4"><?php echo e($contact->Note); ?></p>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-journal-text"></i> Remarks
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No remarks added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($contact->group?->Name): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-people-fill"></i> Group Information
                    </h2>
                    <div class="">
                        <div class="flex flex-wrap gap-1 items-baseline pl-2 m-4">
                            <span class="<?php echo e($labelClass); ?>">Assigned to Group: </span>
                            <span
                                class="<?php echo e($dataClass); ?> whitespace-pre-line"><?php echo e($contact->group->Name); ?></span>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-people-fill"></i> Group Information
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">Not assigned to any group.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($contact->tags->isNotEmpty()): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-tag"></i> Tags
                    </h2>
                    <div class="flex flex-wrap gap-2 pl-2 m-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contact->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="bg-blue-600/20 text-blue-300 text-sm px-2 py-1 rounded-full "><?php echo e($tag->Name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-tag"></i> Tags
                    </h2>
                    <p class="text-slate-500 pl-2 m-4">No tags added.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($contactNotes && count($contactNotes) > 0): ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-sticky-fill"></i> Notes
                    </h2>
                    <div class="max-h-80 overflow-y-auto pr-2 space-y-2 pl-2 m-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contactNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="py-2.5 px-3 rounded border bg-slate-700/20 border-slate-600/50 ">
                                <div class="flex items-center justify-between mb-1.5">
                                    <div class="flex gap-2">
                                        
                                        <!--[if BLOCK]><![endif]--><?php if($note['isPinned']): ?>
                                            <i class="bi bi-pin-fill text-yellow-400 "></i>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <p class="<?php echo e($labelClass); ?> !font-thin !text-xs">
                                            <span class=""><?php echo e($note['User_Name']); ?></span>
                                            <!--[if BLOCK]><![endif]--><?php if($note['Vertical_Name']): ?>
                                                <span class=" ">
                                                    (<?php echo e($note['Vertical_Name']); ?>)
                                                </span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </p>
                                    </div>
                                    <span class="<?php echo e($labelClass); ?> !font-thin !text-xs">
                                        <?php echo e($note['CrOn']->setTimezone('Asia/Kolkata')->format('d-M-Y h:i A')); ?>

                                    </span>
                                </div>
                                <p class="<?php echo e($dataClass); ?> line-clamp-2 break-words"><?php echo e($note['Note_Detl']); ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php else: ?>
                <div class="figma-card bg-slate-600/40">
                    <h2 class="<?php echo e($sectionHeaderClass); ?> figma-card-header ">
                        <i class="bi bi-sticky-fill"></i> Contact Notes
                    </h2>
                    <p class="text-slate-500 pl-2 m-4 "><i class="bi bi-info-circle"></i> No notes added yet.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH /home/u625055691/domains/admin.partakedigital.com/public_html/admin/resources/views/livewire/contacts/show.blade.php ENDPATH**/ ?>