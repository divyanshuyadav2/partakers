<div>
    <div x-data="contactFormValidator()" x-init="init()"
        @validate-phone-length.window="validatePhoneLength($event.detail.fieldKey, $event.detail.value, $event.detail.index)">
        @csrf

        {{-- Show error message if link is invalid --}}
        @if ($hasError)
            <div class="max-w-2xl mx-auto py-10 sm:px-6 lg:px-8">
                <div
                    class="rounded-md p-8 text-center border-2 @if ($errorType === 'used') bg-amber-900/30 border-amber-500/50 @elseif($errorType === 'expired') bg-red-900/30 border-red-500/50 @else bg-slate-900/50 border-slate-500/50 @endif">
                    <div class="mb-6">
                        @if ($errorType === 'used')
                            <i class="bi bi-check-circle-fill text-amber-400 text-6xl"></i>
                        @elseif($errorType === 'expired')
                            <i class="bi bi-clock-fill text-red-400 text-6xl"></i>
                        @else
                            <i class="bi bi-exclamation-triangle-fill text-slate-400 text-6xl"></i>
                        @endif
                    </div>
                    <h2
                        class="text-2xl font-bold mb-4 @if ($errorType === 'used') text-amber-300 @elseif($errorType === 'expired') text-red-300 @else text-slate-300 @endif">
                        @if ($errorType === 'used')
                            Link Already Used
                        @elseif($errorType === 'expired')
                            Link Has Expired
                        @else
                            Access Not Available
                        @endif
                    </h2>
                    <p
                        class="mb-6 text-base leading-relaxed @if ($errorType === 'used') text-amber-200 @elseif($errorType === 'expired') text-red-200 @else text-slate-300 @endif">
                        {{ $errorMessage }}
                    </p>
                    @if ($errorType === 'used')
                        <div class="bg-amber-800/30 border border-amber-600/50 rounded-md p-4 mb-6">
                            <div class="flex items-start">
                                <i class="bi bi-info-circle-fill text-amber-400 text-lg mt-0.5 mr-3 flex-shrink-0"></i>
                                <div class="text-left">
                                    <p class="text-amber-200 text-sm font-medium mb-1">What happened?</p>
                                    <p class="text-amber-300 text-sm">Someone (possibly you) has already submitted
                                        information using this link. For security reasons, each invitation link can only
                                        be used once.</p>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if ($errorType === 'expired')
                        <div class="bg-red-800/30 border border-red-600/50 rounded-md p-4 mb-6">
                            <div class="flex items-start">
                                <i class="bi bi-info-circle-fill text-red-400 text-lg mt-0.5 mr-3 flex-shrink-0"></i>
                                <div class="text-left">
                                    <p class="text-red-200 text-sm font-medium mb-1">Why did this expire?</p>
                                    <p class="text-red-300 text-sm">Invitation links are valid for 24 hours from the
                                        time they were created for security purposes.</p>
                                </div>
                            </div>
                        </div>
                    @endif
                    <div class="text-sm text-slate-400">
                        @if ($errorType === 'used' || $errorType === 'expired')
                            Need a new link? Please contact the person who originally sent you this invitation.
                        @else
                            If you believe this is an error, please contact support.
                        @endif
                    </div>
                </div>
            </div>

            {{-- Show success message if form was submitted successfully --}}
        @elseif ($isSuccess)
            <div class="max-w-2xl mx-auto py-10 sm:px-6 lg:px-8">
                <div class="bg-green-900/50 border border-green-500/50 rounded-md p-8 text-center">
                    <div class="mb-4">
                        <i class="bi bi-check-circle-fill text-green-400 text-6xl"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-white mb-4">Thank You!</h2>
                    <p class="text-green-300 mb-6">Your contact information has been successfully submitted.</p>
                    <p class="text-slate-400 text-sm">This invitation link has now been used and cannot be accessed
                        again.</p>
                </div>
            </div>

            {{-- Show the form only if not yet successfully submitted and no errors --}}
        @else
            <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">
                {{-- Link Expiry Display --}}
                @if (isset($linkExpiresAt))
                    <div class="mb-6 bg-blue-900/30 border border-blue-500/50 rounded-md p-4" x-data="linkExpiryTimer('{{ $linkExpiresAt }}')"
                        x-init="init()">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-3">
                                <i class="bi bi-clock text-blue-400 text-lg"></i>
                                <div>
                                    <p class="text-blue-300 font-medium text-sm">Link Expires In</p>
                                    <p class="text-blue-200 text-xs">This invitation link will expire automatically for
                                        security.</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="flex items-center gap-2 text-blue-300">
                                    <div class="bg-blue-800/50 rounded px-2 py-1 text-sm font-mono"
                                        x-show="timeLeft.hours > 0">
                                        <span x-text="timeLeft.hours.toString().padStart(2, '0')"></span>h
                                    </div>
                                    <div class="bg-blue-800/50 rounded px-2 py-1 text-sm font-mono">
                                        <span x-text="timeLeft.minutes.toString().padStart(2, '0')"></span>m
                                    </div>
                                    <div class="bg-blue-800/50 rounded px-2 py-1 text-sm font-mono">
                                        <span x-text="timeLeft.seconds.toString().padStart(2, '0')"></span>s
                                    </div>
                                </div>
                                <p class="text-blue-400 text-xs mt-1" x-text="expiryDate"></p>
                            </div>
                        </div>
                        {{-- Warning when less than 1 hour remaining --}}
                        <div x-show="timeLeft.total < 3600000 && timeLeft.total > 0" x-transition
                            class="mt-3 bg-amber-900/30 border border-amber-600/50 rounded-md p-3">
                            <div class="flex items-center gap-2">
                                <i class="bi bi-exclamation-triangle-fill text-amber-400"></i>
                                <p class="text-amber-300 text-sm font-medium">Link expires in less than 1 hour!</p>
                            </div>
                            <p class="text-amber-200 text-xs mt-1">Please complete and submit the form before it
                                expires.</p>
                        </div>
                        {{-- Critical warning when less than 15 minutes remaining --}}
                        <div x-show="timeLeft.total < 900000 && timeLeft.total > 0" x-transition
                            class="mt-3 bg-red-900/30 border border-red-600/50 rounded-md p-3">
                            <div class="flex items-center gap-2">
                                <i class="bi bi-exclamation-triangle-fill text-red-400 animate-pulse"></i>
                                <p class="text-red-300 text-sm font-medium">Critical: Link expires in less than 15
                                    minutes!</p>
                            </div>
                            <p class="text-red-200 text-xs mt-1">Submit the form immediately to avoid losing access.</p>
                        </div>
                    </div>
                @endif

                {{-- Page Header --}}
                <div class="flex items-center space-x-4">
                    <div>
                        <h1 class="text-3xl font-bold text-white"> Welcome to {{ $organization }} !</h1>
                        <p class="mt-2 text-sm text-slate-400">We’re glad you joined us. To get the best experience,
                            kindly fill in your personal and business details here:</p>
                    </div>
                </div>


                {{-- Session Flash Messages --}}
                @if (session()->has('error'))
                    <div class="mt-4 bg-red-900/50 border border-red-500/50 rounded-md p-4">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="bi bi-exclamation-triangle-fill text-red-400 text-lg"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-red-300">{{ session('error') }}</p>
                            </div>
                        </div>
                    </div>
                @endif

                {{-- The Form Wrapper --}}
                <form wire:submit="save" @submit="if(!validateForm()) { $event.preventDefault(); }"
                    class="mt-8 grid grid-cols-1 gap-8">
                    <!-- Personal Details Card -->
                    <div class="figma-card">
                        <h2 class="figma-card-header text-green-200"><i class="bi bi-person-vcard mr-2"></i>Personal
                            Details</h2>
                        <div class="p-6 space-y-6">

                            {{-- AlpineJS Component for Image Cropping --}}
                            <div x-data="imageCropperComponent()" wire:key="alpine-image-cropper"
                                class="flex flex-col items-center space-y-4">
                                <!-- Hidden file input, triggered by our buttons -->
                                <input type="file" class="hidden" x-ref="fileInput" @change="handleFileSelect"
                                    accept="image/png, image/jpeg, image/gif">

                                <!-- MODIFIED: Profile Picture Display Area -->
                                <div class="relative group w-36 h-36">
                                    <!-- The circular preview area (acts as a container) -->
                                    <div
                                        class="w-36 h-36 rounded-full mx-auto bg-slate-800 border-2 border-dashed border-slate-600 flex items-center justify-center overflow-hidden">
                                        @if ($Prfl_Pict)
                                            <img src="{{ $Prfl_Pict->temporaryUrl() }}"
                                                class="w-full h-full object-cover" alt="Profile Preview">
                                        @else
                                            {{-- Placeholder when no image is selected --}}
                                            <div @click="$refs.fileInput.click()"
                                                class="cursor-pointer w-full h-full flex flex-col items-center justify-center text-center p-2">
                                                <i class="bi bi-camera-fill text-3xl text-slate-500"></i>
                                                <span class="text-xs text-slate-500 mt-1">Upload Photo</span>
                                            </div>
                                        @endif
                                    </div>
                                    <!-- Hover Overlay with Change/Remove Actions -->
                                    @if ($Prfl_Pict)
                                        <div
                                            class="absolute inset-0 rounded-full bg-black/60 flex flex-col items-center justify-center space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                            <!-- Change Button -->
                                            <button type="button" @click.prevent="$refs.fileInput.click()"
                                                class="flex items-center gap-2 text-sm font-semibold text-white hover:text-blue-300 transition-colors">
                                                <i class="bi bi-arrow-repeat"></i>
                                                <span>Change</span>
                                            </button>
                                            <!-- Remove Button -->
                                            <button type="button" wire:click="removeProfilePicture"
                                                class="flex items-center gap-2 text-sm font-semibold text-white hover:text-red-400 transition-colors">
                                                <i class="bi bi-trash"></i>
                                                <span>Clear</span>
                                            </button>
                                        </div>
                                    @endif
                                </div>
                                <span class="text-gray-400 text-xs -mt-2 block">upload file type : jpg/png</span>
                                @error('Prfl_Pict')
                                    <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                @enderror

                                <!-- Cropper.js Modal (Unchanged) -->
                                <div x-show="showCropper" x-transition
                                    class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
                                    style="display: none;">
                                    <div @click.away="closeCropper()"
                                        class="bg-slate-800 rounded-md shadow-xl w-full max-w-lg">
                                        <div class="p-6">
                                            <h3 class="text-lg font-medium text-white mb-4">Crop Your Image</h3>
                                            <div class="w-full h-80 bg-slate-900">
                                                <img x-ref="imageToCropEl" :src="imageToCrop"
                                                    class="max-w-full max-h-full block">
                                            </div>
                                        </div>
                                        <div
                                            class="px-6 py-4 bg-slate-900/50 flex justify-end items-center gap-4 rounded-b-lg">
                                            <button type="button" @click="closeCropper()"
                                                class="text-sm font-semibold text-slate-400 hover:text-white transition-colors">Cancel</button>
                                            <button type="button" @click="cropImage()"
                                                class="figma-button-primary flex gap-2">
                                                <i class="bi bi-crop"></i>
                                                Apply
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                {{-- Prefix Field --}}
                                <div>
                                    <label for="Prfx_UIN" class="text-sm font-medium text-slate-400">Prefix</label>
                                    <select id="Prfx_UIN" wire:model.live="Prfx_UIN" class="form-select-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Prfx_UIN') }">
                                        <option value="">Select...</option>
                                        @foreach ($allPrefixes as $prefix)
                                            <option value="{{ $prefix->Prfx_Name_UIN }}"
                                                title="{{ $prefix->Prfx_Name_D }}">
                                                {{ $prefix->Prfx_Name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('Prfx_UIN')
                                        <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                                    @enderror
                                </div>

                                <!-- First Name -->
                                <div>
                                    <label for="FaNm" class="text-sm font-medium text-slate-400">First Name <span
                                            class="text-red-400">*</span></label>
                                    <input type="text" id="FaNm" wire:model.blur="FaNm"
                                        @blur="markTouched('FaNm')"
                                        @input="filterInput($event, 'alpha'); validateField('FaNm', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('FaNm') }">
                                    <span x-show="hasError('FaNm')" x-text="getError('FaNm')"
                                        class="text-red-400 text-xs mt-1"></span>
                                    @error('FaNm')
                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                    @enderror
                                </div>

                                <!-- Middle Name -->
                                <div>
                                    <label for="MiNm" class="text-sm font-medium text-slate-400">Middle
                                        Name</label>
                                    <input type="text" id="MiNm" wire:model.blur="MiNm"
                                        @blur="markTouched('MiNm'); validateField('MiNm', $event.target.value)"
                                        @input="validateField('MiNm', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('MiNm') }">
                                    <span x-show="hasError('MiNm')" x-text="getError('MiNm')"
                                        class="text-red-400 text-xs mt-1"></span>
                                    @error('MiNm')
                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                    @enderror
                                </div>

                                <!-- Last Name -->
                                <div>
                                    <label for="LaNm" class="text-sm font-medium text-slate-400">Last Name</label>
                                    <input type="text" id="LaNm" wire:model.blur="LaNm"
                                        @blur="markTouched('LaNm'); validateField('LaNm', $event.target.value)"
                                        @input="validateField('LaNm', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('LaNm') }">
                                    <span x-show="hasError('LaNm')" x-text="getError('LaNm')"
                                        class="text-red-400 text-xs mt-1"></span>
                                    @error('LaNm')
                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                    @enderror
                                </div>

                                <!-- Gender -->

                                <div>
                                    <label for="Gend" class="text-sm font-medium text-slate-400">
                                        Gender

                                    </label>
                                    <select id="Gend" wire:model.blur="Gend"
                                        @change="markTouched('Gend'); validateField('Gend', $event.target.value)"
                                        class="form-select-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Gend') }">
                                        <option value="">Select...</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                    <span x-show="hasError('Gend')" x-text="getError('Gend')"
                                        class="text-red-400 text-xs mt-1"></span>
                                    @error('Gend')
                                        <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                                    @enderror
                                </div>


                                <!-- Birth Date -->
                                <div>
                                    <label for="Brth_Dt" class="text-sm font-medium text-slate-400">Date of
                                        Birth</label>
                                    <input type="date" id="Brth_Dt" wire:model.blur="Brth_Dt"
                                        @change="markTouched('Brth_Dt'); validateField('Brth_Dt', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Brth_Dt') }">
                                    <span x-show="hasError('Brth_Dt')" x-text="getError('Brth_Dt')"
                                        class="text-red-400 text-xs mt-1"></span>
                                    @error('Brth_Dt')
                                        <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                                    @enderror
                                </div>

                                {{-- <div>
                                    <label for="Anvy_Dt" class="text-sm font-medium text-slate-400">Anniversary
                                        Date</label>
                                    <input type="date" id="Anvy_Dt" wire:model.blur="Anvy_Dt"
                                        @change="markTouched('Anvy_Dt'); validateField('Anvy_Dt', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Anvy_Dt') }">
                                    <span x-show="hasError('Anvy_Dt')" x-text="getError('Anvy_Dt')"
                                        class="text-red-400 text-xs mt-1"></span>
                                    @error('Anvy_Dt')
                                        <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                                    @enderror
                                </div> --}}
                            </div>
                        </div>
                    </div>

                    <!-- Address Card -->
                    <div class="figma-card">
                        <h2 class="figma-card-header text-green-200"><i class="bi bi-geo-alt-fill mr-2"></i>Address
                        </h2>
                        <div class="p-6 space-y-6">
                            @foreach ($addresses as $index => $address)
                                <div class="relative p-5 rounded-md bg-slate-700/30 border border-slate-600"
                                    wire:key="address-{{ $index }}">

                                    <!-- TOP ROW: Address Type (Left) + Actions (Right) -->
                                    <div class="flex items-start justify-between gap-4 mb-4">
                                        <!-- Address Type -->
                                        <div class="flex-1">
                                            <label class="block text-sm mb-1 font-medium text-gray-100">Address
                                                Type</label>
                                            <select wire:model="addresses.{{ $index }}.Admn_Addr_Type_Mast_UIN"
                                                @change="markTouched('addresses.{{ $index }}.Admn_Addr_Type_Mast_UIN')"
                                                class="form-select-figma w-fit"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'addresses.{{ $index }}.Admn_Addr_Type_Mast_UIN')
                                                }">
                                                <option value="">Select</option>
                                                @foreach ($addressTypes as $type)
                                                    <option value="{{ $type->Admn_Addr_Type_Mast_UIN }}">
                                                        {{ $type->Name }}</option>
                                                @endforeach
                                            </select>
                                            <span
                                                x-show="hasError('addresses.{{ $index }}.Admn_Addr_Type_Mast_UIN')"
                                                x-text="getError('addresses.{{ $index }}.Admn_Addr_Type_Mast_UIN')"
                                                class="text-red-400 text-xs mt-1 block"></span>
                                            @error('addresses.' . $index . '.Admn_Addr_Type_Mast_UIN')
                                                <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <!-- Primary & Remove Actions -->
                                        <div class="flex items-center gap-4 pt-6">
                                            <label for="primary_address_{{ $index }}"
                                                class="flex items-center cursor-pointer gap-2 whitespace-nowrap">
                                                <span class="text-sm font-medium text-slate-400">Primary</span>
                                                <input type="radio" id="primary_address_{{ $index }}"
                                                    name="primary_address" title="Set as primary"
                                                    wire:click="setPrimaryAddress({{ $index }})"
                                                    @if ($address['Is_Prmy'] ?? false) checked @endif
                                                    class="form-radio-figma">
                                            </label>

                                            @if (count($addresses) > 1)
                                                <button type="button"
                                                    wire:click="removeAddress({{ $index }})"
                                                    title="Remove Address"
                                                    class="text-slate-400 hover:text-red-500 transition-colors">
                                                    <i class="bi bi-trash-fill text-lg"></i>
                                                </button>
                                            @endif
                                        </div>
                                    </div>

                                    <!-- Address Fields Grid -->
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">

                                        <!-- Country -->
                                        <div>
                                            <label class="block text-sm mb-1 font-medium text-gray-100">Country</label>
                                            <select wire:model.live="addresses.{{ $index }}.Admn_Cutr_Mast_UIN"
                                                class="form-select-figma w-full">
                                                <option value="">Select Country...</option>
                                                @foreach ($allCountries as $country)
                                                    <option value="{{ $country->Admn_Cutr_Mast_UIN }}">
                                                        {{ $country->Name }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <!-- State -->
                                        <div>
                                            <label class="block text-sm mb-1 font-medium text-gray-100">State</label>
                                            <select wire:model.live="addresses.{{ $index }}.Admn_Stat_Mast_UIN"
                                                class="form-select-figma w-full"
                                                @if (empty($address['statesForDropdown'] ?? [])) disabled @endif>
                                                <option value="">Select State...</option>
                                                @foreach ($address['statesForDropdown'] ?? [] as $state)
                                                    <option value="{{ $state['Admn_Stat_Mast_UIN'] }}">
                                                        {{ $state['Name'] }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <!-- District -->
                                        <div>
                                            <label
                                                class="block text-sm mb-1 font-medium text-gray-100">District</label>
                                            <select wire:model.live="addresses.{{ $index }}.Admn_Dist_Mast_UIN"
                                                class="form-select-figma w-full"
                                                @if (empty($address['districtsForDropdown'] ?? [])) disabled @endif>
                                                <option value="">Select District...</option>
                                                @foreach ($address['districtsForDropdown'] ?? [] as $district)
                                                    <option value="{{ $district['Admn_Dist_Mast_UIN'] }}">
                                                        {{ $district['Name'] }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <!-- Pincode -->
                                        <div>
                                            <label class="block text-sm mb-1 font-medium text-gray-100">Pincode</label>
                                            <select
                                                wire:model.live="addresses.{{ $index }}.Admn_PinCode_Mast_UIN"
                                                class="form-select-figma w-full"
                                                @if (empty($address['pincodesForDropdown'] ?? [])) disabled @endif>
                                                <option value="">Select Pincode...</option>
                                                @foreach ($address['pincodesForDropdown'] ?? [] as $pincode)
                                                    <option value="{{ $pincode['Admn_PinCode_Mast_UIN'] }}">
                                                        {{ $pincode['Code'] }}</option>
                                                @endforeach
                                            </select>
                                            @error('addresses.' . $index . '.Admn_PinCode_Mast_UIN')
                                                <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <!-- Location -->
                                        <div>
                                            <label
                                                class="block text-sm mb-1 font-medium text-gray-100">Location</label>
                                            <input type="text"
                                                wire:model.blur="addresses.{{ $index }}.Lndm"
                                                @blur="markTouched('addresses.{{ $index }}.Lndm')"
                                                @input="validateField('addresses', $event.target.value, {{ $index }}, 'Lndm')"
                                                class="form-input-figma w-full"
                                                :class="{ 'border-red-500 ring-red-500': hasError(
                                                        'addresses.{{ $index }}.Lndm') }"
                                                placeholder="Town/City, Locality, Landmark">
                                            <span x-show="hasError('addresses.{{ $index }}.Lndm')"
                                                x-text="getError('addresses.{{ $index }}.Lndm')"
                                                class="text-red-400 text-xs mt-1 block"></span>
                                            @error('addresses.' . $index . '.Lndm')
                                                <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <!-- Street -->
                                        <div>
                                            <label class="block text-sm mb-1 font-medium text-gray-100">Street</label>
                                            <input type="text"
                                                wire:model.blur="addresses.{{ $index }}.Loca"
                                                @blur="markTouched('addresses.{{ $index }}.Loca')"
                                                @input="validateField('addresses', $event.target.value, {{ $index }}, 'Loca')"
                                                class="form-input-figma w-full"
                                                :class="{ 'border-red-500 ring-red-500': hasError(
                                                        'addresses.{{ $index }}.Loca') }"
                                                placeholder="Area, Street, Sector, Village">
                                            <span x-show="hasError('addresses.{{ $index }}.Loca')"
                                                x-text="getError('addresses.{{ $index }}.Loca')"
                                                class="text-red-400 text-xs mt-1 block"></span>
                                            @error('addresses.' . $index . '.Loca')
                                                <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <!-- Address Line (Full Width) -->
                                        <div class="sm:col-span-2">
                                            <label class="block text-sm mb-1 font-medium text-gray-100">Flat, House No,
                                                Building Name, Company</label>
                                            <textarea wire:model.blur="addresses.{{ $index }}.Addr"
                                                @blur="markTouched('addresses.{{ $index }}.Addr')"
                                                @input="validateField('addresses', $event.target.value, {{ $index }}, 'Addr')" rows="2"
                                                class="form-input-figma w-full"
                                                :class="{ 'border-red-500 ring-red-500': hasError(
                                                        'addresses.{{ $index }}.Addr') }"
                                                placeholder="Flat, House No, Building Name, Company..."></textarea>
                                            <span x-show="hasError('addresses.{{ $index }}.Addr')"
                                                x-text="getError('addresses.{{ $index }}.Addr')"
                                                class="text-red-400 text-xs mt-1 block"></span>
                                            @error('addresses.' . $index . '.Addr')
                                                <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            @endforeach

                            <!-- Add Another Address Button -->
                            @if (count($addresses) < 5)
                                <button type="button" wire:click="addAddress"
                                    class="text-sm font-semibold text-blue-500 hover:text-blue-300 transition-colors flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i>
                                    Add Another Address
                                </button>
                            @endif
                        </div>
                    </div>

                    <!-- Contact Information Card -->
                    <div class="figma-card">
                        <h2 class="figma-card-header text-green-200"><i
                                class="bi bi-person-lines-fill mr-2"></i>Contact Information</h2>
                        <div class="p-6 space-y-8">
                            <!-- Phone Numbers -->
                            <div>
                                <h3
                                    class="font-medium text-slate-300 mb-4 flex items-center gap-2 text-sm uppercase tracking-wide">
                                    <i class="bi bi-telephone-fill text-blue-400"></i>
                                    Phone Numbers
                                </h3>
                                <div class="space-y-4">
                                    @forelse ($phones as $index => $phone)
                                        <div class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600"
                                            wire:key="phone-{{ $index }}">
                                            <!-- MODIFIED: Controls moved to the top right -->
                                            <div class="absolute top-4 right-4 flex items-center gap-4">
                                                <label for="primary_phone_{{ $index }}"
                                                    class="flex items-center cursor-pointer gap-2">
                                                    <span class="text-sm font-medium text-slate-400">Preferable</span>
                                                    <input type="radio" id="primary_phone_{{ $index }}"
                                                        name="primary_phone" title="Set as preferable"
                                                        wire:click="setPrimaryPhone({{ $index }})"
                                                        @if ($phone['Is_Prmy'] ?? false) checked @endif
                                                        class="form-radio-figma">
                                                </label>
                                                @if (count($phones) > 1)
                                                    <button type="button"
                                                        wire:click="removePhone({{ $index }})"
                                                        title="Remove Phone"
                                                        class="text-slate-500 hover:text-red-500 transition-colors">
                                                        <i class="bi bi-trash-fill text-lg"></i>
                                                    </button>
                                                @endif
                                            </div>

                                            <div class="flex-grow grid grid-cols-1 sm:grid-cols-5 gap-3 pt-8">
                                                <div class="sm:col-span-1">
                                                    <div wire:ignore>
                                                        <div x-data="countryPicker('{{ $phone['Cutr_Code'] ?? ($allCountries->first()->Phon_Code ?? '91') }}', {{ $index }})" x-init="init()"
                                                            @primary-country-changed.window="updateFromPrimary($event.detail)"
                                                            class="relative">
                                                            <button type="button" @click="open = !open"
                                                                class="form-select-figma text-sm w-full h-10 flex items-center justify-between px-3">
                                                                <span class="flex items-center gap-2">
                                                                    <span x-show="selectedCountry"
                                                                        :class="`fi fi-${(selectedCountry?.Code || '').trim().toLowerCase()}`"></span>
                                                                    <span x-show="selectedCountry"
                                                                        x-text="selectedCountry?.Name + ' +' +(selectedCountry?.Phon_Code || '').trim()"></span>
                                                                </span>
                                                                <i class="bi bi-chevron-down text-gray-400"></i>
                                                            </button>
                                                            <div x-show="open" @click.outside="open = false"
                                                                x-transition
                                                                class="absolute z-20 mt-1 w-72 max-h-60 overflow-y-auto rounded-md bg-white shadow-lg border border-slate-200">
                                                                <div
                                                                    class="p-2 sticky top-0 bg-white border-b border-slate-200">
                                                                    <input type="text" x-model="search"
                                                                        placeholder="Search country..."
                                                                        class="w-full rounded-md border-gray-300 text-sm px-2 py-1">
                                                                </div>
                                                                <ul class="py-1">
                                                                    <template x-for="country in filteredCountries"
                                                                        :key="country.Admn_Cutr_Mast_UIN">
                                                                        <li @click="choose(country)"
                                                                            class="flex items-center gap-x-3 px-3 py-2 text-sm hover:bg-slate-100 cursor-pointer">
                                                                            <span
                                                                                :class="`fi fi-${(country?.Code || '').trim().toLowerCase()}`"></span>
                                                                            <span class="font-medium flex-1 truncate"
                                                                                x-text="country.Name"></span>
                                                                            <span class="text-gray-500"
                                                                                x-text="'+' + country.Phon_Code"></span>
                                                                        </li>
                                                                    </template>
                                                                    <li x-show="filteredCountries.length === 0"
                                                                        class="px-4 py-2 text-sm text-gray-500">No
                                                                        country found.</li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Phone Number -->
                                                <div class="sm:col-span-2">
                                                    <input type="tel"
                                                        wire:model.blur="phones.{{ $index }}.Phon_Numb"
                                                        @blur="markTouched('phones.{{ $index }}.Phon_Numb')"
                                                        @input="filterInput($event, 'numeric'); validatePhoneLength('phones.{{ $index }}.Phon_Numb', $event.target.value, {{ $index }})"
                                                        placeholder="Phone Number"
                                                        class="form-input-figma text-sm w-full"
                                                        :class="{
                                                            'border-red-500 ring-red-500': hasError(
                                                                'phones.{{ $index }}.Phon_Numb')
                                                        }"
                                                        maxlength="15">
                                                    <span x-show="hasError('phones.{{ $index }}.Phon_Numb')"
                                                        x-text="getError('phones.{{ $index }}.Phon_Numb')"
                                                        class="text-red-400 text-xs mt-1"></span>
                                                </div>
                                                <!-- Type -->
                                                <div class="sm:col-span-1">
                                                    <select wire:model.blur="phones.{{ $index }}.Phon_Type"
                                                        @change="markTouched('phones.{{ $index }}.Phon_Type')"
                                                        class="form-select-figma text-sm w-full"
                                                        :class="{
                                                            'border-red-500 ring-red-500': hasError(
                                                                'phones.{{ $index }}.Phon_Type')
                                                        }">
                                                        <option value="self">Self</option>
                                                        <option value="office">Office</option>
                                                        <option value="home">Home</option>
                                                    </select>
                                                    <span x-show="hasError('phones.{{ $index }}.Phon_Type')"
                                                        x-text="getError('phones.{{ $index }}.Phon_Type')"
                                                        class="text-red-400 text-xs mt-1"></span>
                                                    @error('phones.' . $index . '.Phon_Type')
                                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <!-- Messaging -->
                                                <div class="flex flex-col gap-2">
                                                    <label class="flex items-center gap-2 text-sm text-slate-400">
                                                        <input type="checkbox"
                                                            wire:model.blur="phones.{{ $index }}.Has_WtAp"
                                                            class="form-checkbox-figma">
                                                        WhatsApp
                                                    </label>
                                                    <label class="flex items-center gap-2 text-sm text-slate-400">
                                                        <input type="checkbox"
                                                            wire:model.blur="phones.{{ $index }}.Has_Telg"
                                                            class="form-checkbox-figma">
                                                        Telegram
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        @error('phones.' . $index . '.Phon_Numb')
                                            <span class="text-red-400 text-xs ml-1">{{ $message }}</span>
                                        @enderror
                                    @empty
                                        <p class="text-slate-500 text-sm pl-1">No phone numbers added.</p>
                                    @endforelse
                                </div>
                                <button type="button" wire:click="addPhone"
                                    class="mt-4 text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i>
                                    Add Phone Number
                                </button>
                            </div>

                            <!-- Emails -->
                            <div>
                                <h3
                                    class="font-medium text-slate-300 mb-4 flex items-center gap-2 text-sm uppercase tracking-wide">
                                    <i class="bi bi-envelope-fill text-green-400"></i>
                                    Email Addresses
                                </h3>
                                <div class="space-y-4">
                                    @forelse ($emails as $index => $email)
                                        <div class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600"
                                            wire:key="email-{{ $index }}">
                                            <!-- MODIFIED: Controls moved to the top right -->
                                            <div class="absolute top-4 right-4 flex items-center gap-4">
                                                <label for="primary_email_{{ $index }}"
                                                    class="flex items-center cursor-pointer gap-2">
                                                    <span class="text-sm font-medium text-slate-400">Preferable</span>
                                                    <input type="radio" id="primary_email_{{ $index }}"
                                                        name="primary_email" title="Set as preferable"
                                                        wire:click="setPrimaryEmail({{ $index }})"
                                                        @if ($email['Is_Prmy'] ?? false) checked @endif
                                                        class="form-radio-figma">
                                                </label>
                                                @if (count($emails) > 1)
                                                    <button type="button"
                                                        wire:click="removeEmail({{ $index }})"
                                                        title="Remove Email"
                                                        class="text-slate-500 hover:text-red-500 transition-colors">
                                                        <i class="bi bi-trash-fill text-lg"></i>
                                                    </button>
                                                @endif
                                            </div>
                                            <div class="flex-grow grid grid-cols-1 sm:grid-cols-3 gap-3 pt-8">
                                                <div class="sm:col-span-2">
                                                    <input type="email"
                                                        wire:model.blur="emails.{{ $index }}.Emai_Addr"
                                                        @blur="markTouched('emails.{{ $index }}.Emai_Addr'); validateField('emails', $event.target.value, {{ $index }})"
                                                        @input="validateField('emails', $event.target.value, {{ $index }})"
                                                        placeholder="example@domain.com"
                                                        class="form-input-figma text-sm w-full"
                                                        :class="{
                                                            'border-red-500 ring-red-500': hasError(
                                                                'emails.{{ $index }}.Emai_Addr')
                                                        }">
                                                    <span x-show="hasError('emails.{{ $index }}.Emai_Addr')"
                                                        x-text="getError('emails.{{ $index }}.Emai_Addr')"
                                                        class="text-red-400 text-xs mt-1"></span>
                                                </div>
                                                <select wire:model.blur="emails.{{ $index }}.Emai_Type"
                                                    @change="markTouched('emails.{{ $index }}.Emai_Type')"
                                                    class="form-select-figma text-sm w-full"
                                                    :class="{
                                                        'border-red-500 ring-red-500': hasError(
                                                            'emails.{{ $index }}.Emai_Type')
                                                    }">
                                                    <option value="Self Generated">Self Generated</option>
                                                    <option value="Office">Office</option>
                                                    <option value="Business">Business</option>
                                                </select>
                                                <span x-show="hasError('emails.{{ $index }}.Emai_Type')"
                                                    x-text="getError('emails.{{ $index }}.Emai_Type')"
                                                    class="text-red-400 text-xs mt-1"></span>
                                                @error('emails.' . $index . '.Emai_Type')
                                                    <span class="text-red-400 text-xs">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                        @error('emails.' . $index . '.Emai_Addr')
                                            <span class="text-red-400 text-xs ml-1">{{ $message }}</span>
                                        @enderror
                                    @empty
                                        <p class="text-slate-500 text-sm pl-1">No email addresses added.</p>
                                    @endforelse
                                </div>
                                <button type="button" wire:click="addEmail"
                                    class="mt-4 text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i>
                                    Add Email
                                </button>
                            </div>
                        </div>
                    </div>


                    <!-- Web Presence Card -->
                    <div class="figma-card">
                        <h2 class="figma-card-header text-green-200"><i class="bi bi-globe2 mr-2"></i>Web Presence
                        </h2>
                        <div class="p-6 grid grid-cols-1 sm:grid-cols-2 gap-5">

                            <!-- Website -->
                            <div class="relative">
                                <i
                                    class="bi bi-globe text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <input type="url" wire:model.blur="Web" placeholder="Website"
                                    @blur="markTouched('Web'); validateField('Web', $event.target.value)"
                                    @input="validateField('Web', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('Web') }" />
                                <span x-show="hasError('Web')" x-text="getError('Web')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('Web')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                            <!-- LinkedIn -->
                            <div class="relative">
                                <i
                                    class="bi bi-linkedin text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <input type="url" wire:model.blur="LnDn" placeholder="LinkedIn"
                                    @blur="markTouched('LnDn'); validateField('LnDn', $event.target.value)"
                                    @input="validateField('LnDn', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('LnDn') }" />
                                <span x-show="hasError('LnDn')" x-text="getError('LnDn')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('LnDn')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                            <!-- Twitter / X -->
                            <div class="relative">
                                <i
                                    class="bi bi-twitter-x text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <input type="url" wire:model.blur="Twtr" placeholder="Twitter / X"
                                    @blur="markTouched('Twtr'); validateField('Twtr', $event.target.value)"
                                    @input="validateField('Twtr', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('Twtr') }" />
                                <span x-show="hasError('Twtr')" x-text="getError('Twtr')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('Twtr')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                            <!-- Facebook -->
                            <div class="relative">
                                <i
                                    class="bi bi-facebook text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <input type="url" wire:model.blur="FcBk" placeholder="Facebook"
                                    @blur="markTouched('FcBk'); validateField('FcBk', $event.target.value)"
                                    @input="validateField('FcBk', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('FcBk') }" />
                                <span x-show="hasError('FcBk')" x-text="getError('FcBk')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('FcBk')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                            <!-- Instagram -->
                            <div class="relative">
                                <i
                                    class="bi bi-instagram text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <input type="url" wire:model.blur="Intg" placeholder="Instagram"
                                    @blur="markTouched('Intg'); validateField('Intg', $event.target.value)"
                                    @input="validateField('Intg', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('Intg') }" />
                                <span x-show="hasError('Intg')" x-text="getError('Intg')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('Intg')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                            <!-- Reddit -->
                            <div class="relative">
                                <i
                                    class="bi bi-reddit text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                                <input type="url" wire:model.blur="Redt" placeholder="Reddit"
                                    @blur="markTouched('Redt'); validateField('Redt', $event.target.value)"
                                    @input="validateField('Redt', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('Redt') }" />
                                <span x-show="hasError('Redt')" x-text="getError('Redt')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('Redt')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                            <!-- Yahoo -->
                            <div class="relative sm:col-span-2">
                                <i
                                    class="text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">Y!</i>
                                <input type="url" wire:model.blur="Yaho" placeholder="Yahoo"
                                    @blur="markTouched('Yaho'); validateField('Yaho', $event.target.value)"
                                    @input="validateField('Yaho', $event.target.value)"
                                    class="form-input-figma w-full pl-10"
                                    :class="{ 'border-red-500 ring-red-500': hasError('Yaho') }" />
                                <span x-show="hasError('Yaho')" x-text="getError('Yaho')"
                                    class="text-red-400 text-xs mt-1 ml-10 block"></span>
                                @error('Yaho')
                                    <span class="text-red-400 text-xs mt-1 ml-10 block">{{ $message }}</span>
                                @enderror
                            </div>

                        </div>
                    </div>

                    <!-- Employment Card -->
                    <div class="figma-card">
                        <h2 class="figma-card-header text-green-200"><i
                                class="bi bi-briefcase-fill mr-2"></i>Employment</h2>
                        <div class="p-6 space-y-6">
                            <div class="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-xl">
                                <button type="button" wire:click="$set('Empl_Type', 'job')"
                                    class="px-2 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200"
                                    :class="{ 'bg-blue-600 text-white shadow-md': @js($Empl_Type) === 'job', 'text-slate-400 hover:bg-slate-700': @js($Empl_Type) !== 'job' }">
                                    Job
                                </button>
                                <button type="button" wire:click="$set('Empl_Type', 'self-employed')"
                                    class="px-2 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200"
                                    :class="{ 'bg-blue-600 text-white shadow-md': @js($Empl_Type) === 'self-employed', 'text-slate-400 hover:bg-slate-700': @js($Empl_Type) !== 'self-employed' }">
                                    Self Employed
                                </button>
                            </div>

                            @if ($Empl_Type === 'job')
                                <div class="space-y-5">
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                        <div>
                                            <label for="Comp_Name" class="text-sm font-medium text-slate-400">Company
                                                Name</label>
                                            <input type="text" id="Comp_Name" wire:model.blur="Comp_Name"
                                                placeholder="e.g., ABC Corporation"
                                                @blur="markTouched('Comp_Name'); validateField('Comp_Name', $event.target.value)"
                                                @input="validateField('Comp_Name', $event.target.value)"
                                                class="form-input-figma mt-1"
                                                :class="{ 'border-red-500 ring-red-500': hasError('Comp_Name') }">
                                            <span x-show="hasError('Comp_Name')" x-text="getError('Comp_Name')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('Comp_Name')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div>
                                            <label for="Comp_Dsig"
                                                class="text-sm font-medium text-slate-400">Designation</label>
                                            <input type="text" id="Comp_Dsig" wire:model.blur="Comp_Dsig"
                                                placeholder="e.g., Senior Manager, Software Engineer"
                                                @blur="markTouched('Comp_Dsig')"
                                                @input="validateField('Comp_Dsig', $event.target.value)"
                                                class="form-input-figma mt-1"
                                                :class="{ 'border-red-500 ring-red-500': hasError('Comp_Dsig') }">
                                            <span x-show="hasError('Comp_Dsig')" x-text="getError('Comp_Dsig')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('Comp_Dsig')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div>
                                            <label for="Comp_LdLi" class="text-sm font-medium text-slate-400">Company
                                                Landline</label>
                                            <input type="tel" id="Comp_LdLi" wire:model.blur="Comp_LdLi"
                                                placeholder="e.g., 02012345678" @blur="markTouched('Comp_LdLi')"
                                                @input="filterInput($event, 'numeric'); validateField('Comp_LdLi', $event.target.value)"
                                                class="form-input-figma mt-1"
                                                :class="{ 'border-red-500 ring-red-500': hasError('Comp_LdLi') }">
                                            <span x-show="hasError('Comp_LdLi')" x-text="getError('Comp_LdLi')"
                                                class="text-red-400 text-xs mt-1"></span>
                                        </div>
                                        <div>
                                            <label for="Comp_Desp" class="text-sm font-medium text-slate-400">Company
                                                Business Description</label>
                                            <input type="text" id="Comp_Desp" wire:model.blur="Comp_Desp"
                                                placeholder="e.g., Software Development, Manufacturing"
                                                @blur="markTouched('Comp_Desp')"
                                                @input="validateField('Comp_Desp', $event.target.value)"
                                                class="form-input-figma mt-1"
                                                :class="{ 'border-red-500 ring-red-500': hasError('Comp_Desp') }">
                                            <span x-show="hasError('Comp_Desp')" x-text="getError('Comp_Desp')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('Comp_Desp')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div>
                                            <label for="Comp_Emai" class="text-sm font-medium text-slate-400">Company
                                                Email</label>
                                            <input type="email" id="Comp_Emai" wire:model.blur="Comp_Emai"
                                                placeholder="e.g., info@company.com" @blur="markTouched('Comp_Emai')"
                                                @input="validateField('Comp_Emai', $event.target.value)"
                                                class="form-input-figma mt-1"
                                                :class="{ 'border-red-500 ring-red-500': hasError('Comp_Emai') }">
                                            <span x-show="hasError('Comp_Emai')" x-text="getError('Comp_Emai')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('Comp_Emai')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div>
                                            <label for="Comp_Web" class="text-sm font-medium text-gray-200">Company
                                                Website</label>
                                            <input type="url" id="Comp_Web"
                                                placeholder="https://www.company.com" wire:model.blur="Comp_Web"
                                                @blur="markTouched('Comp_Web')"
                                                @input="validateField('Comp_Web', $event.target.value)"
                                                class="form-input-figma mt-1"
                                                :class="{ 'border-red-500 ring-red-500': hasError('Comp_Web') }">
                                            <span x-show="hasError('Comp_Web')" x-text="getError('Comp_Web')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('Comp_Web')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div>
                                        <label for="Comp_Addr" class="text-sm font-medium text-slate-400">Company
                                            Address</label>
                                        <textarea id="Comp_Addr" wire:model.blur="Comp_Addr" @blur="markTouched('Comp_Addr')"
                                            @input="validateField('Comp_Addr', $event.target.value)" rows="3"
                                            placeholder="Enter complete company address including street, city, state, and postal code"
                                            class="form-input-figma mt-1" :class="{ 'border-red-500 ring-red-500': hasError('Comp_Addr') }"></textarea>
                                        <span x-show="hasError('Comp_Addr')" x-text="getError('Comp_Addr')"
                                            class="text-red-400 text-xs mt-1"></span>
                                        @error('Comp_Addr')
                                            <span class="text-red-400 text-xs">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            @endif

                            @if ($Empl_Type === 'self-employed')
                                <div class="space-y-5">
                                    <div>
                                        <label for="Prfl_Name" class="text-sm font-medium text-slate-400">Profession /
                                            Service</label>
                                        <input type="text" id="Prfl_Name" wire:model.blur="Prfl_Name"
                                            @blur="markTouched('Prfl_Name')"
                                            @input="validateField('Prfl_Name', $event.target.value)"
                                            placeholder="e.g., Graphic Designer, Consultant, Freelance Developer"
                                            class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': hasError('Prfl_Name') }">
                                        <span x-show="hasError('Prfl_Name')" x-text="getError('Prfl_Name')"
                                            class="text-red-400 text-xs mt-1"></span>
                                        @error('Prfl_Name')
                                            <span class="text-red-400 text-xs">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div>
                                        <label for="Prfl_Addr" class="text-sm font-medium text-slate-400">Business
                                            Address</label>
                                        <textarea id="Prfl_Addr" wire:model.blur="Prfl_Addr" @blur="markTouched('Prfl_Addr')"
                                            @input="validateField('Prfl_Addr', $event.target.value)" rows="3"
                                            placeholder="Enter your business address or work location" class="form-input-figma mt-1"
                                            :class="{ 'border-red-500 ring-red-500': hasError('Prfl_Addr') }"></textarea>
                                        <span x-show="hasError('Prfl_Addr')" x-text="getError('Prfl_Addr')"
                                            class="text-red-400 text-xs mt-1"></span>
                                        @error('Prfl_Addr')
                                            <span class="text-red-400 text-xs">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>


                    <!-- References Card -->
                    <div class="figma-card">
                        <h2 class="figma-card-header text-green-200"><i class="bi bi-people-fill mr-2"></i>Reference
                            Persons</h2>
                        <div class="p-6 space-y-6">
                            @forelse ($references as $index => $reference)
                                <div class="relative p-5 border border-white/[.10] rounded-md"
                                    wire:key="reference-{{ $index }}">
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                        <!-- Reference Person Name -->
                                        <div>
                                            <label class="block text-sm font-medium text-slate-400">Reference Person
                                                Name</label>
                                            <input type="text"
                                                wire:model.blur="references.{{ $index }}.Refa_Name"
                                                @blur="markTouched('references.{{ $index }}.Refa_Name')"
                                                @input="filterInput($event, 'alpha'); validateField('references', $event.target.value, {{ $index }}, 'Refa_Name')"
                                                class="form-input-figma mt-1"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'references.{{ $index }}.Refa_Name')
                                                }"
                                                placeholder="John Doe">
                                            <span x-show="hasError('references.{{ $index }}.Refa_Name')"
                                                x-text="getError('references.{{ $index }}.Refa_Name')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('references.' . $index . '.Refa_Name')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <!-- Relationship -->
                                        <div>
                                            <label
                                                class="block text-sm font-medium text-slate-400">Relationship</label>
                                            <input type="text"
                                                wire:model.blur="references.{{ $index }}.Refa_Rsip"
                                                @blur="markTouched('references.{{ $index }}.Refa_Rsip')"
                                                @input="filterInput($event, 'alpha'); validateField('references', $event.target.value, {{ $index }}, 'Refa_Rsip')"
                                                class="form-input-figma mt-1"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'references.{{ $index }}.Refa_Rsip')
                                                }"
                                                placeholder="Former Colleague">
                                            <span x-show="hasError('references.{{ $index }}.Refa_Rsip')"
                                                x-text="getError('references.{{ $index }}.Refa_Rsip')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('references.' . $index . '.Refa_Rsip')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <!-- Email Address -->
                                        <div>
                                            <label class="block text-sm font-medium text-slate-400">Email
                                                Address</label>
                                            <input type="email"
                                                wire:model.blur="references.{{ $index }}.Refa_Emai"
                                                @blur="markTouched('references.{{ $index }}.Refa_Emai'); validateField('references', $event.target.value, {{ $index }}, 'Refa_Emai')"
                                                @input="validateField('references', $event.target.value, {{ $index }}, 'Refa_Emai')"
                                                class="form-input-figma mt-1"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'references.{{ $index }}.Refa_Emai')
                                                }"
                                                placeholder="john.doe@example.com">
                                            <span x-show="hasError('references.{{ $index }}.Refa_Emai')"
                                                x-text="getError('references.{{ $index }}.Refa_Emai')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('references.' . $index . '.Refa_Emai')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <!-- Phone Number -->
                                        <div>
                                            <label class="block text-sm font-medium text-slate-400">Phone
                                                Number</label>
                                            <input type="tel"
                                                wire:model.blur="references.{{ $index }}.Refa_Phon"
                                                @blur="markTouched('references.{{ $index }}.Refa_Phon')"
                                                @input="filterInput($event, 'numeric'); validateField('references', $event.target.value, {{ $index }}, 'Refa_Phon')"
                                                class="form-input-figma mt-1"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'references.{{ $index }}.Refa_Phon')
                                                }"
                                                placeholder="9876543210">
                                            <span x-show="hasError('references.{{ $index }}.Refa_Phon')"
                                                x-text="getError('references.{{ $index }}.Refa_Phon')"
                                                class="text-red-400 text-xs mt-1"></span>
                                            @error('references.' . $index . '.Refa_Phon')
                                                <span class="text-red-400 text-xs">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="absolute top-4 right-4">
                                        <button type="button" wire:click="removeReference({{ $index }})"
                                            class="text-slate-500 hover:text-red-500 transition-colors">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </div>
                                </div>
                            @empty
                                <p class="text-slate-500 text-sm">No references added.</p>
                            @endforelse

                            @if (count($references) < 5)
                                <button type="button" wire:click="addReference"
                                    class="text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-2">
                                    <i class="bi bi-plus-circle"></i>
                                    Add Reference
                                </button>
                            @endif
                        </div>
                    </div>
                    {{-- Error Display Section --}}
                    @if ($errors->any())
                        <div class="mt-4 bg-red-900/50 border border-red-500/50 rounded-md p-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-exclamation-triangle-fill text-red-400 text-lg"></i>
                                </div>
                                <div class="ml-3">
                                    <h3 class="text-sm font-medium text-red-400">There were errors with your
                                        submission:
                                    </h3>
                                    <div class="mt-2 text-sm text-red-300">
                                        <ul class="list-disc list-inside space-y-1">
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif


                    <!-- Form Actions -->
                    <div class="flex justify-end items-center gap-4 mt-6">
                        <button type="submit" class="figma-button-primary">
                            <div wire:loading.remove wire:target="save">
                                <i class="bi bi-person-fill-add"></i>
                                <span>Submit</span>
                            </div>
                            <div wire:loading wire:target="save">
                                <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10"
                                        stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor"
                                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                                    </path>
                                </svg>
                                <span>Saving...</span>
                            </div>
                        </button>
                    </div>
                </form>
            </div>

            {{-- Scripts section updated to match new template --}}
            @push('scripts')
                {{-- Cropper.js library --}}
                <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css">

                {{-- Link Expiry Timer Script (Kept from original link file) --}}
                <script>
                    function linkExpiryTimer(expiryTime) {
                        return {
                            timeLeft: {
                                total: 0,
                                hours: 0,
                                minutes: 0,
                                seconds: 0
                            },
                            expiryDate: '',
                            interval: null,
                            init() {
                                const expiry = new Date(expiryTime);
                                this.expiryDate = expiry.toLocaleDateString() + ' at ' + expiry.toLocaleTimeString();
                                this.updateTimer();
                                this.interval = setInterval(() => {
                                    this.updateTimer();
                                }, 1000);
                            },
                            updateTimer() {
                                const now = new Date().getTime();
                                const expiry = new Date(this.expiryTime || expiryTime).getTime();
                                const distance = expiry - now;

                                if (distance < 0) {
                                    this.timeLeft = {
                                        total: 0,
                                        hours: 0,
                                        minutes: 0,
                                        seconds: 0
                                    };
                                    if (this.interval) {
                                        clearInterval(this.interval);
                                    }
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 2000);
                                    return;
                                }

                                this.timeLeft = {
                                    total: distance,
                                    hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                                    minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
                                    seconds: Math.floor((distance % (1000 * 60)) / 1000)
                                };
                            },
                            destroy() {
                                if (this.interval) {
                                    clearInterval(this.interval);
                                }
                            }
                        }
                    }
                </script>

                {{-- AlpineJS Image Cropper Component --}}
                <script>
                    function imageCropperComponent() {
                        return {
                            showCropper: false,
                            imageToCrop: null,
                            cropper: null,
                            handleFileSelect(event) {
                                const file = event.target.files[0];
                                if (!file) return;
                                const reader = new FileReader();
                                reader.onload = (e) => {
                                    this.imageToCrop = e.target.result;
                                    this.showCropper = true;
                                    this.$nextTick(() => {
                                        this.initCropper();
                                    });
                                };
                                reader.readAsDataURL(file);
                            },
                            initCropper() {
                                if (this.cropper) {
                                    this.cropper.destroy();
                                }
                                this.cropper = new Cropper(this.$refs.imageToCropEl, {
                                    aspectRatio: 1,
                                    viewMode: 1,
                                });
                            },
                            cropImage() {
                                let canvas = this.cropper.getCroppedCanvas({
                                    width: 512,
                                    height: 512
                                });
                                canvas.toBlob((blob) => {
                                    const file = new File([blob], 'cropped-avatar.png', {
                                        type: blob.type
                                    });
                                    this.$wire.upload('Prfl_Pict', file, (uploadedFilename) => {
                                        this.closeCropper();
                                    });
                                });
                            },
                            closeCropper() {
                                this.showCropper = false;
                                if (this.cropper) {
                                    this.cropper.destroy();
                                    this.cropper = null;
                                }
                                this.$refs.fileInput.value = "";
                            }
                        }
                    }
                </script>

                {{-- Livewire event listeners --}}
                <script>
                    document.addEventListener('livewire:init', () => {
                        Livewire.on('contact-save-success', (data) => {
                            console.log('Contact saved successfully:', data);
                        });

                        Livewire.on('contact-save-error', (errors) => {
                            console.error('Contact save failed with errors:', errors);
                            if (errors && typeof errors === 'object') {
                                Object.keys(errors).forEach(field => {
                                    console.error(`Validation error for ${field}:`, errors[field]);
                                });
                            }
                        });
                    });
                </script>

                <script>
                    function contactFormValidator() {
                        return {
                            errors: {},
                            touchedFields: {},

                            init() {
                                // Watch for phone changes to revalidate
                                this.$watch('$wire.phones', (value) => {
                                    if (value && Array.isArray(value)) {
                                        value.forEach((phone, index) => {
                                            const fieldKey = `phones.${index}.Phon_Numb`;
                                            if (this.touchedFields[fieldKey] && phone.Phon_Numb) {
                                                this.validatePhoneLength(fieldKey, phone.Phon_Numb, index);
                                            }
                                        });
                                    }
                                });
                            },

                            markTouched(field) {
                                this.touchedFields[field] = true;
                            },

                            hasError(field) {
                                return !!(this.touchedFields[field] && this.errors[field]);
                            },

                            getError(field) {
                                return this.errors[field] || '';
                            },

                            filterInput(event, type) {
                                const input = event.target;
                                let value = input.value;

                                switch (type) {
                                    case 'alpha':
                                        value = value.replace(/[^a-zA-Z\s-]/g, '');
                                        break;
                                    case 'numeric':
                                        value = value.replace(/[^0-9]/g, '');
                                        break;
                                }

                                if (input.value !== value) {
                                    input.value = value;
                                    const wireModel = input.getAttribute('wire:model.blur');
                                    if (wireModel) {
                                        @this.set(wireModel, value);
                                    }
                                }
                            },

                            // PHONE LENGTH VALIDATION
                            validatePhoneLength(fieldKey, value, phoneIndex) {
                                const countries = @js($allCountries);
                                const phones = @this.get('phones');

                                if (!phones || !phones[phoneIndex]) {
                                    return;
                                }

                                const countryCode = phones[phoneIndex].Cutr_Code;
                                const country = countries.find(c => c.Phon_Code?.trim() === countryCode?.trim());

                                if (!country) {
                                    this.errors[fieldKey] = 'Please select a valid country';
                                    return;
                                }

                                const requiredLength = country.MoNo_Digt;
                                const currentLength = value.length;

                                if (currentLength === 0) {
                                    delete this.errors[fieldKey];
                                } else if (currentLength < requiredLength) {
                                    this.errors[fieldKey] = `Phone number must be ${requiredLength} digits`;
                                } else if (currentLength > requiredLength) {
                                    this.errors[fieldKey] = `Phone number cannot exceed ${requiredLength} digits`;
                                } else {
                                    delete this.errors[fieldKey];
                                }
                            },

                            validateField(field, value, index = null, subField = null) {
                                let fieldKey = field;
                                if (index !== null) {
                                    if (field === 'phones') fieldKey = `phones.${index}.Phon_Numb`;
                                    if (field === 'emails') fieldKey = `emails.${index}.Emai_Addr`;
                                    if (field === 'references' && subField) fieldKey = `references.${index}.${subField}`;
                                    if (field === 'addresses' && subField) fieldKey = `addresses.${index}.${subField}`;
                                }

                                delete this.errors[fieldKey];

                                switch (field) {
                                    case 'FaNm':
                                        if (!value || value.trim() === '') {
                                            this.errors[fieldKey] = 'First name is required.';
                                        } else if (value.length > 50) {
                                            this.errors[fieldKey] = 'Max 50 characters.';
                                        }
                                        break;

                                    case 'MiNm':
                                    case 'LaNm':
                                        if (value && value.length > 50) {
                                            this.errors[fieldKey] = 'Max 50 characters.';
                                        }
                                        break;


                                    case 'Brth_Dt':
                                        if (value && new Date(value) >= new Date()) {
                                            this.errors[fieldKey] = 'Birth date must be before today.';
                                        }
                                        break;

                                    case 'Comp_Name':
                                    case 'Comp_Dsig':
                                    case 'Prfl_Name':
                                        if (value && value.length > 255) {
                                            this.errors[fieldKey] = 'Max 255 characters.';
                                        }
                                        break;

                                    case 'Comp_Desp':
                                        if (value && value.length > 1000) {
                                            this.errors[fieldKey] = 'Max 1000 characters.';
                                        }
                                        break;

                                    case 'Comp_Emai':
                                        if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                                            this.errors[fieldKey] = 'Please enter a valid email.';
                                        }
                                        break;

                                    case 'Comp_LdLi':
                                        if (value && value.length > 20) {
                                            this.errors[fieldKey] = 'Max 20 digits.';
                                        }
                                        break;

                                        // ✅ ALL WEB PRESENCE FIELDS WITH SAME VALIDATION
                                    case 'Web':
                                    case 'Comp_Web':
                                    case 'LnDn':
                                    case 'Twtr':
                                    case 'FcBk':
                                    case 'Intg':
                                    case 'Redt':
                                    case 'Yaho':
                                        if (value && value.trim() !== '') {
                                            // Check if it's a valid URL format
                                            if (!/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/i.test(value)) {
                                                this.errors[fieldKey] = 'Please enter a valid URL.';
                                            }
                                            // Check length
                                            else if (value.length > 255) {
                                                this.errors[fieldKey] = 'URL may not be greater than 255 characters.';
                                            }
                                            // Optional: Check domain-specific validation (matches backend logic)
                                            else {
                                                const urlLower = value.toLowerCase().replace(/\/$/, ''); // remove trailing slash

                                                if (field === 'LnDn' && !urlLower.includes('linkedin.com')) {
                                                    this.errors[fieldKey] = 'LinkedIn URL must contain linkedin.com';
                                                } else if (field === 'Twtr' && !urlLower.includes('twitter.com') && !urlLower.includes(
                                                        'x.com')) {
                                                    this.errors[fieldKey] = 'Twitter/X URL must contain twitter.com or x.com';
                                                } else if (field === 'FcBk' && !urlLower.includes('facebook.com')) {
                                                    this.errors[fieldKey] = 'Facebook URL must contain facebook.com';
                                                } else if (field === 'Intg' && !urlLower.includes('instagram.com')) {
                                                    this.errors[fieldKey] = 'Instagram URL must contain instagram.com';
                                                } else if (field === 'Redt' && !urlLower.includes('reddit.com')) {
                                                    this.errors[fieldKey] = 'Reddit URL must contain reddit.com';
                                                } else if (field === 'Yaho' && !urlLower.includes('yahoo.com')) {
                                                    this.errors[fieldKey] = 'Yahoo URL must contain yahoo.com';
                                                }
                                            }
                                        }
                                        break;

                                    case 'Comp_Addr':
                                    case 'Prfl_Addr':
                                        if (value && value.length > 1000) {
                                            this.errors[fieldKey] = 'Max 1000 characters.';
                                        }
                                        break;

                                    case 'emails':
                                        if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                                            this.errors[fieldKey] = 'Please enter a valid email.';
                                        }
                                        break;

                                    case 'addresses':
                                        if (subField === 'Addr' && value && value.length > 1000) {
                                            this.errors[fieldKey] = 'Max 1000 characters.';
                                        } else if ((subField === 'Loca' || subField === 'Lndm') && value && value.length > 255) {
                                            this.errors[fieldKey] = 'Max 255 characters.';
                                        }
                                        break;

                                    case 'references':
                                        if (subField === 'Refa_Name') {
                                            if (value && value.trim() === '') {
                                                this.errors[fieldKey] = 'Reference name cannot be empty.';
                                            } else if (value && !/^[a-zA-Z\s\-\.\']+$/.test(value)) {
                                                this.errors[fieldKey] = 'Name contains invalid characters.';
                                            }
                                        } else if (subField === 'Refa_Rsip') {
                                            if (value && !/^[a-zA-Z\s\-\.\']+$/.test(value)) {
                                                this.errors[fieldKey] = 'Relationship contains invalid characters.';
                                            }
                                        } else if (subField === 'Refa_Emai') {
                                            if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                                                this.errors[fieldKey] = 'Please enter a valid email address.';
                                            }
                                        } else if (subField === 'Refa_Phon') {
                                            if (value && (value.length < 7 || value.length > 15)) {
                                                this.errors[fieldKey] = 'Phone number must be between 7 and 15 digits.';
                                            }
                                        }
                                        break;
                                }
                            },
                            validateForm() {
                                const faName = document.getElementById('FaNm')?.value;
                                this.validateField('FaNm', faName);
                                this.markTouched('FaNm');

                                // Validate all phone numbers
                                const phones = @this.get('phones');
                                if (phones && Array.isArray(phones)) {
                                    phones.forEach((phone, index) => {
                                        const fieldKey = `phones.${index}.Phon_Numb`;
                                        this.markTouched(fieldKey);
                                        if (phone.Phon_Numb) {
                                            this.validatePhoneLength(fieldKey, phone.Phon_Numb, index);
                                        }
                                    });
                                }

                                return Object.keys(this.errors).length === 0;
                            }
                        }
                    }
                </script>
            @endpush

            @once
                <script>
                    const allCountries = @json($allCountries->toArray());

                    function countryPicker(initialCode, livewireIndex) {
                        return {
                            open: false,
                            search: '',
                            selectedCountry: null,

                            init() {
                                this.selectedCountry = allCountries.find(c => c.Phon_Code == initialCode) || allCountries[0];
                                if (this.selectedCountry) {
                                    const model = `phones.${livewireIndex}.Cutr_Code`;
                                    this.$wire.set(model, this.selectedCountry.Phon_Code);
                                }
                            },

                            get filteredCountries() {
                                if (!this.search) return allCountries;
                                const q = this.search.toLowerCase();
                                return allCountries.filter(c =>
                                    c.Name.toLowerCase().includes(q) ||
                                    c.Phon_Code.includes(this.search) ||
                                    c.Code.toLowerCase().includes(q)
                                );
                            },

                            choose(country) {
                                this.selectedCountry = country;
                                this.open = false;
                                this.search = '';
                                const model = `phones.${livewireIndex}.Cutr_Code`;
                                this.$wire.set(model, country.Phon_Code);

                                // Trigger phone validation after country change
                                const phoneInput = document.querySelector(
                                    `input[wire\\:model\\.blur="phones.${livewireIndex}.Phon_Numb"]`
                                );
                                if (phoneInput && phoneInput.value) {
                                    window.dispatchEvent(new CustomEvent('validate-phone-length', {
                                        detail: {
                                            fieldKey: `phones.${livewireIndex}.Phon_Numb`,
                                            value: phoneInput.value,
                                            index: livewireIndex
                                        }
                                    }));
                                }
                            },

                            updateFromPrimary(detail) {
                                const newCode = detail.newPhoneCode;
                                const newCountry = allCountries.find(c => c.Phon_Code == newCode);
                                if (newCountry) {
                                    this.selectedCountry = newCountry;
                                    const model = `phones.${livewireIndex}.Cutr_Code`;
                                    this.$wire.set(model, newCountry.Phon_Code);
                                }
                            }
                        }
                    }
                </script>
            @endonce

            @script
                <script>
                    $wire.on('validation-errors', (errors) => {
                        console.error('Livewire validation errors received:', errors);
                    });

                    $wire.on('save-failed', (data) => {
                        console.error('Save operation failed:', data);
                    });

                    $wire.on('save-success', (data) => {
                        console.log('Contact saved successfully:', data);
                    });
                </script>
            @endscript
        @endif
    </div>
</div>
