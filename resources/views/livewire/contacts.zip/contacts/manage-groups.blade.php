<div>
    <!-- ========================================== -->
    <!-- 1. MAIN "MANAGE GROUPS" MODAL (LOWEST Z-INDEX) -->
    <!-- ========================================== -->
    @if ($showManageGroupsModal)
        <div class="fixed inset-0 z-30 flex items-center justify-center p-4 sm:p-6">
            <!-- Backdrop -->
            <div wire:click="closeAllModals" class="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
                x-data x-transition.opacity></div>

            <!-- Panel -->
            <div x-data="{ show: @entangle('showManageGroupsModal') }" x-show="show" x-transition.scale.origin.center
                class="relative z-10 bg-slate-800 rounded-lg text-left overflow-hidden shadow-2xl w-full max-w-4xl border border-slate-700/50 flex flex-col max-h-[85vh]">

                <!-- Header Section -->
                <div
                    class="bg-gradient-to-r from-slate-800 to-slate-700/80 px-6 sm:px-8 py-6 sm:py-8 border-b border-slate-700/50 flex-shrink-0">
                    <div class="flex justify-between items-center gap-4">
                        <div class="flex items-center gap-3">
                            <div class="p-2.5 bg-blue-500/20 rounded-lg">
                                <i class="bi bi-diagram-3-fill text-blue-400 text-xl"></i>
                            </div>
                            <div>
                                <h2 id="manage-groups-title" class="text-2xl font-bold text-white">Manage Contact Groups
                                </h2>
                                <p class="text-sm text-gray-400 mt-1">Create, organize, and assign contacts to groups
                                </p>
                            </div>
                        </div>
                        <button wire:click="closeAllModals"
                            class="p-2 hover:bg-slate-700 text-gray-400 hover:text-white rounded-lg transition-all duration-200"
                            aria-label="Close dialog">
                            <i class="bi bi-x-lg text-xl"></i>
                        </button>
                    </div>
                </div>

                <!-- Content Section -->
                <div class="flex-1 overflow-y-auto">
                    <div class="px-6 sm:px-8 py-6 sm:py-8">
                        <!-- Create Button -->
                        <div class="mb-6">
                            <button wire:click="openCreateModal"
                                class="inline-flex items-center justify-center gap-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/25 group">
                                <i class="bi bi-plus-circle text-lg group-hover:scale-110 transition-transform"></i>
                                <span>Create New Group</span>
                            </button>
                        </div>

                        <!-- Groups Table -->
                        @if ($allGroups->count() > 0)
                            <div
                                class="overflow-x-auto rounded-lg border border-slate-700/50 bg-slate-900/30 backdrop-blur-xs">
                                <table class="w-full">
                                    <thead>
                                        <tr class="bg-slate-800/80 border-b border-slate-700/50">
                                            <th class="px-6 py-4 text-left">
                                                <span
                                                    class="text-xs font-semibold text-gray-400 uppercase tracking-widest">Group
                                                    Name</span>
                                            </th>
                                            <th class="px-6 py-4 text-left">
                                                <span
                                                    class="text-xs font-semibold text-gray-400 uppercase tracking-widest">Parent
                                                    Group</span>
                                            </th>
                                            <th class="px-6 py-4 text-center">
                                                <span
                                                    class="text-xs font-semibold text-gray-400 uppercase tracking-widest">Contacts</span>
                                            </th>
                                            <th class="px-6 py-4 text-right">
                                                <span
                                                    class="text-xs font-semibold text-gray-400 uppercase tracking-widest">Actions</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-700/30">
                                        @foreach ($allGroups as $group)
                                            <tr wire:key="group-{{ $group->Admn_Grup_Mast_UIN }}"
                                                class="hover:bg-slate-800/50 transition-colors duration-150 group">
                                                <!-- Group Name -->
                                                <td class="px-6 py-4">
                                                    <div class="flex items-center gap-3">
                                                        <div
                                                            class="p-2 bg-slate-700/50 group-hover:bg-slate-700 rounded-md transition-colors">
                                                            <i class="bi bi-folder text-gray-400 text-sm"></i>
                                                        </div>
                                                        <div>
                                                            <p class="text-sm font-semibold text-gray-100">
                                                                {{ $group->Name }}</p>
                                                          
                                                        </div>
                                                    </div>
                                                </td>

                                                <!-- Parent Group -->
                                                <td class="px-6 py-4">
                                                    @if ($group->parent)
                                                        <div class="flex items-center gap-2">
                                                            <span
                                                                class="inline-block w-2 h-2 bg-blue-400 rounded-full"></span>
                                                            <span
                                                                class="text-sm text-gray-300">{{ $group->parent->Name }}</span>
                                                        </div>
                                                    @else
                                                        <span
                                                            class="inline-flex items-center gap-2 px-2.5 py-1 bg-gray-700/30 rounded text-xs text-gray-400">
                                                            <i class="bi bi-dash"></i> Root Group
                                                        </span>
                                                    @endif
                                                </td>

                                                <!-- Contacts Count -->
                                                <td class="px-6 py-4 text-center">
                                                    <button
                                                        wire:click="openViewAssignedModal({{ $group->Admn_Grup_Mast_UIN }})"
                                                        class="inline-flex items-center justify-center gap-2 px-3 py-1.5 bg-blue-500/20 rounded-full">
                                                        <i class="bi bi-people text-blue-400 text-xs"></i>
                                                        <span
                                                            class="text-sm font-semibold text-blue-300">{{ $group->users_count }}</span>
                                                    </button>
                                                </td>

                                                <!-- Actions -->
                                                <td class="px-6 py-4">
                                                    <div class="flex items-center justify-end gap-2">
                                                        <!-- Assign Button -->
                                                        <button
                                                            wire:click="openAssignModal({{ $group->Admn_Grup_Mast_UIN }})"
                                                            class="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-300 bg-slate-700/40 hover:bg-blue-600/30 hover:text-blue-300 rounded-md transition-all duration-200 group/btn"
                                                            title="Assign contacts to this group">
                                                            <i
                                                                class="bi bi-person-plus text-sm group-hover/btn:scale-110 transition-transform"></i>
                                                            <span class="hidden sm:inline">Assign</span>
                                                        </button>

                                                        <!-- Edit Button -->
                                                        <button
                                                            wire:click="openEditModal({{ $group->Admn_Grup_Mast_UIN }})"
                                                            class="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-300 bg-slate-700/40 hover:bg-amber-600/30 hover:text-amber-300 rounded-md transition-all duration-200 group/btn"
                                                            title="Edit group">
                                                            <i
                                                                class="bi bi-pencil text-sm group-hover/btn:scale-110 transition-transform"></i>
                                                            <span class="hidden sm:inline">Edit</span>
                                                        </button>

                                                        <!-- Delete Button -->
                                                        <button
                                                            wire:click="confirmDelete({{ $group->Admn_Grup_Mast_UIN }})"
                                                            wire:confirm="Are you sure? This will delete '{{ $group->Name }}' and unassign all {{ $group->users_count }} contact(s). This action cannot be undone."
                                                            class="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-300 bg-slate-700/40 hover:bg-red-600/30 hover:text-red-300 rounded-md transition-all duration-200 group/btn"
                                                            title="Delete group">
                                                            <i
                                                                class="bi bi-trash text-sm group-hover/btn:scale-110 transition-transform"></i>
                                                            <span class="hidden sm:inline">Delete</span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <!-- Empty State -->
                            <div
                                class="rounded-lg border-2 border-dashed border-slate-700/50 bg-slate-900/20 px-6 sm:px-8 py-12 sm:py-16 text-center">
                                <div class="flex justify-center mb-4">
                                    <div class="p-4 bg-slate-700/30 rounded-full">
                                        <i class="bi bi-inbox text-4xl text-gray-500"></i>
                                    </div>
                                </div>
                                <h3 class="text-lg font-semibold text-gray-300 mb-2">No Groups Yet</h3>
                                <p class="text-sm text-gray-500 mb-6">Create your first group to organize and manage
                                    your contacts.</p>
                                <button wire:click="openCreateModal"
                                    class="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-200">
                                    <i class="bi bi-plus-circle"></i>
                                    <span>Create Your First Group</span>
                                </button>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- ========================================== -->
    <!-- 2. CREATE/EDIT GROUP MODAL (MIDDLE Z-INDEX) -->
    <!-- ========================================== -->
    @if ($showCreateEditModal)
        <div class="fixed inset-0 z-40 flex items-center justify-center p-4">
            <!-- Backdrop -->
            <div wire:click="closeModal" class="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" x-data
                x-transition.opacity></div>

            <!-- Panel -->
            <form wire:submit.prevent="saveGroup" x-data="{ show: @entangle('showCreateEditModal') }" x-show="show"
                x-transition.scale.origin.center
                class="relative z-10 bg-slate-800 rounded-lg text-left overflow-hidden shadow-2xl w-full max-w-md border border-slate-700/50">

                <!-- Header -->
                <div
                    class="bg-gradient-to-r from-slate-800 to-slate-700/80 px-6 sm:px-8 py-6 border-b border-slate-700/50">
                    <div class="flex justify-between items-start gap-4">
                        <div>
                            <h3 id="form-title" class="text-xl font-bold text-white">
                                {{ $editingGroupId ? '✏️ Edit Group' : '➕ Create New Group' }}
                            </h3>
                            <p class="text-sm text-gray-400 mt-1">
                                {{ $editingGroupId ? 'Update group details' : 'Add a new group to organize contacts' }}
                            </p>
                        </div>
                        <button type="button" wire:click="closeModal"
                            class="p-2 hover:bg-slate-700 text-gray-400 hover:text-white rounded-lg transition-all duration-200"
                            aria-label="Close">
                            <i class="bi bi-x-lg text-xl"></i>
                        </button>
                    </div>
                </div>

                <!-- Content -->
                <div class="px-6 sm:px-8 py-6 space-y-5">
                    <!-- Parent Group Select -->
                    <div>
                        <label for="parent_grup_uin" class="block text-sm font-semibold text-gray-200 mb-2">
                            <i class="bi bi-diagram-3 text-blue-400 mr-2"></i>Parent Group
                        </label>
                        <select id="parent_grup_uin" wire:model.live="parent_grup_uin"
                            class="w-full bg-slate-700/50 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 py-2.5 px-3 appearance-none cursor-pointer hover:bg-slate-700/70"
                            style="background-image: url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22none%22 stroke=%229ca3af%22 stroke-width=%222%22><polyline points=%226 9 12 15 18 9%22></polyline></svg>'); background-position: right 0.75rem center; background-repeat: no-repeat; background-size: 1.25rem; padding-right: 2.5rem;">
                            <option value="">Select a parent...</option>
                            @foreach ($parentGroupOptions as $option)
                                <option value="{{ $option->Admn_Grup_Mast_UIN }}">{{ $option->Name }}</option>
                            @endforeach
                        </select>
                        @error('parent_grup_uin')
                            <div class="mt-2 flex items-center gap-2 text-red-400 text-sm">
                                <i class="bi bi-exclamation-circle"></i>
                                <span>{{ $message }}</span>
                            </div>
                        @enderror
                    </div>

                    <!-- Group Name Input -->
                    <div>
                        <label for="name" class="block text-sm font-semibold text-gray-200 mb-2">
                            <i class="bi bi-tag text-blue-400 mr-2"></i>Group Name
                        </label>
                        <input type="text" id="name" wire:model.live="name"
                            placeholder="e.g., 'Clients', 'Family', 'VIP'"
                            class="w-full bg-slate-700/50 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 py-2.5 px-3 placeholder-gray-500"
                            maxlength="255">
                        @error('name')
                            <div class="mt-2 flex items-center gap-2 text-red-400 text-sm">
                                <i class="bi bi-exclamation-circle"></i>
                                <span>{{ $message }}</span>
                            </div>
                        @enderror
                        <p class="mt-1.5 text-xs text-gray-500">{{ strlen($name) }}/255 characters</p>
                    </div>
                </div>

                <!-- Footer -->
                <div
                    class="bg-slate-800/50 px-6 sm:px-8 py-4 border-t border-slate-700/50 flex gap-3 justify-end flex-row-reverse">
                    <button type="submit"
                        class="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/25 group">
                        <span wire:loading.remove wire:target="saveGroup">
                            <i class="bi bi-check-circle group-hover:scale-110 transition-transform"></i>
                            {{ $editingGroupId ? 'Save Changes' : 'Create Group' }}
                        </span>
                        <span wire:loading wire:target="saveGroup" class="flex items-center gap-2">
                            <i class="bi bi-arrow-repeat animate-spin"></i>
                            Saving...
                        </span>
                    </button>
                    <button type="button" wire:click="closeModal"
                        class="inline-flex items-center justify-center gap-2 bg-slate-700/50 hover:bg-slate-700 text-gray-300 hover:text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200">
                        <i class="bi bi-x-circle"></i>
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    @endif

    <!-- ========================================== -->
    <!-- 3. ASSIGN CONTACTS MODAL (HIGHEST Z-INDEX) -->
    <!-- ========================================== -->
    @if ($showAssignModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4">
            <!-- Backdrop -->
            <div wire:click="closeModal" class="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
                x-data x-transition.opacity></div>

            <!-- Panel -->
            <div x-data="{ show: @entangle('showAssignModal') }" x-show="show" x-transition.scale.origin.center
                class="relative z-10 bg-slate-800 rounded-lg text-left overflow-hidden shadow-2xl w-full max-w-2xl border border-slate-700/50 flex flex-col max-h-[70vh]">

                <!-- Header (Fixed) -->
                <div
                    class="bg-gradient-to-r from-slate-800 to-slate-700/80 px-6 sm:px-8 py-6 border-b border-slate-700/50 flex-shrink-0">
                    <div class="flex justify-between items-start gap-4">
                        <div>
                            <h3 id="assign-title" class="text-xl font-bold text-white flex items-center gap-2">
                                <i class="bi bi-person-plus-fill text-blue-400"></i>Assign Contacts
                            </h3>
                            <p class="text-sm text-gray-400 mt-2">
                                <span
                                    class="inline-block px-2.5 py-1 bg-blue-500/20 text-blue-300 rounded text-xs font-semibold">
                                    To: {{ $groupForAssignment?->Name }}
                                </span>
                            </p>
                        </div>
                        <button type="button" wire:click="closeModal"
                            class="p-2 hover:bg-slate-700 text-gray-400 hover:text-white rounded-lg transition-all duration-200"
                            aria-label="Close">
                            <i class="bi bi-x-lg text-xl"></i>
                        </button>
                    </div>

                    <!-- Search Bar -->
                    <div class="mt-4 relative">
                        <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-500"></i>
                        <input type="text" wire:model.live.debounce.300ms="searchUnassigned"
                            placeholder="Search by name or company..."
                            class="w-full bg-slate-700/50 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 py-2.5 px-3 pl-10 placeholder-gray-500">
                    </div>
                </div>

                <!-- Contact List (Scrollable) -->
                <div class="flex-1 overflow-y-auto">
                    <div class="px-6 sm:px-8 py-4">
                        @if ($this->unassignedContacts->count() > 0)
                            <div class="space-y-2">
                                @foreach ($this->unassignedContacts as $contact)
                                    <label wire:key="contact-{{ $contact->Admn_User_Mast_UIN }}"
                                        class="flex items-center gap-3 cursor-pointer p-3 rounded-lg bg-slate-700/20 hover:bg-slate-700/40 border border-transparent hover:border-blue-500/30 transition-all duration-150 group">
                                        <input type="checkbox" wire:model.live="selectedContacts"
                                            value="{{ $contact->Admn_User_Mast_UIN }}"
                                            class="w-4 h-4 rounded border-gray-500 text-blue-500 focus:ring-2 focus:ring-blue-500 bg-slate-900 cursor-pointer flex-shrink-0">
                                        <div class="flex-1 min-w-0">
                                            <p
                                                class="text-sm font-semibold text-gray-200 group-hover:text-blue-300 transition-colors truncate">
                                                {{ trim($contact->FaNm . ' ' . $contact->LaNm) }}
                                            </p>
                                            @if ($contact->Comp_Name)
                                                <p class="text-xs text-gray-500 truncate">{{ $contact->Comp_Name }}
                                                </p>
                                            @endif
                                        </div>
                                        @if ($contact->phones->first())
                                            <p class="text-xs text-gray-500 flex-shrink-0">
                                                {{ $contact->phones->first()->Phon_Numb }}</p>
                                        @endif
                                    </label>
                                @endforeach
                            </div>
                        @else
                            <!-- Empty State -->
                            <div class="text-center py-16">
                                <div class="flex justify-center mb-4">
                                    <div class="p-3 bg-slate-700/30 rounded-full">
                                        <i class="bi bi-inbox text-4xl text-gray-500"></i>
                                    </div>
                                </div>
                                <p wire:loading.remove class="text-base text-gray-400 font-medium">No unassigned
                                    contacts</p>
                                <p wire:loading
                                    class="text-base text-blue-400 font-medium flex items-center justify-center gap-2">
                                    <i class="bi bi-arrow-repeat animate-spin"></i>
                                    Searching...
                                </p>
                                <p class="text-sm text-gray-500 mt-2">All contacts are already assigned to groups</p>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Footer (Fixed) -->
                <div class="bg-slate-800/50 px-6 sm:px-8 py-4 border-t border-slate-700/50 flex-shrink-0">
                    <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-700/30">
                        <span class="text-sm text-gray-400">
                            Selected: <span class="font-semibold text-blue-300">{{ count($selectedContacts) }}</span>
                        </span>
                        @if (count($selectedContacts) > 0)
                            <button type="button" wire:click="$set('selectedContacts', [])"
                                class="text-xs text-gray-500 hover:text-gray-300 transition-colors font-medium">Clear
                                All</button>
                        @endif
                    </div>
                    <div class="flex gap-3 justify-end flex-row-reverse">
                        <button wire:click="assignContacts" @disabled(empty($selectedContacts))
                            class="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/25 disabled:bg-slate-600 disabled:cursor-not-allowed disabled:shadow-none group">
                            <i class="bi bi-check-circle group-hover:scale-110 transition-transform"></i>
                            <span>Assign
                                {{ count($selectedContacts) > 0 ? '(' . count($selectedContacts) . ')' : '' }}</span>
                        </button>
                        <button type="button" wire:click="closeModal"
                            class="inline-flex items-center justify-center gap-2 bg-slate-700/50 hover:bg-slate-700 text-gray-300 hover:text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200">
                            <i class="bi bi-x-circle"></i>
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- ========================================== -->
    <!-- 4. VIEW ASSIGNED CONTACTS MODAL -->
    <!-- ========================================== -->
    @if ($showViewAssignedModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4">
            <!-- Backdrop -->
            <div wire:click="closeModal" class="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
                x-data x-transition.opacity></div>

            <!-- Panel -->
            <div x-data="{ show: @entangle('showViewAssignedModal') }" x-show="show" x-transition.scale.origin.center
                class="relative z-10 bg-slate-800 rounded-lg text-left overflow-hidden shadow-2xl w-full max-w-2xl border border-slate-700/50 flex flex-col max-h-[70vh]">

                <!-- Header (Fixed) -->
                <div
                    class="bg-gradient-to-r from-slate-800 to-slate-700/80 px-6 sm:px-8 py-6 border-b border-slate-700/50 flex-shrink-0">
                    <div class="flex justify-between items-start gap-4">
                        <div>
                            <h3 id="view-assigned-title" class="text-xl font-bold text-white flex items-center gap-2">
                                <i class="bi bi-people-fill text-green-400"></i>Assigned Contacts
                            </h3>
                            <p class="text-sm text-gray-400 mt-2">
                                <span
                                    class="inline-block px-2.5 py-1 bg-green-500/20 text-green-300 rounded text-xs font-semibold">
                                    Group: {{ $groupForViewing?->Name }}
                                </span>
                            </p>
                        </div>
                        <button type="button" wire:click="closeModal"
                            class="p-2 hover:bg-slate-700 text-gray-400 hover:text-white rounded-lg transition-all duration-200"
                            aria-label="Close">
                            <i class="bi bi-x-lg text-xl"></i>
                        </button>
                    </div>

                    <!-- Search Bar -->
                    <div class="mt-4 relative">
                        <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-500"></i>
                        <input type="text" wire:model.live.debounce.300ms="searchAssigned"
                            placeholder="Search by name or company..."
                            class="w-full bg-slate-700/50 border border-slate-600 text-white text-sm rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 py-2.5 px-3 pl-10 placeholder-gray-500">
                    </div>
                </div>

                <!-- Contact List (Scrollable) -->
                <div class="flex-1 overflow-y-auto">
                    <div class="px-6 sm:px-8 py-4">
                        @if ($this->assignedContacts->count() > 0)
                            <div class="space-y-2">
                                @foreach ($this->assignedContacts as $contact)
                                    <label wire:key="assigned-contact-{{ $contact->Admn_User_Mast_UIN }}"
                                        class="flex items-center gap-3 cursor-pointer p-3 rounded-lg bg-slate-700/20 hover:bg-slate-700/40 border border-transparent hover:border-green-500/30 transition-all duration-150 group">
                                        <input type="checkbox" wire:model.live="contactsToUnassign"
                                            value="{{ $contact->Admn_User_Mast_UIN }}"
                                            class="w-4 h-4 rounded border-gray-500 text-red-500 focus:ring-2 focus:ring-red-500 bg-slate-900 cursor-pointer flex-shrink-0">
                                        <div class="flex-1 min-w-0">
                                            <div class="flex items-center gap-2">
                                                <p
                                                    class="text-sm font-semibold text-gray-200 group-hover:text-green-300 transition-colors truncate">
                                                    {{ trim($contact->FaNm . ' ' . $contact->MiNm . ' ' . $contact->LaNm) }}
                                                </p>
                                                @if ($contact->Is_Vf == 100206)
                                                    <span class="h-2.5 w-2.5 bg-yellow-500 rounded-full flex-shrink-0"
                                                        title="Not Verified"></span>
                                                @endif
                                            </div>
                                            @if ($contact->Comp_Name)
                                                <p class="text-xs text-gray-500 truncate">
                                                    <i class="bi bi-briefcase"></i> {{ $contact->Comp_Name }}
                                                    @if ($contact->Comp_Dsig)
                                                        • {{ $contact->Comp_Dsig }}
                                                    @endif
                                                </p>
                                            @endif
                                        </div>
                                        <div class="flex-shrink-0 text-right">
                                            @if ($contact->phones->first())
                                                <p class="text-xs text-gray-500">
                                                    {{ $contact->phones->first()->Phon_Numb }}</p>
                                            @endif
                                            @if ($contact->emails->first())
                                                <p class="text-xs text-gray-600">
                                                    {{ $contact->emails->first()->Emai_Addr }}</p>
                                            @endif
                                        </div>
                                    </label>
                                @endforeach
                            </div>
                        @else
                            <!-- Empty State -->
                            <div class="text-center py-16">
                                <div class="flex justify-center mb-4">
                                    <div class="p-3 bg-slate-700/30 rounded-full">
                                        <i class="bi bi-inbox text-4xl text-gray-500"></i>
                                    </div>
                                </div>
                                <p wire:loading.remove class="text-base text-gray-400 font-medium">No assigned contacts
                                </p>
                                <p wire:loading
                                    class="text-base text-green-400 font-medium flex items-center justify-center gap-2">
                                    <i class="bi bi-arrow-repeat animate-spin"></i>
                                    Searching...
                                </p>
                                <p class="text-sm text-gray-500 mt-2">This group doesn't have any assigned contacts yet
                                </p>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Footer (Fixed) -->
                <div class="bg-slate-800/50 px-6 sm:px-8 py-4 border-t border-slate-700/50 flex-shrink-0">
                    <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-700/30">
                        <span class="text-sm text-gray-400">
                            Total: <span
                                class="font-semibold text-green-300">{{ $this->assignedContacts->count() }}</span>
                            @if (count($contactsToUnassign) > 0)
                                | Selected for removal: <span
                                    class="font-semibold text-red-300">{{ count($contactsToUnassign) }}</span>
                            @endif
                        </span>
                        @if (count($contactsToUnassign) > 0)
                            <button type="button" wire:click="$set('contactsToUnassign', [])"
                                class="text-xs text-gray-500 hover:text-gray-300 transition-colors font-medium">Clear</button>
                        @endif
                    </div>
                    <div class="flex gap-3 justify-end flex-row-reverse">
                        @if (count($contactsToUnassign) > 0)
                            <button wire:click="unassignContacts"
                                class="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-red-500/25 group">
                                <i class="bi bi-trash group-hover:scale-110 transition-transform"></i>
                                <span>Unassign
                                    {{ count($contactsToUnassign) > 0 ? '(' . count($contactsToUnassign) . ')' : '' }}</span>
                            </button>
                        @endif
                        <button type="button" wire:click="closeModal"
                            class="inline-flex items-center justify-center gap-2 bg-slate-700/50 hover:bg-slate-700 text-gray-300 hover:text-white font-semibold py-2.5 px-6 rounded-lg transition-all duration-200">
                            <i class="bi bi-x-circle"></i>
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
