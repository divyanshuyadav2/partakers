<div>
    <div class="max-w-4xl mx-auto py-10 sm:px-6 lg:px-8">

        {{-- Page Header --}}
        <div class="px-4 sm:px-0">
            <div class="flex items-center space-x-4">
                <a href="{{ route('contacts.index') }}" class="text-gray-200 hover:text-white">
                    <i class="bi bi-arrow-left text-xl"></i>
                </a>
                <div>
                    <h1 class="text-3xl font-bold text-white">Edit</h1>
                </div>
            </div>
        </div>


        {{-- The Form Wrapper --}}
        <form x-data="contactFormValidator()" x-init="init()"
            @validate-phone-length.window="validatePhoneLength($event.detail.fieldKey, $event.detail.value, $event.detail.index)"
            wire:submit="update" @submit="if(!validateForm()) { $event.preventDefault(); }"
            class="mt-8 grid grid-cols-1 gap-8">
            <!-- Personal Details Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-person-vcard mr-2"></i> Personal Details
                </h2>
                <div class="p-6 space-y-6">

                    {{-- AlpineJS Component for Image Cropping --}}
                    <div x-data="imageCropperComponent()" wire:key="alpine-image-cropper"
                        class="flex flex-col items-center space-y-4">

                        <!-- Hidden file input -->
                        <input type="file" class="hidden" x-ref="fileInput" @change="handleFileSelect"
                            accept="image/png, image/jpeg, image/gif">

                        {{-- Enhanced Profile Picture Display Area --}}
                        <div class="relative group w-36 h-36">
                            <div
                                class="w-36 h-36 rounded-full mx-auto bg-slate-800 border-2 border-dashed border-slate-600 flex items-center justify-center overflow-hidden">
                                @if ($Prfl_Pict)
                                    <img src="{{ $Prfl_Pict->temporaryUrl() }}" class="w-full h-full object-cover"
                                        alt="Profile Preview">
                                @elseif ($existing_avatar)
                                    <img src="{{ Storage::url($existing_avatar) }}" class="w-full h-full object-cover"
                                        alt="Current Profile Photo">
                                @else
                                    <div @click="$refs.fileInput.click()"
                                        class="cursor-pointer w-full h-full flex flex-col items-center justify-center text-center p-2">
                                        <i class="bi bi-camera-fill text-3xl text-slate-500"></i>
                                        <span class="text-xs text-slate-500 mt-1">Upload Photo</span>
                                    </div>
                                @endif
                            </div>

                            {{-- Hover Overlay with Change/Remove Actions --}}
                            <div
                                class="absolute inset-0 rounded-full bg-black/60 flex flex-col items-center justify-center space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                <button type="button" @click.prevent="$refs.fileInput.click()"
                                    class="flex items-center gap-2 text-sm font-semibold text-white hover:text-blue-300 transition-colors">
                                    <i class="bi bi-arrow-repeat"></i>
                                    <span>Change</span>
                                </button>
                                {{-- Clear button --}}
                                @if ($Prfl_Pict || $existing_avatar)
                                    <button type="button" wire:click="removeProfilePicture"
                                        class="flex items-center gap-2 px-3 py-1.5 rounded-md bg-red-500 text-white text-sm font-semibold 
                       hover:bg-red-600 transition-colors">
                                        <i class="bi bi-trash"></i>
                                        <span>Clear</span>
                                    </button>
                                @endif
                            </div>
                        </div>

                        <span class="text-gray-400 text-xs -mt-2 block">upload file type : jpg/png</span>
                        @error('Prfl_Pict')
                            <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                        @enderror

                        <!-- Cropper.js Modal -->
                        <div x-show="showCropper" x-transition
                            class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
                            style="display: none;">
                            <div @click.away="closeCropper()" class="bg-slate-800 rounded-md shadow-xl w-full max-w-lg">
                                <div class="p-6">
                                    <h3 class="text-lg font-medium text-white mb-4">Crop Your Image</h3>
                                    <div class="w-full h-80 bg-slate-900">
                                        <img x-ref="imageToCropEl" :src="imageToCrop"
                                            class="max-w-full max-h-full block">
                                    </div>
                                </div>
                                <div class="px-6 py-4 bg-slate-900/50 flex justify-end items-center gap-4 rounded-b-lg">
                                    <button type="button" @click="closeCropper()"
                                        class="text-sm font-semibold text-gray-200 hover:text-white transition-colors">Cancel</button>
                                    <button type="button" @click="cropImage()" class="figma-button-primary flex gap-2">
                                        <i class="bi bi-crop"></i> Apply
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        {{-- Prefix Field --}}
                        <div>
                            <label for="Prfx_UIN" class="text-sm font-medium text-gray-200">Prefix</label>
                            <select id="Prfx_UIN" wire:model.live="Prfx_UIN" class="form-select-figma mt-1">
                                <option value="">Select...</option>
                                @foreach ($allPrefixes as $prefix)
                                    <option value="{{ $prefix->Prfx_Name_UIN }}" title="{{ $prefix->Prfx_Name_Desp }}">
                                        {{ $prefix->Prfx_Name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('Prfx_UIN')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>



                        {{-- First Name Field --}}
                        <div>
                            <label for="FaNm" class="text-sm font-medium text-gray-200">
                                First Name <span class="text-red-400">*</span>
                            </label>
                            <input type="text" id="FaNm" wire:model.blur="FaNm" @blur="markTouched('FaNm')"
                                @input="filterInput($event, 'alpha'); validateField('FaNm', $event.target.value)"
                                class="form-input-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('FaNm') }">
                            <span x-show="hasError('FaNm')" x-text="getError('FaNm')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('FaNm')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Middle Name Field --}}
                        <div>
                            <label for="MiNm" class="text-sm font-medium text-gray-200">Middle Name</label>
                            <input type="text" id="MiNm" wire:model.blur="MiNm"
                                @blur="markTouched('MiNm'); validateField('MiNm', $event.target.value)"
                                @input="filterInput($event, 'alpha'); validateField('MiNm', $event.target.value)"
                                class="form-input-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('MiNm') }">
                            <span x-show="hasError('MiNm')" x-text="getError('MiNm')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('MiNm')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Last Name Field --}}
                        <div>
                            <label for="LaNm" class="text-sm font-medium text-gray-200">Last Name</label>
                            <input type="text" id="LaNm" wire:model.blur="LaNm"
                                @blur="markTouched('LaNm'); validateField('LaNm', $event.target.value)"
                                @input="filterInput($event, 'alpha'); validateField('LaNm', $event.target.value)"
                                class="form-input-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('LaNm') }">
                            <span x-show="hasError('LaNm')" x-text="getError('LaNm')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('LaNm')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Gender Field --}}
                        <div>
                            <label for="Gend" class="text-sm font-medium text-gray-200">
                                Gender <span class="text-red-400">*</span>
                            </label>
                            <select id="Gend" wire:model.blur="Gend"
                                @change="markTouched('Gend'); validateField('Gend', $event.target.value)"
                                class="form-select-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('Gend') }">
                                <option value="">Select...</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                            <span x-show="hasError('Gend')" x-text="getError('Gend')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('Gend')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Date of Birth, Anniversary, Death --}}
                        <div>
                            <label for="Brth_Dt" class="text-sm font-medium text-gray-200">Date of Birth</label>
                            <input type="date" id="Brth_Dt" wire:model.blur="Brth_Dt"
                                @change="markTouched('Brth_Dt'); validateField('Brth_Dt', $event.target.value)"
                                class="form-input-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('Brth_Dt') }">
                            <span x-show="hasError('Brth_Dt')" x-text="getError('Brth_Dt')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('Brth_Dt')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>
                        <div>
                            <label for="Anvy_Dt" class="text-sm font-medium text-gray-200">Anniversary Date</label>
                            <input type="date" id="Anvy_Dt" wire:model.blur="Anvy_Dt"
                                @change="markTouched('Anvy_Dt'); validateField('Anvy_Dt', $event.target.value)"
                                class="form-input-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('Anvy_Dt') }">
                            <span x-show="hasError('Anvy_Dt')" x-text="getError('Anvy_Dt')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('Anvy_Dt')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="Deth_Dt" class="text-sm font-medium text-gray-200">Date of Death</label>
                            <input type="date" id="Deth_Dt" wire:model.blur="Deth_Dt"
                                @change="markTouched('Deth_Dt'); validateField('Deth_Dt', $event.target.value)"
                                class="form-input-figma mt-1"
                                :class="{ 'border-red-500 ring-red-500': hasError('Deth_Dt') }">
                            <span x-show="hasError('Deth_Dt')" x-text="getError('Deth_Dt')"
                                class="text-red-400 text-xs mt-1"></span>
                            @error('Deth_Dt')
                                <span class="text-red-400 text-xs mt-1">{{ $message }}</span>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            <!-- Address Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-geo-alt-fill mr-2"></i>Address</h2>
                <div class="p-6 space-y-6">
                    @foreach ($addresses as $index => $address)
                        <div class="relative p-5 rounded-md bg-slate-700/30 border border-slate-600"
                            wire:key="address-{{ $index }}">

                            <!-- TOP ROW: Address Type (Left) + Actions (Right) -->
                            <div class="flex items-start justify-between gap-4 mb-4">
                                <!-- Address Type -->
                                <div class="flex-1">
                                    <label class="block text-sm mb-1 font-medium text-gray-100">Address Type</label>
                                    <select wire:model="addresses.{{ $index }}.Admn_Addr_Type_Mast_UIN"
                                        class="form-select-figma w-fit">
                                        <option value="">Select</option>
                                        @foreach ($addressTypes as $type)
                                            <option value="{{ $type->Admn_Addr_Type_Mast_UIN }}">
                                                {{ $type->Name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('addresses.' . $index . '.Admn_Addr_Type_Mast_UIN')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>

                                <!-- Primary & Remove Actions -->
                                <div class="flex items-center gap-4 pt-6">
                                    <label for="primary_address_{{ $index }}"
                                        class="flex items-center cursor-pointer gap-2 whitespace-nowrap">
                                        <span class="text-sm font-medium text-gray-200">Primary</span>
                                        <input type="radio" id="primary_address_{{ $index }}"
                                            name="primary_address"
                                            wire:click="setPrimaryAddress({{ $index }})"
                                            class="form-radio-figma" @if ($address['Is_Prmy'] ?? false) checked @endif>
                                    </label>
                                    @if (count($addresses) > 1)
                                        <button type="button" wire:click="removeAddress({{ $index }})"
                                            class="text-gray-200 hover:text-red-500 transition-colors"
                                            title="Remove Address">
                                            <i class="bi bi-trash-fill text-lg"></i>
                                        </button>
                                    @endif
                                </div>
                            </div>

                            <!-- Location & Address Fields Grid -->
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">

                                <!-- Country -->
                                <div>
                                    <label class="block text-sm mb-1 font-medium text-gray-200">Country</label>
                                    <select wire:model.live="addresses.{{ $index }}.Admn_Cutr_Mast_UIN"
                                        class="form-select-figma w-full">
                                        <option value="">Select Country...</option>
                                        @foreach ($allCountries as $country)
                                            <option value="{{ $country->Admn_Cutr_Mast_UIN }}">
                                                {{ $country->Name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- State -->
                                <div>
                                    <label class="block text-sm mb-1 font-medium text-gray-200">State</label>
                                    <select wire:model.live="addresses.{{ $index }}.Admn_Stat_Mast_UIN"
                                        class="form-select-figma w-full"
                                        @if (empty($address['statesForDropdown'] ?? [])) disabled @endif>
                                        <option value="">Select State...</option>
                                        @foreach ($address['statesForDropdown'] ?? [] as $state)
                                            <option value="{{ $state['Admn_Stat_Mast_UIN'] }}">
                                                {{ $state['Name'] }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- District -->
                                <div>
                                    <label class="block text-sm mb-1 font-medium text-gray-200">District</label>
                                    <select wire:model.live="addresses.{{ $index }}.Admn_Dist_Mast_UIN"
                                        class="form-select-figma w-full"
                                        @if (empty($address['districtsForDropdown'] ?? [])) disabled @endif>
                                        <option value="">Select District...</option>
                                        @foreach ($address['districtsForDropdown'] ?? [] as $district)
                                            <option value="{{ $district['Admn_Dist_Mast_UIN'] }}">
                                                {{ $district['Name'] }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- Pincode -->
                                <div>
                                    <label class="block text-sm mb-1 font-medium text-gray-200">Pincode</label>
                                    <select wire:model.live="addresses.{{ $index }}.Admn_PinCode_Mast_UIN"
                                        class="form-select-figma w-full"
                                        @if (empty($address['pincodesForDropdown'] ?? [])) disabled @endif>
                                        <option value="">Select Pincode...</option>
                                        @foreach ($address['pincodesForDropdown'] ?? [] as $pincode)
                                            <option value="{{ $pincode['Admn_PinCode_Mast_UIN'] }}">
                                                {{ $pincode['Code'] }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('addresses.' . $index . '.Admn_PinCode_Mast_UIN')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>

                                <!-- Location -->
                                <div>
                                    <label class="block text-sm mb-1 font-medium text-gray-200">Location</label>
                                    <input type="text" wire:model.blur="addresses.{{ $index }}.Lndm"
                                        class="form-input-figma w-full" placeholder="Town/City, Locality, Landmark">
                                </div>

                                <!-- Street -->
                                <div>
                                    <label class="block text-sm mb-1 font-medium text-gray-200">Street</label>
                                    <input type="text" wire:model.blur="addresses.{{ $index }}.Loca"
                                        class="form-input-figma w-full" placeholder="Area, Street, Sector, Village">
                                </div>

                                <!-- Address Line (Full Width) -->
                                <div class="sm:col-span-2">
                                    <label class="block text-sm mb-1 font-medium text-gray-200">Flat, House No,
                                        Building Name, Company</label>
                                    <textarea wire:model.blur="addresses.{{ $index }}.Addr" rows="2" class="form-input-figma w-full"
                                        placeholder="Flat, House No, Building, Company..."></textarea>
                                    @error('addresses.' . $index . '.Addr')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    @endforeach

                    <!-- Add Another -->
                    @if (count($addresses) < 5)
                        <button type="button" wire:click="addAddress"
                            class="text-sm font-semibold text-blue-500 hover:text-blue-300 transition-colors flex items-center gap-2">
                            <i class="bi bi-plus-circle"></i> Add Another Address
                        </button>
                    @endif
                </div>
            </div>
            <!-- Contact Information Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-person-lines-fill"></i> Contact
                    Information</h2>
                <div class="p-6 space-y-8">
                    <!-- Phone Numbers -->
                    <div>
                        <h3 class="font-medium text-slate-300 mb-4 flex items-center gap-2 text-sm tracking-wide">
                            <i class="bi bi-telephone-fill text-blue-400"></i> Phone Numbers
                        </h3>
                        <div class="space-y-4">
                            @forelse ($phones as $index => $phone)
                                <div class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600"
                                    wire:key="phone-{{ $index }}">
                                    <div class="absolute top-4 right-4 flex items-center gap-4">
                                        <label for="primary_phone_{{ $index }}"
                                            class="flex items-center cursor-pointer gap-2">
                                            <span class="text-sm font-medium text-gray-200">Preferable</span>
                                            <input type="radio" id="primary_phone_{{ $index }}"
                                                name="primary_phone" title="Set as preferable"
                                                wire:click="setPrimaryPhone({{ $index }})"
                                                @if ($phone['Is_Prmy'] ?? false) checked @endif
                                                class="form-radio-figma">
                                        </label>
                                        @if (count($phones) > 1)
                                            <button type="button" wire:click="removePhone({{ $index }})"
                                                title="Remove Phone"
                                                class="text-slate-500 hover:text-red-500 transition-colors">
                                                <i class="bi bi-trash-fill text-lg"></i>
                                            </button>
                                        @endif
                                    </div>

                                    <div class="flex-grow grid grid-cols-1 sm:grid-cols-5 gap-3 pt-8"
                                        @primary-country-changed.window="updateFromPrimary($event.detail)">
                                        <div class="sm:col-span-1">
                                            <div wire:ignore>
                                                <div x-data="countryPicker('{{ $phone['Cutr_Code'] ?? ($allCountries->first()->Phon_Code ?? '91') }}', {{ $index }})" x-init="init()"
                                                    class="relative">
                                                    <button type="button" @click="open = !open"
                                                        class="form-select-figma text-sm w-full h-10 flex items-center justify-between px-3">
                                                        <span class="flex items-center gap-2">
                                                            <span x-show="selectedCountry"
                                                                :class="`fi fi-${(selectedCountry?.Code || '').trim().toLowerCase()}`"></span>
                                                            <span x-show="selectedCountry"
                                                                x-text="selectedCountry?.Name + ' +' +(selectedCountry?.Phon_Code || '').trim()"></span>
                                                        </span>
                                                        <i class="bi bi-chevron-down text-gray-400"></i>
                                                    </button>
                                                    <div x-show="open" @click.outside="open = false" x-transition
                                                        class="absolute z-20 mt-1 w-72 max-h-60 overflow-y-auto rounded-md bg-white shadow-lg border border-slate-200">
                                                        <div
                                                            class="p-2 sticky top-0 bg-white border-b border-slate-200">
                                                            <input type="text" x-model="search"
                                                                placeholder="Search country..."
                                                                class="w-full rounded-md border-gray-300 text-sm px-2 py-1">
                                                        </div>
                                                        <ul class="py-1">
                                                            <template x-for="country in filteredCountries"
                                                                :key="country.Admn_Cutr_Mast_UIN">
                                                                <li @click="choose(country)"
                                                                    class="flex items-center gap-x-3 px-3 py-2 text-sm hover:bg-slate-100 cursor-pointer">
                                                                    <span
                                                                        :class="`fi fi-${(country?.Code || '').trim().toLowerCase()}`"></span>
                                                                    <span class="font-medium flex-1 truncate"
                                                                        x-text="country.Name"></span>
                                                                    <span class="text-gray-500"
                                                                        x-text="'+' + country.Phon_Code"></span>
                                                                </li>
                                                            </template>
                                                            <li x-show="filteredCountries.length === 0"
                                                                class="px-4 py-2 text-sm text-gray-500">No country
                                                                found.</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="sm:col-span-2">
                                            <input type="tel"
                                                wire:model.blur="phones.{{ $index }}.Phon_Numb"
                                                @blur="markTouched('phones.{{ $index }}.Phon_Numb')"
                                                @input="filterInput($event, 'numeric'); validatePhoneLength('phones.{{ $index }}.Phon_Numb', $event.target.value, {{ $index }})"
                                                placeholder="Phone Number" class="form-input-figma text-sm w-full"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'phones.{{ $index }}.Phon_Numb')
                                                }"
                                                maxlength="15">
                                            <span x-show="hasError('phones.{{ $index }}.Phon_Numb')"
                                                x-text="getError('phones.{{ $index }}.Phon_Numb')"
                                                class="text-red-400 text-xs mt-1"></span>
                                        </div>
                                        <div class="sm:col-span-1">
                                            <select wire:model.blur="phones.{{ $index }}.Phon_Type"
                                                class="form-select-figma text-sm w-full">
                                                <option value="self">Self</option>
                                                <option value="office">Office</option>
                                                <option value="home">Home</option>
                                            </select>
                                        </div>
                                        <div class="flex flex-col gap-2">
                                            <label class="flex items-center gap-2 text-sm text-gray-200">
                                                <input type="checkbox"
                                                    wire:model.blur="phones.{{ $index }}.Has_WtAp"
                                                    class="form-checkbox-figma"> <i
                                                    class="bi bi-whatsapp text-green-400 text-xs"
                                                    title="WhatsApp"></i>
                                            </label>
                                            <label class="flex items-center gap-2 text-sm text-gray-200">
                                                <input type="checkbox"
                                                    wire:model.blur="phones.{{ $index }}.Has_Telg"
                                                    class="form-checkbox-figma"> <i
                                                    class="bi bi-telegram text-sky-400 text-xs" title="Telegram"></i>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                @error('phones.' . $index . '.Phon_Numb')
                                    <span class="text-red-400 text-xs ml-1">{{ $message }}</span>
                                @enderror
                            @empty
                                <p class="text-slate-500 text-sm pl-1">No phone numbers added.</p>
                            @endforelse
                        </div>
                        <button type="button" wire:click="addPhone"
                            class="mt-4 text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-2">
                            <i class="bi bi-plus-circle"></i> Add Phone Number
                        </button>
                    </div>

                    <!-- Emails -->
                    <div>
                        <h3 class="font-medium text-slate-300 mb-4 flex items-center gap-2 text-sm tracking-wide">
                            <i class="bi bi-envelope-fill text-green-400"></i> Email Addresses
                        </h3>
                        <div class="space-y-4">
                            @forelse ($emails as $index => $email)
                                <div class="relative p-4 rounded-md bg-slate-700/30 border border-slate-600"
                                    wire:key="email-{{ $index }}">
                                    <div class="absolute top-4 right-4 flex items-center gap-4">
                                        <label for="primary_email_{{ $index }}"
                                            class="flex items-center cursor-pointer gap-2">
                                            <span class="text-sm font-medium text-gray-200">Preferable</span>
                                            <input type="radio" id="primary_email_{{ $index }}"
                                                name="primary_email" title="Set as preferable"
                                                wire:click="setPrimaryEmail({{ $index }})"
                                                @if ($email['Is_Prmy'] ?? false) checked @endif
                                                class="form-radio-figma">
                                        </label>
                                        @if (count($emails) > 1)
                                            <button type="button" wire:click="removeEmail({{ $index }})"
                                                title="Remove Email"
                                                class="text-slate-500 hover:text-red-500 transition-colors">
                                                <i class="bi bi-trash-fill text-lg"></i>
                                            </button>
                                        @endif
                                    </div>
                                    <div class="flex-grow grid grid-cols-1 sm:grid-cols-3 gap-3 pt-8">
                                        <div class="sm:col-span-2">
                                            <input type="email"
                                                wire:model.blur="emails.{{ $index }}.Emai_Addr"
                                                @blur="markTouched('emails.{{ $index }}.Emai_Addr'); validateField('emails', $event.target.value, {{ $index }})"
                                                @input="validateField('emails', $event.target.value, {{ $index }})"
                                                placeholder="example@domain.com"
                                                class="form-input-figma text-sm w-full"
                                                :class="{
                                                    'border-red-500 ring-red-500': hasError(
                                                        'emails.{{ $index }}.Emai_Addr')
                                                }">
                                            <span x-show="hasError('emails.{{ $index }}.Emai_Addr')"
                                                x-text="getError('emails.{{ $index }}.Emai_Addr')"
                                                class="text-red-400 text-xs mt-1"></span>
                                        </div>
                                        <select wire:model.blur="emails.{{ $index }}.Emai_Type"
                                            class="form-select-figma text-sm w-full">
                                            <option value="Self Generated">Self Generated</option>
                                            <option value="Office">Office</option>
                                            <option value="Business">Business</option>
                                        </select>
                                    </div>
                                </div>
                                @error('emails.' . $index . '.Emai_Addr')
                                    <span class="text-red-400 text-xs ml-1">{{ $message }}</span>
                                @enderror
                            @empty
                                <p class="text-slate-500 text-sm pl-1">No email addresses added.</p>
                            @endforelse
                        </div>
                        <button type="button" wire:click="addEmail"
                            class="mt-4 text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-2">
                            <i class="bi bi-plus-circle"></i> Add Email
                        </button>
                    </div>
                </div>
            </div>


            <!-- Web Presence Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-globe2 mr-2"></i>Web Presence</h2>
                <div class="p-6 grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div class="relative">
                        <i
                            class="bi bi-globe text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        <input type="url" wire:model.blur="Web" placeholder="Website"
                            @blur="markTouched('Web'); validateField('Web', $event.target.value)"
                            @input="validateField('Web', $event.target.value)" class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('Web') }" />
                        @error('Web')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="relative">
                        <i
                            class="bi bi-linkedin text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        <input type="url" wire:model.blur="LnDn" placeholder="LinkedIn"
                            class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('LnDn') }" />
                        @error('LnDn')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="relative">
                        <i
                            class="bi bi-twitter-x text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        <input type="url" wire:model.blur="Twtr" placeholder="Twitter / X"
                            class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('Twtr') }" />
                        @error('Twtr')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="relative">
                        <i
                            class="bi bi-facebook text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        <input type="url" wire:model.blur="FcBk" placeholder="Facebook"
                            class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('FcBk') }" />
                        @error('FcBk')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="relative">
                        <i
                            class="bi bi-instagram text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        <input type="url" wire:model.blur="Intg" placeholder="Instagram"
                            class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('Intg') }" />
                        @error('Intg')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="relative">
                        <i
                            class="bi bi-reddit text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        <input type="url" wire:model.blur="Redt" placeholder="Reddit"
                            class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('Redt') }" />
                        @error('Redt')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="relative sm:col-span-2">
                        <i class="text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">Y!</i>
                        <input type="url" wire:model.blur="Yaho" placeholder="Yahoo"
                            class="form-input-figma w-full pl-10"
                            :class="{ 'border-red-500 ring-red-500': hasError('Yaho') }" />
                        @error('Yaho')
                            <span class="text-red-400 text-xs mt-1 ml-10">{{ $message }}</span>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Employment Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-briefcase-fill mr-2"></i>Employment</h2>
                <div class="p-6 space-y-6">
                    <div class="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-xl">
                        <button type="button" wire:click="$set('Empl_Type', 'job')"
                            class="px-2 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200"
                            :class="{ 'bg-blue-600 text-white shadow-md': @js($Empl_Type) === 'job', 'text-gray-200 hover:bg-slate-700': @js($Empl_Type) !== 'job' }">
                            Job
                        </button>
                        <button type="button" wire:click="$set('Empl_Type', 'self-employed')"
                            class="px-2 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200"
                            :class="{ 'bg-blue-600 text-white shadow-md': @js($Empl_Type) === 'self-employed', 'text-gray-200 hover:bg-slate-700': @js($Empl_Type) !== 'self-employed' }">
                            Self Employed
                        </button>
                    </div>

                    @if ($Empl_Type === 'job')
                        <div class="space-y-5">
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                <div>
                                    <label for="Comp_Name" class="text-sm font-medium text-gray-200">Company
                                        Name</label>
                                    <input type="text" id="Comp_Name" wire:model.live="Comp_Name"
                                        placeholder="e.g., ABC Corporation"
                                        @blur="markTouched('Comp_Name'); validateField('Comp_Name', $event.target.value)"
                                        @input="validateField('Comp_Name', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Comp_Name') }">
                                    @error('Comp_Name')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label for="Comp_Dsig"
                                        class="text-sm font-medium text-gray-200">Designation</label>
                                    <input type="text" id="Comp_Dsig" wire:model.live="Comp_Dsig"
                                        placeholder="e.g., Senior Manager, Software Engineer"
                                        class="form-input-figma mt-1">
                                    @error('Comp_Dsig')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label for="Comp_LdLi" class="text-sm font-medium text-gray-200">Company
                                        Landline</label>
                                    <input type="tel" id="Comp_LdLi" wire:model.live="Comp_LdLi"
                                        placeholder="e.g., 02012345678" @blur="markTouched('Comp_LdLi')"
                                        @input="filterInput($event, 'numeric'); validateField('Comp_LdLi', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Comp_LdLi') }">
                                    @error('Comp_LdLi')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label for="Comp_Desp" class="text-sm font-medium text-gray-200">Company Business
                                        Description</label>
                                    <input type="text" id="Comp_Desp" wire:model.live="Comp_Desp"
                                        placeholder="e.g., Software Development, Manufacturing"
                                        @input="filterInput($event, 'string')" class="form-input-figma mt-1">
                                    @error('Comp_Desp')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label for="Comp_Emai" class="text-sm font-medium text-gray-200">Company
                                        Email</label>
                                    <input type="email" id="Comp_Emai" wire:model.live="Comp_Emai"
                                        placeholder="e.g., info@company.com" @blur="markTouched('Comp_Emai')"
                                        @input="validateField('Comp_Emai', $event.target.value)"
                                        class="form-input-figma mt-1"
                                        :class="{ 'border-red-500 ring-red-500': hasError('Comp_Emai') }">
                                    @error('Comp_Emai')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label for="Comp_Web" class="text-sm font-medium text-gray-200">Company
                                        Website</label>
                                    <input type="url" id="Comp_Web" placeholder="https://www.company.com"
                                        wire:model.live="Comp_Web"
                                        @input="validateField('Comp_Web', $event.target.value)"
                                        class="form-input-figma mt-1">
                                    @error('Comp_Web')
                                        <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>

                            <div>
                                <label for="Comp_Addr" class="text-sm font-medium text-gray-200">Company
                                    Address</label>
                                <textarea id="Comp_Addr" wire:model.blur="Comp_Addr" @input="validateField('Comp_Addr', $event.target.value)"
                                    rows="3" placeholder="Enter complete company address including street, city, state, and postal code"
                                    class="form-input-figma mt-1"></textarea>
                                @error('Comp_Addr')
                                    <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                    @endif

                    @if ($Empl_Type === 'self-employed')
                        <div class="space-y-5">
                            <div>
                                <label for="Prfl_Name" class="text-sm font-medium text-gray-200">Profession /
                                    Service</label>
                                <input type="text" id="Prfl_Name" wire:model.blur="Prfl_Name"
                                    placeholder="e.g., Graphic Designer, Consultant, Freelance Developer"
                                    class="form-input-figma mt-1">
                                @error('Prfl_Name')
                                    <span class="text-red-400 text-xs">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label for="Prfl_Addr" class="text-sm font-medium text-gray-200">Business
                                    Address</label>
                                <textarea id="Prfl_Addr" wire:model.blur="Prfl_Addr" rows="3"
                                    placeholder="Enter your business address or work location" class="form-input-figma mt-1"></textarea>
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Tags Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-tags-fill mr-2"></i>Contact Tag</h2>
                <div class="p-6">
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                        @forelse($allTags as $tag)
                            <label for="tag-{{ $tag->Admn_Tag_Mast_UIN }}"
                                class="flex items-center space-x-3 bg-slate-900/50 p-3 rounded-md hover:bg-slate-800 cursor-pointer transition-colors">
                                <input type="checkbox" id="tag-{{ $tag->Admn_Tag_Mast_UIN }}"
                                    value="{{ $tag->Admn_Tag_Mast_UIN }}" wire:model.live="selectedTags"
                                    class="form-checkbox-figma">
                                <span class="text-sm font-medium text-slate-300">{{ $tag->Name }}</span>
                            </label>
                        @empty
                            <p class="text-slate-500 text-sm sm:col-span-4">No tags available to select.</p>
                        @endforelse
                    </div>
                </div>
            </div>

            <!-- References Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-people-fill mr-2"></i>Reference Persons
                </h2>
                <div class="p-6 space-y-6">
                    @forelse ($references as $index => $reference)
                        <div class="relative p-5 border border-white/[.10] rounded-md"
                            wire:key="reference-{{ $index }}">
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                <div>
                                    <label class="block text-sm font-medium text-gray-200">Reference Person
                                        Name</label>
                                    <input type="text" wire:model.blur="references.{{ $index }}.Refa_Name"
                                        class="form-input-figma mt-1" placeholder="John Doe">
                                    @error('references.' . $index . '.Refa_Name')
                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-200">Relationship</label>
                                    <input type="text" wire:model.blur="references.{{ $index }}.Refa_Rsip"
                                        class="form-input-figma mt-1" placeholder="Former Colleague">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-200">Email Address</label>
                                    <input type="email" wire:model.blur="references.{{ $index }}.Refa_Emai"
                                        class="form-input-figma mt-1" placeholder="john.doe@example.com">
                                    @error('references.' . $index . '.Refa_Emai')
                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-200">Phone Number</label>
                                    <input type="tel" wire:model.blur="references.{{ $index }}.Refa_Phon"
                                        @input="filterInput($event, 'numeric')" class="form-input-figma mt-1"
                                        placeholder="9876543210">
                                    @error('references.' . $index . '.Refa_Phon')
                                        <span class="text-red-400 text-xs">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="absolute top-4 right-4">
                                <button type="button" wire:click="removeReference({{ $index }})"
                                    class="text-slate-500 hover:text-red-500 transition-colors">
                                    <i class="bi bi-trash-fill"></i>
                                </button>
                            </div>
                        </div>
                    @empty
                        <p class="text-slate-500 text-sm">No references added.</p>
                    @endforelse
                    @if (count($references) < 5)
                        <button type="button" wire:click="addReference"
                            class="text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-2">
                            <i class="bi bi-plus-circle"></i> Add Reference
                        </button>
                    @endif
                </div>
            </div>

            <!-- Notes Card -->
            <div class="figma-card">
                <h2 class="figma-card-header text-green-200"><i class="bi bi-journal-text mr-2"></i>Notes for Contact
                    Person</h2>
                <div class="p-6">
                    <label for="Note" class="sr-only">Notes for Contact Person</label>
                    <textarea id="Note" wire:model.blur="Note" rows="5" class="form-input-figma"
                        placeholder="Add any additional notes about this contact..."></textarea>
                </div>
            </div>


            {{-- Error Display Section - Place this after Notes Card --}}
            @if ($errors->any())
                <div x-data="{ show: true }" x-show="show" x-transition
                    class="bg-red-900/50 border border-red-500/50 rounded-md p-4">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="bi bi-exclamation-triangle-fill text-red-400 text-lg"></i>
                        </div>
                        <div class="ml-3 flex-1">
                            <h3 class="text-sm font-medium text-red-400">
                                There {{ $errors->count() > 1 ? 'were' : 'was' }} {{ $errors->count() }}
                                error{{ $errors->count() > 1 ? 's' : '' }} with your submission:
                            </h3>
                            <div class="mt-2 text-sm text-red-300">
                                <ul class="list-disc list-inside space-y-1">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        <div class="ml-auto pl-3">
                            <button type="button" @click="show = false"
                                class="inline-flex text-red-400 hover:text-red-300">
                                <span class="sr-only">Dismiss</span>
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Form Actions -->
            <div class="flex justify-end items-center gap-4 mt-6">
                <a href="{{ route('contacts.index') }}"
                    class="text-sm font-semibold text-gray-200 hover:text-white transition-colors">
                    Cancel
                </a>
                <button type="submit" class="figma-button-primary">
                    <div wire:loading.remove wire:target="update">
                        <i class="bi bi-person-fill-check"></i>
                        <span>Update</span>
                    </div>
                    <div wire:loading wire:target="update">
                        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor"
                                stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                            </path>
                        </svg>
                        <span>Updating...</span>
                    </div>
                </button>
            </div>
        </form>
        @if ($MoOn)
            <div class="flex justify-end mt-4">
                <div
                    class="inline-flex items-center gap-2 px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-md text-sm">
                    <i class="bi bi-clock-history text-slate-400"></i>
                    <span class="text-slate-400">Last updated:</span>
                    <span class="font-medium text-slate-300">
                        {{ \Carbon\Carbon::parse($MoOn)->timezone('Asia/Kolkata')->format('d M Y, h:i A') }}
                    </span>
                    <span class="text-xs text-slate-500">IST</span>
                </div>
            </div>
        @endif
    </div>

    @push('scripts')
        {{-- Cropper.js library --}}
        <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css">

        {{-- AlpineJS Components (Cropper & Country Picker) --}}
        <script>
            function imageCropperComponent() {
                return {
                    showCropper: false,
                    imageToCrop: null,
                    cropper: null,
                    handleFileSelect(event) {
                        const file = event.target.files[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            this.imageToCrop = e.target.result;
                            this.showCropper = true;
                            this.$nextTick(() => this.initCropper());
                        };
                        reader.readAsDataURL(file);
                    },
                    initCropper() {
                        if (this.cropper) this.cropper.destroy();
                        this.cropper = new Cropper(this.$refs.imageToCropEl, {
                            aspectRatio: 1,
                            viewMode: 1
                        });
                    },
                    cropImage() {
                        let canvas = this.cropper.getCroppedCanvas({
                            width: 512,
                            height: 512
                        });
                        canvas.toBlob((blob) => {
                            const file = new File([blob], 'cropped-avatar.png', {
                                type: blob.type
                            });
                            this.$wire.upload('Prfl_Pict', file, () => this.closeCropper());
                        });
                    },
                    closeCropper() {
                        this.showCropper = false;
                        if (this.cropper) {
                            this.cropper.destroy();
                            this.cropper = null;
                        }
                        this.$refs.fileInput.value = "";
                    }
                }
            }

            const allCountries = @json($allCountries->toArray());

            function countryPicker(initialCode, livewireIndex) {
                return {
                    open: false,
                    search: '',
                    selectedCountry: null,

                    // NEW: Helper function to find the associated phone input
                    getPhoneInput() {
                        // This robustly finds the input field associated with this specific country picker instance
                        return this.$el.closest('.grid').querySelector(
                            `input[wire\\:model\\.blur="phones.${livewireIndex}.Phon_Numb"]`);
                    },

                    // NEW: Helper function to update the maxlength
                    updateMaxLength(country) {
                        const phoneInput = this.getPhoneInput();
                        if (phoneInput && country) {
                            phoneInput.maxLength = country.MoNo_Digt || 10;
                        }
                    },

                    init() {
                        // MODIFIED: Find the country and set the initial maxlength
                        this.selectedCountry = allCountries.find(c => c.Phon_Code == initialCode) || allCountries.find(c => c
                            .Phon_Code == '91') || allCountries[0];
                        if (this.selectedCountry) {
                            this.$wire.set(`phones.${livewireIndex}.Cutr_Code`, this.selectedCountry.Phon_Code);
                            this.$nextTick(() => this.updateMaxLength(this.selectedCountry));
                        }
                    },
                    get filteredCountries() {
                        if (!this.search) return allCountries;
                        const q = this.search.toLowerCase();
                        return allCountries.filter(c =>
                            c.Name.toLowerCase().includes(q) ||
                            c.Phon_Code.includes(this.search) ||
                            c.Code.toLowerCase().includes(q)
                        );
                    },
                    choose(country) {
                        // MODIFIED: Update maxlength when a new country is chosen
                        this.selectedCountry = country;
                        this.open = false;
                        this.search = '';
                        this.$wire.set(`phones.${livewireIndex}.Cutr_Code`, country.Phon_Code);
                        this.updateMaxLength(country); // NEW
                    },
                    updateFromPrimary(detail) {
                        // MODIFIED: Update maxlength when the primary address changes the country
                        const newCode = detail.newPhoneCode;
                        const newCountry = allCountries.find(c => c.Phon_Code == newCode);
                        if (newCountry) {
                            this.selectedCountry = newCountry;
                            this.$wire.set(`phones.${livewireIndex}.Cutr_Code`, newCountry.Phon_Code);
                            this.updateMaxLength(newCountry); // NEW
                        }
                    }
                }
            }
        </script>
        {{-- Livewire event listeners --}}
        <script>
            document.addEventListener('livewire:init', () => {
                Livewire.on('scroll-to-errors', () => {
                    const errorSection = document.getElementById('error-section') || document.querySelector(
                        '.bg-red-900\\/50');
                    if (errorSection) {
                        errorSection.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                        errorSection.classList.add('animate-pulse');
                        setTimeout(() => errorSection.classList.remove('animate-pulse'), 2000);
                    }
                });
            });
        </script>
    @endpush
</div>
