<div>
    <div class="max-w-4xl mx-auto py-6 sm:px-4">

        {{-- Header --}}
        <div class="flex items-center justify-between mb-4">
            <div class="flex space-x-3">
                <a href="{{ route('contacts.index') }}" class="text-green-200 hover:text-white">
                    <i class="bi bi-arrow-left text-lg"></i>
                </a>
                <div>
                    <div class="flex flex-col">
                        <h1 class="text-2xl font-semibold text-white">
                            {{ collect([$prefixName, $contact->FaNm, $contact->MiNm, $contact->LaNm])->filter()->implode(' ') }}
                        </h1>
                        <!-- Tags -->
                        @if ($contact->tags->isNotEmpty())

                            <div class="flex flex-wrap gap-2 mt-">
                                @foreach ($contact->tags as $tag)
                                    <span
                                        class="bg-blue-600/20 text-blue-300 px-2 py-1 rounded-full text-xs">{{ $tag->Name }}</span>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <div class="space-y-4">

            <!-- Personal & Contact Info -->
            <div class="figma-card p-4">
                <div class="flex items-center space-x-6">
                    <!-- Profile Pic -->
                    @if ($contact->avatar_url)
                        <img src="{{ $contact->avatar_url }}" class="w-20 h-20 rounded-full border border-slate-600">
                    @else
                        <div class="w-20 h-20 rounded-full border border-slate-600 flex items-center justify-center"
                            style="background-color: {{ $contact->avatar_color }}">
                            <span class="text-white text-lg font-bold">{{ $contact->initials }}</span>
                        </div>
                    @endif

                    <!-- Quick fields -->
                    <div class="flex flex-row text-sm gap-x-6 gap-y-1">

                        @if ($contact->Gend)
                            <p><span class="text-green-200">Gender:</span> <span
                                    class="text-white">{{ ucfirst($contact->Gend) ?? '-' }}</span></p>
                        @endif



                        @if ($contact->Brth_Dt)
                            <p><span class="text-green-200">DOB:</span> <span class="text-white">
                                    {{ $this->formatDate($contact->Brth_Dt) }}
                                </span></p>
                        @endif
                        @if ($contact->Anvy_Dt)
                            <p><span class="text-green-200">Anniversary:</span> <span class="text-white">
                                    {{ $this->formatDate($contact->Anvy_Dt) }}
                                </span></p>
                        @endif

                        @if ($contact->Deth_Dt)
                            <p><span class="text-green-200">Date of Death:</span> <span class="text-white">
                                    {{ $this->formatDate($contact->Deth_Dt) }}
                                </span></p>
                        @endif
                    </div>
                </div>
            </div>
            <!-- Socials -->
            @if ($this->hasSocialLinks())
                <div class="figma-card p-3">
                    <h2 class="text-xs font-semibold text-slate-300 mb-2 uppercase flex items-center gap-1">
                        <i class="bi bi-share-fill text-pink-400"></i> Social Links
                    </h2>
                    <div class="flex flex-wrap gap-4 text-sm">
                        @php
                            $socialIcons = [
                                'website' => 'bi-globe',
                                'linkedin' => 'bi-linkedin',
                                'twitter' => 'bi-twitter-x',
                                'facebook' => 'bi-facebook',
                                'instagram' => 'bi-instagram',
                                'reddit' => 'bi-reddit',
                                'yahoo' => 'bi-yahoo',
                            ];
                        @endphp
                        <style>
                            .social-link-hover:hover {
                                opacity: 0.8;
                                transition: opacity 0.2s ease-in-out;
                            }
                        </style>

                        @if (!empty($this->getSocialLinks()))
                            <div class="flex  flex-wrap items-center gap-x-4 gap-y-2">
                                @foreach ($this->getSocialLinks() as $platform => $url)
                                    <a href="{{ $url }}" target="_blank" rel="noopener noreferrer"
                                        class="bg-green-100 px-2 rounded-md social-link-hover flex items-center gap-1"
                                        style="color: {{ $socialHexColors[$platform] ?? '#2563EB' }};">

                                        <i class="{{ $socialIcons[$platform] ?? 'bi-link' }}"></i>
                                        <span class="font-medium">{{ ucfirst($platform) }}</span>
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
            @endif
            <!-- Phones + Emails side by side -->
            @if ($contact->phones->isNotEmpty() || $contact->emails->isNotEmpty())
                <div class="figma-card p-4 grid grid-cols-1 md:grid-cols-2 gap-4">

                    @if ($contact->phones->isNotEmpty())
                        <div>
                            <h3 class="text-xs font-semibold text-slate-300 mb-2 uppercase flex items-center gap-1">
                                <i class="bi bi-telephone-fill text-blue-400"></i> Phones
                            </h3>
                            <ul class="space-y-1 text-sm">
                                @foreach ($this->getEnhancedPhones() as $phone)
                                    <li class="text-white flex items-center justify-self-auto gap-1">
                                        <div class="flex items-center gap-1">
                                            @if ($phone->Is_Prmy)
                                                <span
                                                    style="width: 0.5rem; height: 0.5rem; border-radius: 9999px; background-color: #60a5fa;"
                                                    title="Primary"></span>
                                            @endif
                                            <span
                                                class="text-green-200 capitalize">{{ $phone->Phon_Type }}:</span>+{{ $phone->Cutr_Code }}
                                            {{ $phone->Phon_Numb }}

                                        </div>
                                        <div class="flex items-center gap-1">

                                            @if ($phone->Has_WtAp)
                                                <i class="bi bi-whatsapp text-green-400 text-xs" title="WhatsApp"></i>
                                            @endif
                                            @if ($phone->Has_Telg)
                                                <i class="bi bi-telegram text-sky-400 text-xs" title="Telegram"></i>
                                            @endif

                                        </div>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    @if ($contact->emails->isNotEmpty())
                        <div>
                            <h3 class="text-xs font-semibold text-slate-300 mb-2 uppercase flex items-center gap-1">
                                <i class="bi bi-envelope-fill text-green-400"></i> Emails
                            </h3>
                            <ul class="space-y-1 text-sm">
                                @foreach ($contact->emails as $email)
                                    <li class="flex justify-self-auto gap-1 items-center text-white">
                                        @if ($email->Is_Prmy)
                                            <span
                                                style="width: 0.5rem; height: 0.5rem; border-radius: 9999px; background-color: #60a5fa;"
                                                title="Primary"></span>
                                        @endif <span class="break-all"><span
                                                class="text-green-200 capitalize">{{ $email->Emai_Type }}:</span>
                                            {{ $email->Emai_Addr }} </span>

                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                </div>
            @endif

            <!-- Addresses -->
            @if ($this->getEnhancedAddresses()->isNotEmpty())
                <div class="figma-card p-4">
                    <h2 class="text-xs font-semibold text-slate-300 mb-3 uppercase flex items-center gap-1">
                        <i class="bi bi-geo-alt-fill text-purple-400"></i> Addresses
                    </h2>
                    <div class="space-y-3">
                        @foreach ($this->getEnhancedAddresses() as $address)
                            <div class="text-sm border-l-2 border-slate-600 pl-3">
                                <div class="flex items-center justify-self-auto gap-1">
                                    <span
                                        class="text-blue-300 font-medium">{{ $address->type_name ?? 'Address' }}</span>
                                    @if ($address->Is_Prmy)
                                        <span
                                            style="width: 0.5rem; height: 0.5rem; border-radius: 9999px; background-color: #60a5fa;"
                                            title="Primary"></span>
                                    @endif
                                </div>
                                <address class="text-white not-italic mt-1">
                                    {{-- Line 1: Street, Locality, Landmark --}}
                                    {{ collect([$address->Addr, $address->Loca, $address->Lndm])->filter()->implode(', ') }}

                                    {{-- Line 2: District, State, Pincode (only add a line break if this line has content) --}}
                                    @if ($address->district_name || $address->state_name || $address->pincode)
                                        <br>
                                        {{ collect([$address->district_name, $address->state_name])->filter()->implode(', ') }}
                                        @if ($address->pincode)
                                            - {{ $address->pincode }}
                                        @endif
                                    @endif

                                    {{-- Line 3: Country --}}
                                    @if ($address->country_name)
                                        <br>
                                        {{ $address->country_name }}
                                    @endif
                                </address>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif

            <!-- Employment & Profession -->
            @php
                // Check for the presence of each group of details to conditionally show the divider.
                $hasEmploymentDetails =
                    $contact->Comp_Name ||
                    $contact->Comp_Dsig ||
                    $contact->Comp_LdLi ||
                    $contact->Comp_Desp ||
                    $contact->Comp_Emai ||
                    $contact->Comp_Web ||
                    $contact->Comp_Addr;
                $hasProfessionDetails = $contact->Prfl_Name || $contact->Prfl_Addr;
            @endphp

        @if ($hasEmploymentDetails || $hasProfessionDetails)
    <div class="figma-card p-4">
        <h2 class="text-xs font-semibold text-slate-300 mb-4 uppercase flex items-center gap-2">
            <i class="bi bi-briefcase-fill text-orange-400"></i> Employment / Profession
        </h2>

        <!-- == Employment Details == -->
        @if ($hasEmploymentDetails)
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-sm">
                <!-- LEFT COLUMN -->
                <div class="space-y-3">
                    @if ($contact->Comp_Name)
                        <p><span class="text-green-200 font-medium">Company Name:</span>
                            <span class="text-white">{{ $contact->Comp_Name }}</span>
                        </p>
                    @endif

                    @if ($contact->Comp_Dsig)
                        <p><span class="text-green-200 font-medium">Designation:</span>
                            <span class="text-white">{{ $contact->Comp_Dsig }}</span>
                        </p>
                    @endif

                    @if ($contact->Comp_Addr)
                        <p><span class="text-green-200 font-medium">Address:</span>
                            <span class="text-white">{{ $contact->Comp_Addr }}</span>
                        </p>
                    @endif

                    @if ($contact->Comp_Desp)
                        <p><span class="text-green-200 font-medium">Company Business Description:</span>
                            <span class="text-white">{{ $contact->Comp_Desp }}</span>
                        </p>
                    @endif
                </div>

                <!-- RIGHT COLUMN -->
                <div class="space-y-3">
                    @if ($contact->Comp_Web)
                        <p><span class="text-green-200 font-medium">Website:</span>
                            <a href="{{ $contact->Comp_Web }}" target="_blank"
                                class="text-blue-400 hover:text-blue-300 break-all">{{ $contact->Comp_Web }}</a>
                        </p>
                    @endif

                    @if ($contact->Comp_Emai)
                        <p><span class="text-green-200 font-medium">Email:</span>
                            <span class="text-white break-all">{{ $contact->Comp_Emai }}</span>
                        </p>
                    @endif

                    @if ($contact->Comp_LdLi)
                        <p><span class="text-green-200 font-medium">Landline:</span>
                            <span class="text-white">{{ $contact->Comp_LdLi }}</span>
                        </p>
                    @endif
                </div>
            </div>
        @endif

        <!-- == Divider == -->
        @if ($hasEmploymentDetails && $hasProfessionDetails)
            <hr class="border-slate-700 my-4">
        @endif

        <!-- == Profession Details == -->
        @if ($hasProfessionDetails)
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                @if ($contact->Prfl_Name)
                    <p><span class="text-green-200 font-medium">Profession:</span> 
                       <span class="text-white">{{ $contact->Prfl_Name }}</span></p>
                @endif
                @if ($contact->Prfl_Addr)
                    <p class="sm:col-span-2"><span class="text-green-200 font-medium">Profession Address:</span> 
                       <span class="text-white">{{ $contact->Prfl_Addr }}</span></p>
                @endif
            </div>
        @endif
    </div>
@endif


            <!-- References -->
            @if ($contact->referencePersons->isNotEmpty())
                <div class="figma-card p-4">
                    <h2 class="text-xs font-semibold text-slate-300 mb-3 uppercase flex items-center gap-1">
                        <i class="bi bi-people-fill text-cyan-400"></i> References
                    </h2>

                    <!-- START: MODIFIED PARENT DIV -->
                    <div class="divide-y divide-slate-700">
                        <!-- END: MODIFIED PARENT DIV -->

                        @foreach ($contact->referencePersons as $reference)
                            <!-- START: MODIFIED CHILD DIV (added padding) -->
                            <div class=" pl-3 text-sm py-3 first:pt-0 last:pb-0">
                                <!-- END: MODIFIED CHILD DIV -->

                                <p class="text-white font-medium">{{ $reference->Refa_Name }}</p>
                                @if ($reference->Refa_Rsip)
                                    <p class="text-green-200 text-xs">{{ $reference->Refa_Rsip }}</p>
                                @endif
                                <div class="flex items-center gap-4 mt-1 text-xs">
                                    @if ($reference->Refa_Emai)
                                        <a href="mailto:{{ $reference->Refa_Emai }}"
                                            class="text-blue-400 hover:text-blue-300 flex items-center gap-1">
                                            <i class="bi bi-envelope"></i> {{ $reference->Refa_Emai }}
                                        </a>
                                    @endif
                                    @if ($reference->Refa_Phon)
                                        <a href="tel:{{ $reference->Refa_Phon }}"
                                            class="text-blue-400 hover:text-blue-300 flex items-center gap-1">
                                            <i class="bi bi-telephone"></i> {{ $reference->Refa_Phon }}
                                        </a>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif



            <!-- Notes -->
            @if ($contact->Note)
                <div class="figma-card p-4">
                    <h2 class="text-xs font-semibold text-slate-300 mb-2 uppercase flex items-center gap-1">
                        <i class="bi bi-journal-text text-indigo-400"></i> Notes
                    </h2>
                    <p class="text-white text-sm whitespace-pre-line">{{ $contact->Note }}</p>
                </div>
            @endif

        </div>
    </div>
</div>
