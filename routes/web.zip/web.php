<?php

use App\Http\Controllers\Api\RedirectAuthController;
use App\Livewire\Contacts\Create as ContactsCreate;
use App\Livewire\Contacts\CreateByLink;
use App\Livewire\Contacts\Edit as ContactsEdit;
use App\Livewire\Contacts\Index as ContactsIndex;
use App\Livewire\Contacts\Show as ContactsShow;
use App\Livewire\Organizations\Select;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

// Public routes (no authentication required)
Route::get('/api/auth/redirect', [RedirectAuthController::class, 'handleRedirect'])
    ->name('api.auth.redirect');

// Create by link route - public access
Route::get('/contact/create-by-link/{token}', CreateByLink::class)->name('contact.create-by-link');

// Routes requiring API authentication
Route::middleware(['api.authenticated'])->group(function () {
    // Organization selection
    Route::get('/select-organization', Select::class)
        ->middleware('organization.selected')
        ->name('organization.select');
    // Organization switching
    Route::post('/switch-organization', function (\Illuminate\Http\Request $request) {
        $request->validate(['orga_uin' => 'required|numeric']);

        $userUIN = session('authenticated_user_uin');

        // Use User_UIN for access verification
        $hasAccess = DB::table('admn_user_orga_rela')
            ->where('User_UIN', $userUIN)
            ->where('Orga_UIN', $request->orga_uin)
            ->where('Stau_UIN', 100201)  // Only active associations
            ->exists();

        if (!$hasAccess) {
            return redirect()->back()->with('error', 'Access denied to selected organization');
        }

        session(['selected_Orga_UIN' => $request->orga_uin]);

        // Get organization name for success message
        $org = DB::table('admn_orga_mast')->where('Orga_UIN', $request->orga_uin)->first();

        return redirect()->back()->with('success');
    })->name('organization.switch');

    // Logout route
    Route::post('/api/auth/logout', function () {
        session()->flush();
        session()->regenerate();
        return redirect('/')->with('success', 'Logged out successfully');
    })->name('api.auth.logout');

    // Routes requiring both authentication AND organization context
    Route::middleware(['organization.context'])->group(function () {
        Route::get('/', ContactsIndex::class)->name('home');
        Route::get('/contacts', ContactsIndex::class)->name('contacts.index');
        Route::get('/contacts/create', ContactsCreate::class)->name('contacts.create');
        Route::get('/contacts/{contact}/edit', ContactsEdit::class)->name('contacts.edit');
        Route::get('/contacts/{contact}', ContactsShow::class)->name('contacts.show');
        Route::get('/download-document/{path}', function ($path) {
            try {
                $filePath = base64_decode($path, true);

                if (!$filePath) {
                    \Log::error('Invalid base64 encoding for document path');
                    abort(400, 'Invalid file path');
                }

                // Check if file exists in public storage
                if (!Storage::disk('public')->exists($filePath)) {
                    \Log::error('Document file not found', [
                        'filePath' => $filePath,
                        'fullPath' => Storage::disk('public')->path($filePath),
                    ]);
                    abort(404, 'File not found');
                }

                $fullPath = Storage::disk('public')->path($filePath);
                $mimeType = mime_content_type($fullPath);

                \Log::info('Downloading document', [
                    'filePath' => $filePath,
                    'mimeType' => $mimeType,
                    'fileName' => basename($fullPath)
                ]);

                // Return the file with correct headers
                return response()->download($fullPath, basename($fullPath), [
                    'Content-Type' => $mimeType
                ]);
            } catch (\Exception $e) {
                \Log::error('Error downloading document: ' . $e->getMessage());
                abort(500, 'Error downloading file');
            }
        })->name('download.document');
        Route::get('/download-doc/{encodedPath}', function ($encodedPath) {
            \Log::info('Download request received', ['encodedPath' => $encodedPath]);

            $filePath = base64_decode($encodedPath, true);

            if (!$filePath) {
                \Log::error('Invalid base64 encoding');
                return response('Invalid file path', 400);
            }

            \Log::info('Decoded file path', ['filePath' => $filePath]);

            if (!Storage::disk('public')->exists($filePath)) {
                \Log::error('File does not exist', [
                    'filePath' => $filePath,
                    'exists' => Storage::disk('public')->exists($filePath)
                ]);
                return response('File not found', 404);
            }

            $fullPath = Storage::disk('public')->path($filePath);
            \Log::info('File found', ['fullPath' => $fullPath, 'fileExists' => file_exists($fullPath)]);

            if (!file_exists($fullPath)) {
                \Log::error('Physical file does not exist', ['fullPath' => $fullPath]);
                return response('File not found on disk', 404);
            }

            $fileName = basename($filePath);
            return response()->download($fullPath, $fileName);
        })->name('download.doc');
    });
});

// Debug route to check document storage
Route::get('/debug-documents', function () {
    $documents = \App\Models\Admn_Docu_Mast::where('Stau', 100201)
        ->limit(5)
        ->get();

    return response()->json([
        'documents' => $documents->map(function ($doc) {
            $fullPath = \Storage::disk('public')->path($doc->Docu_Atch_Path);
            return [
                'Admn_Docu_Mast_UIN' => $doc->Admn_Docu_Mast_UIN,
                'Docu_Atch_Path' => $doc->Docu_Atch_Path,
                'fullPath' => $fullPath,
                'exists' => \Storage::disk('public')->exists($doc->Docu_Atch_Path),
                'fileExists' => file_exists($fullPath),
                'size' => $doc->Docu_Atch_Path ? \Storage::disk('public')->size($doc->Docu_Atch_Path) : null,
            ];
        }),
        'storage_path' => \Storage::disk('public')->path(''),
        'public_path' => public_path('storage'),
    ]);
});

// Debug route (remove in production)
Route::get('/debug-orga-relation', function () {
    $userUIN = session('authenticated_user_uin');

    // Raw query to see what's in the table for this user
    $relations = DB::table('admn_user_orga_rela')
        ->where('User_UIN', $userUIN)
        ->get();

    // Query with organization details
    $organizationsQuery = DB::table('admn_user_orga_rela')
        ->join('admn_orga_mast', 'admn_user_orga_rela.Orga_UIN', '=', 'admn_orga_mast.Orga_UIN')
        ->where('admn_user_orga_rela.User_UIN', $userUIN)
        ->where('admn_user_orga_rela.Stau_UIN', 100201)
        ->select(
            'admn_user_orga_rela.*',
            'admn_orga_mast.Orga_UIN',
            'admn_orga_mast.Orga_Name'
        )
        ->get();

    return response()->json([
        'authenticated_user_uin' => $userUIN,
        'raw_relations' => $relations,
        'organizations_with_details' => $organizationsQuery,
        'total_relations' => $relations->count(),
        'active_organizations' => $organizationsQuery->count()
    ]);
})->middleware(['api.authenticated']);
Route::post('/logout', function (Request $request) {
    Auth::logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    // Instead of redirecting, return a success JSON response
    return response()->json(['status' => 'success', 'message' => 'Logged out successfully.']);
})->name('logout');
require __DIR__ . '/auth.php';
